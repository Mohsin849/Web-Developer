<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class UserProfileView extends Authenticatable
{
    protected $table = 'user_profile_view';
	
	public function user()
    {
        return $this->hasOne('App\User', 'id','user_profile_view_id');
    }
	
	public function userMatch()
    {
        return $this->hasOne('App\UserMatch','user_id','user_profile_view_id');
    }
	
	public function userIn()
    {
        return $this->hasOne('App\User', 'id','user_id');
    }
	
	public function userMatchIn()
    {
        return $this->hasOne('App\UserMatch','user_id','user_id');
    }
}
