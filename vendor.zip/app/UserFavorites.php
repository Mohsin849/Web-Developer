<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class UserFavorites extends Authenticatable
{
    protected $table = 'user_favorites';
	
	public function user()
    {
        return $this->hasOne('App\User', 'id','favorite_user_id');
    }
	
	public function userMatch()
    {
        return $this->hasOne('App\UserMatch','user_id','favorite_user_id');
    }
	
	public function userIn()
    {
        return $this->hasOne('App\User', 'id','user_id');
    }
	
	public function userMatchIn()
    {
        return $this->hasOne('App\UserMatch','user_id','user_id');
    }
}
