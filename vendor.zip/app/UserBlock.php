<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class UserBlock extends Authenticatable
{
    protected $table = 'user_block';
	
	public function user()
    {
        return $this->hasOne('App\User', 'id','user_block_id');
    }
	
	public function userMatch()
    {
        return $this->hasOne('App\UserMatch','user_id','user_block_id');
    }
	
	
}
