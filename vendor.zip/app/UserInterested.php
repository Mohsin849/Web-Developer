<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class UserInterested extends Authenticatable
{
    protected $table = 'user_interest_my';
	
	public function user()
    {
        return $this->hasOne('App\User', 'id','interest_id');
    }
	
	public function userMatch()
    {
        return $this->hasOne('App\UserMatch','user_id','interest_id');
    }
	
	public function userIn()
    {
        return $this->hasOne('App\User', 'id','user_id');
    }
	
	public function userMatchIn()
    {
        return $this->hasOne('App\UserMatch','user_id','user_id');
    }
}
