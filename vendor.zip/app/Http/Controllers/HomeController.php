<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\User;
use App\UserInterested;
use App\UserBlock;
use App\UserProfileView;
use App\UserFavorites;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
	public function dashboard()
    {
		if(Auth::user()->gender == 2){
			$genderOrder ='Asc';
		}else{
			$genderOrder ='Desc';
		}
		$userList = User::with(['UserMatch','userCountry','userState','userCity'])
		            ->where('id','!=',Auth::user()->id)->where('user_status',1)->orderBy('gender',$genderOrder)->paginate(20);
		       	  
		$resultInterest = DB::table('user_interest_my')->select('interest_id')->where('user_id',Auth::user()->id)->get(); 
		   
		$resultInterest = json_decode(json_encode($resultInterest), true);
	    
	    $resultInterest = array_column($resultInterest, 'interest_id');

        return view('user.dashboard')->with(['userList'=>$userList,'resultInterest'=>$resultInterest]);
    }
	public function matches()
    {
		if(Auth::user()->gender == 2){
			$gender =1;
		}else{
			$gender =2;
		}
		$userList = User::with(['UserMatch','userCountry','userState','userCity'])
		            ->where('id','!=',Auth::user()->id)->where('user_status',1)->where('gender',$gender)->paginate(20);
		       	  
		$resultInterest = DB::table('user_interest_my')->select('interest_id')->where('user_id',Auth::user()->id)->get(); 
		   
		$resultInterest = json_decode(json_encode($resultInterest), true);
	    
	    $resultInterest = array_column($resultInterest, 'interest_id');

        return view('user.dashboard')->with(['userList'=>$userList,'resultInterest'=>$resultInterest]);
    }
	
	public function showEmailSettings()
    {
        return view('user.showEmailSettings');
    }
	
	//update email address
	public function postEmailSettings(Request $request)
    {
		$emailAddress = $request->input('emailAddress');
		if(!empty($emailAddress)){
			
			$resultData = DB::table('users')->where('email',$emailAddress)->count();
			if($resultData > 1){
				//if redirect back with error
				return redirect()->back()
						->withErrors('The email address already exists under another profile. Please enter another email address.');
			}else{
				DB::table('users')->where('id',Auth::user()->id)->update(
					['email' => $emailAddress]
				);
				// if redirect back with Success
				return redirect()->back()->withSuccess('Your email has been successfully updated!');
			}
		}else{
			// if redirect back with error
            return redirect()->back()->withErrors('Email is required');
		}
	}
	
	public function showPasswordSettings()
    {
        return view('user.showPasswordSettings');
    }
	
	public function postPasswordSettings(Request $request)
    {
        $oldPassword = $request->input('oldPassword');
		
		$newPassword = $request->input('newPassword');
		$confPassword = $request->input('confPassword');
		$matchPassword = false;
		if($newPassword == $confPassword){
			$matchPassword = true;
		}
		
		if(Hash::check($oldPassword, Auth()->user()->password)){
			DB::table('users')->where('id',Auth::user()->id)->update(
					['password' => Hash::make($newPassword)]
				);
			// if redirect back with Success
			return redirect()->back()->withSuccess('Successfully Updated!');	
		}else{
			
			// if unsuccessful -> redirect back
            return redirect()->back()->withErrors([
                'old_password' => 'Old password is in correct',
            ]);
		}
    }
	
	
	
	public function showProfileSettings()
    {	
		$countryList = DB::table('countries')->get();
		$stateList = DB::table('states')->where('country_id',Auth::user()->country)->get();
		$cityList = DB::table('cities')->where('state_id',Auth::user()->state)->get();
        return view('user.showProfileSettings')->with(['countryList'=>$countryList,
														'stateList'=>$stateList,
														'cityList'=>$cityList]);
    }
    public function showProfile($username,$id)
    {	
		$userProfile = DB::table('users')->where('id',$id)->first();
		$userAppericens = DB::table('user_appericens')->where('user_id',$id)->first();
		$userLifestyle = DB::table('user_lifestyle')->where('user_id',$id)->first();
		$userBackground = DB::table('user_background')->where('user_id',$id)->first();
		$countryList = DB::table('countries')->where('id',Auth::user()->country)->first();
		$stateList = DB::table('states')->where('country_id',Auth::user()->state)->first();
		$cityList = DB::table('cities')->where('state_id',Auth::user()->city)->first();
		
		$myInterest = DB::table('user_interest_my')->where('user_id',Auth::user()->id)->where('interest_id',$id)->count();
		$blockUser = DB::table('user_block')->where('user_id',Auth::user()->id)->where('block_user_id',$id)->count();
		$favoriteUser = DB::table('user_favorites')->where('user_id',Auth::user()->id)->where('favorite_user_id',$id)->count();
		
		$userProfileView = DB::table('user_profile_view')->where('user_id',Auth::user()->id)->where('user_profile_view_id',$id)->count();
		
		if($userProfileView == 0 && Auth::user()->id != $id){
			$dataInsert['user_id'] = Auth::user()->id;
			$dataInsert['user_profile_view_id'] = $id;
			DB::table('user_profile_view')->insert($dataInsert);
		}
		$userMatch = DB::table('user_match')->where('user_id',$id)->first();
		
		$resultInterest = DB::table('user_interest_my')->where('interest_id',$id)->where('user_id',Auth::user()->id)->get()->toArray();
		
        return view('user.showProfileUser')->with(['resultInterest'=>$resultInterest,'countryList'=>$countryList,
														'stateList'=>$stateList,
														'cityList'=>$cityList,
														'userProfile'=>$userProfile,
														'userAppericens'=>$userAppericens,
														'userLifestyle'=>$userLifestyle,
														'userBackground'=>$userBackground,'userMatch'=>$userMatch,'myInterest'=>$myInterest,
														'blockUser'=>$blockUser,'favoriteUser'=>$favoriteUser]);
    }
    
	
	//update user basic profile setting
	public function postProfileSettings(Request $request)
    {
	   $onlineStatus = $request->input('onlineStatus');
	   $country = $request->input('country');
	   $state = $request->input('state');
	   $city = $request->input('city');
	   
		DB::table('users')->where('id',Auth::user()->id)->update(
					['online_status' => $onlineStatus,'country' => $country,'state' => $state,'city' => $city]
				);
		// if redirect back with Success
		return redirect()->back()->withSuccess('Successfully Updated!');
    }
	
	public function showNotificationSettings()
    {
		$notificationList = DB::table('user_notifications')->where('user_id',Auth::user()->id)->get();
		return view('user.showNotificationSettings')->with(['notificationList'=>$notificationList]);
    }
	
	public function postNotificationSettings(Request $request)
    {
		$newMessage = $request->input('newMessage');
		DB::table('user_notifications')->where('user_id',Auth::user()->id)
									 ->where('notification_id',101)->update(['notification_status' => $newMessage]);
		$interestMe = $request->input('interestMe');
		DB::table('user_notifications')->where('user_id',Auth::user()->id)
									 ->where('notification_id',102)->update(['notification_status' => $interestMe]);
		$newMatche = $request->input('newMatche');
		DB::table('user_notifications')->where('user_id',Auth::user()->id)
									 ->where('notification_id',103)->update(['notification_status' => $newMatche]);
		$promotions = $request->input('promotions');
		DB::table('user_notifications')->where('user_id',Auth::user()->id)
										->where('notification_id',104)->update(['notification_status' => $promotions]);
		// if redirect back with Success
		return redirect()->back()->withSuccess('Successfully Updated!');							 
    }
	
	
	public function editMyProfile()
    {
		$countryList = DB::table('countries')->get();
		$stateList = DB::table('states')->where('country_id',Auth::user()->country)->get();
		$cityList = DB::table('cities')->where('state_id',Auth::user()->state)->get();
		$userBackground = DB::table('user_background')->where('user_id',Auth::user()->id)->first();
		$userAppericens = DB::table('user_appericens')->where('user_id',Auth::user()->id)->first();
		$userLifestyle = DB::table('user_lifestyle')->where('user_id',Auth::user()->id)->first();
		return view('user.editmyprofile')->with(['countryList'=>$countryList,
												'stateList'=>$stateList,'cityList'=>$cityList,
												'userBackground'=>$userBackground,'userAppericens'=>$userAppericens,
												'userLifestyle'=>$userLifestyle]);
    }
	
	public function postMyProfile(Request $request)
    {
		$userId = Auth::user()->id;
		//user basic information update
		$name = $request->input('name');
		$gender = $request->input('gender');
		$date_of_birth = $request->input('date_of_birth');
		$country = $request->input('country');
		$state = $request->input('state');
		$city = $request->input('city');
		$profile_heading = $request->input('profile_heading');
		$about_youself = $request->input('about_youself');
		$looking_partner = $request->input('looking_partner');
		$dataUserProfile = array('name'=>$name,'gender'=>$gender,
							'date_of_birth'=>$date_of_birth,'country'=>$country,
							'state'=>$state,'city'=>$city,
							'profile_heading'=>$profile_heading,'about_yourself'=>$about_youself,'looking_partner'=>$looking_partner);
		
		DB::table('users')->where('id',$userId)->update($dataUserProfile);
		//user user appericens information update
		$hair_color = $request->input('hair_color');
		$hair_length = $request->input('hair_length');
		$hair_type = $request->input('hair_type');
		$eye_color = $request->input('eye_color');
		$eye_wear = $request->input('eye_wear');
		$height = $request->input('height');
		$weight = $request->input('weight');
		$body_type = $request->input('body_type');
		$ethnicity = $request->input('ethnicity');
		$facial_hair = $request->input('facial_hair');
		$best_feature = $request->input('best_feature');
		$body_art = $request->input('body_art');
		$appearance = $request->input('appearance');
		$dataUserAppericens = array('hair_color'=>$hair_color,'hair_length'=>$hair_length,
									'hair_type'=>$hair_type,'eye_color'=>$eye_color,
									'eye_wear'=>$eye_wear,'height'=>$height,
									'weight'=>$weight,'body_type'=>$body_type,
									'ethnicity'=>$ethnicity,'ethnicity'=>$ethnicity,
									'facial_hair'=>$facial_hair,'facial_hair'=>$facial_hair,
									'best_feature'=>$best_feature,'body_art'=>$body_art,
									'appearance'=>$appearance);
		DB::table('user_appericens')->where('user_id',$userId)->update($dataUserAppericens);
		//user lifestyle information update
		$drink = $request->input('drink');
		$smoke = $request->input('smoke');
		$marital_status = $request->input('marital_status');
		$children_have = $request->input('children_have');
		$children_number = $request->input('children_number');
		$children_oldest = $request->input('children_oldest');
		$youngest_child = $request->input('youngest_child');
		$children_want = $request->input('children_want');
		$occupation = $request->input('occupation');
		$employment_status = $request->input('employment_status');
		$home_type = $request->input('home_type');
		$living_situation = $request->input('living_situation');
		$relocate = $request->input('relocate');
		$dataUserLifestyle = array('drink'=>$drink,'smoke'=>$smoke,
									'marital_status'=>$marital_status,'children_have'=>$children_have,
									'children_number'=>$children_number,'children_oldest'=>$children_oldest,
									'youngest_child'=>$youngest_child,'children_want'=>$children_want,
									'occupation'=>$occupation,'employment_status'=>$employment_status,
									'home_type'=>$home_type,'living_situation'=>$living_situation,'relocate'=>$relocate);
		DB::table('user_lifestyle')->where('user_id',$userId)->update($dataUserLifestyle);
		//user background information update
		$nationality = $request->input('nationality');
		$education = $request->input('education');
		$english_ability = $request->input('english_ability');
		$religion = $request->input('religion');
		$religion_values = $request->input('religion_values');
		$star_sign = $request->input('star_sign');
		
		$dataUserBackground = array('nationality'=>$nationality,'education'=>$education,
									'english_ability'=>$english_ability,'religion'=>$religion,
									'religion_values'=>$religion_values,'star_sign'=>$star_sign);
		DB::table('user_background')->where('user_id',$userId)->update($dataUserBackground);
		// if redirect back with Success
		return redirect()->back()->withSuccess('Successfully Updated!');
    }
	
	public function editProfilePhotos()
    {
		$notificationList = DB::table('user_notifications')->where('user_id',Auth::user()->id)->get();
		return view('user.editprofilephotos')->with(['notificationList'=>$notificationList]);
    }
	
	public function editMatchInfo()
    {
		$countryList = DB::table('countries')->get();
		$stateList = DB::table('states')->where('country_id',Auth::user()->country)->get();
		$cityList = DB::table('cities')->where('state_id',Auth::user()->state)->get();
		$useMatch = DB::table('user_match')->where('user_id',Auth::user()->id)->first();
		return view('user.editmatchinfo')->with(['countryList'=>$countryList,
												'stateList'=>$stateList,'cityList'=>$cityList,'useMatch'=>$useMatch]);
    }
	
	public function editInterestInfo()
    {
		$interestInfo = DB::table('user_interest_fun')->where('user_id',Auth::user()->id)->first();
		return view('user.editinterestinfo')->with(['interestInfo'=>$interestInfo]);
    }
	
	public function editPersonalityInfo()
    {
		$userPersonality = DB::table('user_personality')->where('user_id',Auth::user()->id)->get();
		return view('user.editpersonalityinfo')->with(['userPersonality'=>$userPersonality]);
    }
	
	public function postPersonalityInfo(Request $request)
    {
		$userId = Auth::user()->id;
		$favoriteMovie = $request->input('favorite_movie');
		$favoriteBook = $request->input('favorite_book');
		$foodLike = $request->input('food_like');
		$musicLike = $request->input('music_like');
		$hobbieInterest = $request->input('hobbie_interest');
		$physicalAppearance = $request->input('physical_appearance');
		$senseHumor = $request->input('sense_humor');
		$personality = $request->input('personality');
		$travelTo = $request->input('travel_to');
		$cultureOwn = $request->input('culture_own');
		$romanticWeekend = $request->input('romantic_weekend');
		$perfectMatch = $request->input('perfect_match');
		
		$userPersonality = DB::table('user_personality')->where('user_id',$userId)->count();
		
		$dataArray = array('favorite_movie'=>$favoriteMovie,'favorite_book'=>$favoriteBook,
							'food_like'=>$foodLike,'music_like'=>$musicLike,
							'hobbie_interest'=>$hobbieInterest,'physical_appearance'=>$physicalAppearance,
							'sense_humor'=>$senseHumor,'personality'=>$personality,'travel_to'=>$travelTo,
							'culture_own'=>$cultureOwn,'romantic_weekend'=>$romanticWeekend,'perfect_match'=>$perfectMatch);
		if($userPersonality > 0){
			DB::table('user_personality')->where('user_id',$userId)->update($dataArray);
		}else{
			$dataArray['user_id'] = $userId;
			DB::table('user_personality')->insert($dataArray);
		}
		// if redirect back with Success
		return redirect()->back()->withSuccess('Successfully Updated!');
    }
	
	public function verifyProfile()
    {
		
		return view('user.verifyprofile');
    }
	
	public function postVerifyProfile(Request $request)
    {
		
		$image = $request->file('verifyDocument');
		
		$imageName = time().'.'.$image->getClientOriginalExtension();

		$image->move(public_path('../resources/assets/images/documents'), $imageName);
		
		DB::table('users')->where('id',Auth::user()->id)->update(array('verify_document'=>$imageName));
		// if redirect back with Success
		return redirect()->back()->withSuccess('Your profile will be approve soon after admin approve');
    }
	
	public function postProfilePhotos(Request $request)
    {
		$image = $request->file('profileImage');
		
		$imageName = time().'.'.$image->getClientOriginalExtension();

		$image->move(public_path('../resources/assets/images/profile/'), $imageName);
		
		if(Auth::user()->avatar_1 == ""){
			DB::table('users')->where('id',Auth::user()->id)->update(array('avatar_1'=>$imageName));
		}else if(Auth::user()->avatar_2 == ""){
			DB::table('users')->where('id',Auth::user()->id)->update(array('avatar_2'=>$imageName));
		}else if(Auth::user()->avatar_3 == ""){
			DB::table('users')->where('id',Auth::user()->id)->update(array('avatar_3'=>$imageName));
		}else if(Auth::user()->avatar_4 == ""){
			DB::table('users')->where('id',Auth::user()->id)->update(array('avatar_4'=>$imageName));
		}else if(Auth::user()->avatar_5 == ""){
			DB::table('users')->where('id',Auth::user()->id)->update(array('avatar_5'=>$imageName));
		}
		
		// if redirect back with Success
		return redirect()->back()->withSuccess('Successfully Updated!');
    }
	
	public function postInterestInfo(Request $request)
    {
		$antiques = $request->input('antiques');
		$art_painting = $request->input('art_painting');
		$astrology = $request->input('astrology');
		$ballet = $request->input('ballet');
		$bars_pubs_nightclubs = $request->input('bars_pubs_nightclubs');
		$beach_parks = $request->input('beach_parks');
		$board_card_game = $request->input('board_card_game');
		$camping = $request->input('camping');
		$cars_mechanics = $request->input('cars_mechanics');
		$casino_gambling = $request->input('casino_gambling');
		$collecting = $request->input('collecting');
		$comedy_clubs = $request->input('comedy_clubs');
		$computer_internet = $request->input('computer_internet');
		$concerts_live_music = $request->input('concerts_live_music');
		$cooking_food = $request->input('cooking_food');
		$crafts = $request->input('crafts');
		$dancing = $request->input('dancing');
		$dining_out = $request->input('dining_out');
		$dancing_parties = $request->input('dancing_parties');
		$education = $request->input('education');
		$family = $request->input('family');
		$fashion_events = $request->input('fashion_events');
		$gardening = $request->input('gardening');
		$home_improvement = $request->input('home_improvement');
		$investing_finance = $request->input('investing_finance');
		$karaoke_sing_along = $request->input('karaoke_sing_along');
		$library = $request->input('library');
		$meditation = $request->input('meditation');
		$motorcycles = $request->input('motorcycles');
		$movies_cinema = $request->input('movies_cinema');
		$museums = $request->input('museums');
		$music_listening = $request->input('music_listening');
		$music_playing = $request->input('music_playing');
		$news_politics = $request->input('news_politics');
		$pets = $request->input('pets');
		$philosophy_spirituality = $request->input('philosophy_spirituality');
		$photography = $request->input('photography');
		$poetry = $request->input('poetry');
		$reading = $request->input('reading');
		$science_and_technology = $request->input('science_and_technology');
		$shopping = $request->input('shopping');
		$social_causes_activism = $request->input('social_causes_activism');
		$tv_education_news = $request->input('tv_education_news');
		$tv_entertainment = $request->input('tv_entertainment');
		$theatre = $request->input('theatre');
		$traveling = $request->input('traveling');
		$video_online_game = $request->input('video_online_game');
		$volunteering = $request->input('volunteering');
		$watching_sports = $request->input('watching_sports');
		$wine_tasting = $request->input('wine_tasting');
		$writing = $request->input('writing');
		$other_fun = $request->input('other_fun');
		
		$dataArray = array('antiques'=>$antiques,'art_painting'=>$art_painting,
							'astrology'=>$astrology,'ballet'=>$ballet,
							'bars_pubs_nightclubs'=>$bars_pubs_nightclubs,'beach_parks'=>$beach_parks,
							'board_card_game'=>$board_card_game,'camping'=>$camping,'cars_mechanics'=>$cars_mechanics,
							'casino_gambling'=>$casino_gambling,'collecting'=>$collecting,'comedy_clubs'=>$comedy_clubs,
							'computer_internet'=>$computer_internet,'concerts_live_music'=>$concerts_live_music,
							'cooking_food'=>$cooking_food,'crafts'=>$crafts,
							'dancing'=>$dancing,'dining_out'=>$dining_out,
							'dancing_parties'=>$dancing_parties,'education'=>$education,'family'=>$family,
							'fashion_events'=>$fashion_events,'gardening'=>$gardening,'home_improvement'=>$home_improvement,
							'investing_finance'=>$investing_finance,'karaoke_sing_along'=>$karaoke_sing_along,
							'library'=>$library,'meditation'=>$meditation,
							'motorcycles'=>$motorcycles,'movies_cinema'=>$movies_cinema,
							'museums'=>$museums,'music_listening'=>$music_listening,'music_playing'=>$music_playing,
							'news_politics'=>$news_politics,'pets'=>$pets,'philosophy_spirituality'=>$philosophy_spirituality,
							'photography'=>$photography,'poetry'=>$poetry,'reading'=>$reading,
							'science_and_technology'=>$science_and_technology,'shopping'=>$shopping,
							'social_causes_activism'=>$social_causes_activism,'tv_education_news'=>$tv_education_news,
							'tv_entertainment'=>$tv_entertainment,'theatre'=>$theatre,
							'traveling'=>$traveling,'video_online_game'=>$video_online_game,'volunteering'=>$volunteering,
							'watching_sports'=>$watching_sports,'wine_tasting'=>$wine_tasting,'writing'=>$writing,'other_fun'=>$other_fun
							);
		
		DB::table('user_interest_fun')->where('user_id',Auth::user()->id)->update($dataArray);
		// if redirect back with Success
		return redirect()->back()->withSuccess('Successfully Updated!');
    }
    
    public function postMatchInfo(Request $request)
    {
		
		
		$gender = $request->input('gender');
		$age_min = $request->input('age_min');
		$age_max = $request->input('age_max');
		$country = $request->input('country');
		$state = $request->input('state');
		$city = $request->input('city');
		
		$height_min = $request->input('height_min');
		$height_max = $request->input('height_max');
		$weight_min = $request->input('weight_min');
		$weight_max = $request->input('weight_max');
		$body_type = $request->input('body_type');
		$ethnicity = $request->input('ethnicity');
		$appearance = $request->input('appearance');
		$hair_color = $request->input('hair_color');
		$hair_length = $request->input('hair_length');
		$hair_type = $request->input('hair_type');
		$eye_color = $request->input('eye_color');
		$eye_wear = $request->input('eye_wear');
		$best_feature = $request->input('best_feature');
		$body_art = $request->input('body_art');
		$smoke = $request->input('smoke');
		$drink = $request->input('drink');
		$relocate = $request->input('relocate');
		$marital_status = $request->input('marital_status');
		
		$have_children = $request->input('have_children');
		$more_children = $request->input('more_child');
		$occupation = $request->input('employment');
		$employment_status = $request->input('employment_status');
		$home_type = $request->input('home_type');
		$living_situation = $request->input('living');
		
		$nationality = $request->input('nationality');
		$education = $request->input('education');
		$language_ability = $request->input('english_ability');
		$religion = $request->input('religion');
		$religious_values = $request->input('religion_values');
		$star_ssign = $request->input('star_sign');
		if(!empty($body_type)){
		    $body_type = implode(',', $body_type);
		}
		if(!empty($ethnicity)){
		    $ethnicity = implode(',', $ethnicity);
		}
		if(!empty($appearance)){
		    $appearance = implode(',', $appearance);
		}
		if(!empty($hair_color)){
		    $hair_color = implode(',', $hair_color);
		}
		if(!empty($hair_length)){
		    $hair_length = implode(',', $hair_length);
		}
		if(!empty($hair_type)){
		    $hair_type = implode(',', $hair_type);
		}
		if(!empty($eye_color)){
		    $eye_color = implode(',', $eye_color);
		}
		if(!empty($eye_wear)){
		    $eye_wear = implode(',', $eye_wear);
		}
		if(!empty($best_feature)){
		    $best_feature = implode(',', $best_feature);
		}
		if(!empty($body_art)){
		    $body_art = implode(',', $body_art);
		}
		if(!empty($smoke)){
		    $smoke = implode(',', $smoke);
		}
		if(!empty($drink)){
		    $drink = implode(',', $drink);
		}
		if(!empty($relocate)){
		    $relocate = implode(',', $relocate);
		}
		if(!empty($marital_status)){
		    $marital_status = implode(',', $marital_status);
		}
		
		if(!empty($have_children)){
		    $have_children = implode(',', $have_children);
		}
		if(!empty($more_children)){
		    $more_children = implode(',', $more_children);
		}
		if(!empty($occupation)){
		    $occupation = implode(',', $occupation);
		}
		if(!empty($employment_status)){
		    $employment_status = implode(',', $employment_status);
		}
		if(!empty($home_type)){
		    $home_type = implode(',', $home_type);
		}
		if(!empty($living_situation)){
		    $living_situation = implode(',', $living_situation);
		}
		
		if(!empty($nationality)){
		    $nationality = implode(',', $nationality);
		}
		if(!empty($education)){
		    $education = implode(',', $education);
		}
		if(!empty($language_ability)){
		    $language_ability = implode(',', $language_ability);
		}
		
		if(!empty($religious_values)){
		    $religious_values = implode(',', $religious_values);
		}
		if(!empty($star_ssign)){
		    $star_ssign = implode(',', $star_ssign);
		}
		$dataArray = array('gender'=>$gender,'age_min'=>$age_min,
		                    'age_max'=>$age_max,'country'=>$country,
		                    'state'=>$state,'city'=>$city,
		                   'height_min'=>$height_min,'height_max'=>$height_max,'height_min'=>$height_min,'height_max'=>$height_max,'weight_min'=>$weight_min,'weight_max'=>$weight_max,'body_type'=>$body_type,'ethnicity'=>$ethnicity,'appearance'=>$appearance,'hair_color'=>$hair_color
		                   ,'hair_length'=>$hair_length,'hair_type'=>$hair_type,'eye_color'=>$eye_color,'eye_wear'=>$eye_wear,'best_feature'=>$best_feature,'body_art'=>$body_art,'smoke'=>$smoke,'drink'=>$drink,'relocate'=>$relocate,'marital_status'=>$marital_status,
						   'have_children'=>$have_children,'more_children'=>$more_children,'occupation'=>$occupation,'employment_status'=>$employment_status,'home_type'=>$home_type,'living_situation'=>$living_situation,
						   'nationality'=>$nationality,'education'=>$education,'language_ability'=>$language_ability,'religion'=>$religion,'religious_values'=>$religious_values,'star_ssign'=>$star_ssign);
		DB::table('user_match')->where('user_id',Auth::user()->id)->update($dataArray);
		// if redirect back with Success
		return redirect()->back()->withSuccess('Successfully Updated!');
    }
    
    public function interestInUser(Request $request)
    {
		$interestId = $request->input('interestId');
	    $userId = Auth::user()->id;
		$dataArray['interest_id'] = $interestId;
		$dataArray['user_id'] = $userId;
		DB::table('user_interest_my')->insert($dataArray);
		return $interestId;
		
    }
	public function favoritUser(Request $request)
    {
		$favoritUserId = $request->input('favoritUserId');
	    $userId = Auth::user()->id;
		$dataArray['favorite_user_id'] = $favoritUserId;
		$dataArray['user_id'] = $userId;
		DB::table('user_favorites')->insert($dataArray);
		return $favoritUserId;
		
    }
	
	public function deleteInterestInUser(Request $request)
    {
		$interestId = $request->input('interestId');
		DB::table('user_interest_my')->where('id',$interestId)->delete();
		return $interestId;
	}
	
	
	public function blockUser(Request $request)
    {
		$blockUserId = $request->input('block_user_id');
	    $userId = Auth::user()->id;
		$dataArray['block_user_id'] = $blockUserId;
		$dataArray['user_id'] = $userId;
		DB::table('user_block')->insert($dataArray);
		return $blockUserId;
		
    }
	public function deleteBlockUser(Request $request)
    {
		$blockUserId = $request->input('block_user_id');
	    $userId = Auth::user()->id;
		DB::table('user_block')->where('user_id',$userId)->where('block_user_id',$blockUserId)->delete();
		return $blockUserId;
	}
	 public function myInterest()
    {
		$result = UserInterested::with(['user','userMatch'])->where('user_id',Auth::user()->id)->get();
		return view('user.myInterest')->with(['myInterest'=>$result]);	
    }
	
	public function myFavorites()
    {
		$result = UserFavorites::with(['user','userMatch'])->where('user_id',Auth::user()->id)->get();
		return view('user.myFavorites')->with(['myFavorites'=>$result]);	
    }
	 
	public function favoritedInMe()
    {
		$result = UserFavorites::with(['userIn','userMatchIn'])->where('favorite_user_id',Auth::user()->id)->get();
		return view('user.favoritedInMe')->with(['myFavorites'=>$result]);	
    }
	public function interestedInMe()
    {
		$result = UserInterested::with(['userIn','userMatchIn'])->where('interest_id',Auth::user()->id)->get();
		return view('user.interestedInMe')->with(['myInterest'=>$result]);	
    }
	 public function blockList()
    {
		$result = UserBlock::with(['user','userMatch'])->where('user_id',Auth::user()->id)->get();
		return view('user.blockList')->with(['userBlock'=>$result]);
		
    }
	public function deleteProfileView(Request $request)
    {
		$profileViewUserId = $request->input('profile_view_user_id');
		DB::table('user_profile_view')->where('id',$profileViewUserId)->delete();
		return $profileViewUserId;
	}
	public function deleteFavoritUser(Request $request)
    {
		$favoritId = $request->input('favoritId');
		DB::table('user_favorites')->where('id',$favoritId)->delete();
		return $favoritId;
	}
	
	 public function profileView()
    {
		$result = UserProfileView::with(['user','userMatch'])->where('user_id',Auth::user()->id)->get();
		return view('user.profileView')->with(['myInterest'=>$result]);	
    }
	
	public function viewedMyProfile()
    {
		$result = UserProfileView::with(['userIn','userMatchIn'])->where('user_profile_view_id',Auth::user()->id)->get();
		return view('user.viewedMyProfile')->with(['myInterest'=>$result]);	
    }
}
