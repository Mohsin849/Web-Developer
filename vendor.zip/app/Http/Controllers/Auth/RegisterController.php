<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use DB;
class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/dashboard';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'firstname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
		
        $user =  User::create([
            'name' => $data['firstname'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
			'gender'=>$data['gender'],
			'age'=>$data['age'],
			'country'=>$data['country'],
			'city'=>$data['city'],
			'state'=>$data['state'],
        ]);
	
		DB::table('user_personality')->insert(['user_id'=>$user->id]);
		DB::table('user_lifestyle')->insert(['user_id'=>$user->id]);
		DB::table('user_background')->insert(['user_id'=>$user->id]);
		DB::table('user_appericens')->insert(['user_id'=>$user->id]);
		DB::table('user_interest_fun')->insert(['user_id'=>$user->id]);
		DB::table('user_notifications')->insert(['user_id'=>$user->id,'notification_id'=>101,'notification_status' => 1]);
		DB::table('user_notifications')->insert(['user_id'=>$user->id,'notification_id'=>102,'notification_status' => 1]);
		DB::table('user_notifications')->insert(['user_id'=>$user->id,'notification_id'=>103,'notification_status' => 1]);
		DB::table('user_notifications')->insert(['user_id'=>$user->id,'notification_id'=>104,'notification_status' => 1]);
		if($data['gender'] == 1){
		    $gender =2;
		}else{
		    $gender =1;
		}
		DB::table('user_match')->insert(['user_id'=>$user->id,'gender'=>$gender,'age_min' => $data['age'],'age_max'=>$data['age']+10]);
		
		return $user;
    }
	
	public function showRegistrationForm() {
		
		$countryList = DB::table('countries')->get();
		
		return view ('auth.register')->with('countryList',$countryList);
	}
	
	function getState(Request $request){
		$countryId = $request->input('countryId');
		$stateList = DB::table('states')->where('country_id',$countryId)->get();
		$option = '';
		$option .= '<option value="">State</option>';
		foreach($stateList as $item){
			$option .= '<option value="'.$item->id.'">'.$item->name.'</option>';
		}
		return $option;
	}
	
	function getCity(Request $request){
		$stateId = $request->input('stateId');
		$cityList = DB::table('cities')->where('state_id',$stateId)->get();
		$option = '';
		$option .= '<option value="">City</option>';
		foreach($cityList as $item){
			$option .= '<option value="'.$item->id.'">'.$item->name.'</option>';
		}
		return $option;
	}
}
