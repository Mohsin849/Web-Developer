<?php
 namespace App\Http\Controllers;
 use Illuminate\Http\Request;
 use Validator,Redirect,Response,File;
 use Socialite;
 use App\User;
 use DB;
 class SocialController extends Controller
 {
	 public function redirect($provider)
	 {
		 return Socialite::driver($provider)->redirect();
	 }
	 public function callback($provider)
	 {
	   $getInfo = Socialite::driver($provider)->user(); 
	   
	   $user = $this->createUser($getInfo,$provider); 
	   auth()->login($user); 
	   return redirect()->to('/dashboard');
	 }
	 function createUser($getInfo,$provider){
		 $user = User::where('provider_id', $getInfo->id)->first();
		 if (!$user) {
			 
			 $user = User::where('email', $getInfo->email)->first();
			 if (!$user) {
				$user = User::create([
					 'name'     => $getInfo->name,
					 'email'    => $getInfo->email,
					 'provider' => $provider,
					 'provider_id' => $getInfo->id
				]);
				
				DB::table('user_notifications')->insert(['user_id'=>$user->id,'notification_id'=>101,'notification_status' => 1]);
        		DB::table('user_notifications')->insert(['user_id'=>$user->id,'notification_id'=>102,'notification_status' => 1]);
        		DB::table('user_notifications')->insert(['user_id'=>$user->id,'notification_id'=>103,'notification_status' => 1]);
        		DB::table('user_notifications')->insert(['user_id'=>$user->id,'notification_id'=>104,'notification_status' => 1]);
				DB::table('user_personality')->insert(['user_id'=>$user->id]);
				DB::table('user_lifestyle')->insert(['user_id'=>$user->id]);
				DB::table('user_background')->insert(['user_id'=>$user->id]);
				DB::table('user_appericens')->insert(['user_id'=>$user->id]);
				DB::table('user_interest_fun')->insert(['user_id'=>$user->id]);
				
				if(1 == 1){
        		    $gender = 1;
        		}else{
        		    $gender =2;
        		}
		DB::table('user_match')->insert(['user_id'=>$user->id,'gender'=>$gender,'age_min' =>20,'age_max'=>30]);
		
		
			 }else{
				DB::table('users')->where('email',$getInfo->email)->update(
						['provider' => $provider,'provider_id'=>$getInfo->id]
					); 
			 }
			  
		   }
		   return $user;
	 }
	 
	public function privacyPolicy()
	{
		$result = DB::table('page_management')->where('page_key','privacy')->first();
	   return view('pages.privacyPolicy')->with(['result'=>$result]);
	}
	public function aboutUs()
	{
		$result = DB::table('page_management')->where('page_key','about')->first();
		return view('pages.aboutUs')->with(['result'=>$result]);
	}
	public function contactUs()
	{
	   return view('pages.contactUs');
	}
	public function termUse()
	{
		$result = DB::table('page_management')->where('page_key','termsofuse')->first();
	   return view('pages.termUse')->with(['result'=>$result]);
	}
	public function datingSafety()
	{
		$result = DB::table('page_management')->where('page_key','datingsafety')->first();
	   return view('pages.datingSafety')->with(['result'=>$result]);
	}
	public function stories()
	{
	   $result = DB::table('page_management')->where('page_key','success')->first();
	   return view('pages.stories')->with(['result'=>$result]);
	}
	 
 }