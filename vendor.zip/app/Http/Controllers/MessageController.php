<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Nahid\Talk\Facades\Talk;
use Auth;
use View;

class MessageController extends Controller
{
    protected $authUser;
    public function __construct()
    {
        $this->middleware('auth');
        

    }
	public function messageList(){
		Talk::setAuthUserId(Auth::user()->id);
		// controller method
		$inboxes = Talk::getInbox();
		
		return view('messages.message-list')->with(['inboxes'=>$inboxes]);
	}
    public function chatHistory($id)
    {	
		Talk::setAuthUserId(Auth::user()->id);
		$threads = Talk::threads();
        $conversations = Talk::getMessagesByUserId($id, 0, 5);
        $user = '';
        $messages = [];
        if(!$conversations) {
            $user = User::find($id);
        } else {
            $user = $conversations->withUser;
            $messages = $conversations->messages;
        }

        if (count($messages) > 0) {
            $messages = $messages->sortBy('id');
        }

        return view('messages.message-detail', compact('messages', 'user','threads'));
    }

    public function ajaxSendMessage(Request $request)
    {	
		Talk::setAuthUserId(Auth::user()->id);
        if ($request->ajax()) {
            $rules = [
                'message-data'=>'required',
                '_id'=>'required'
            ];

            $this->validate($request, $rules);

            $body = $request->input('message-data');
            $userId = $request->input('_id');

            if ($message = Talk::sendMessageByUserId($userId, $body)) {
                $html = view('ajax.newMessageHtml', compact('message'))->render();
                return response()->json(['status'=>'success', 'html'=>$html], 200);
            }
        }
    }

    public function ajaxDeleteMessage(Request $request, $id)
    {
		Talk::setAuthUserId(Auth::user()->id);
        if ($request->ajax()) {
            if(Talk::deleteMessage($id)) {
                return response()->json(['status'=>'success'], 200);
            }

            return response()->json(['status'=>'errors', 'msg'=>'something went wrong'], 401);
        }
    }

    public function tests()
    {
		Talk::setAuthUserId(Auth::user()->id);
        dd(Talk::channel());
    }
}
