<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use Redirect;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function admin()
    {
        return view('admin/dashboard');
    }
	
	public function userList()
    {
		$result = DB::table('users')->paginate(20);
        return view('admin/user-list')->with(['result'=>$result]);
    }
	public function pageList()
    {
		$result = DB::table('page_management')->paginate(20);
        return view('admin/page-list')->with(['result'=>$result]);
    }
	public function pageEdit($id)
    {
		$result = DB::table('page_management')->where('id',$id)->first();
        return view('admin/page-edit')->with(['result'=>$result]);
    }
	
	public function pageEditData($id)
    {
		$result = DB::table('page_management')->where('id',$id)->update(
                                    ['description' => request()->description]);
        return redirect()->to('admin/pageList');
    }
	public function EmailList()
    {
		$result = DB::table('email_template')->paginate(20);
        return view('admin/email-list')->with(['result'=>$result]);
    }
	public function EmailEdit($id)
    {
		$result = DB::table('email_template')->where('id',$id)->first();
        return view('admin/email-edit')->with(['result'=>$result]);
    }
	
	public function emailEditData($id)
    {
		$result = DB::table('email_template')->where('id',$id)->update(
                                    ['description' => request()->description]);
        return redirect()->to('admin/emailList');
    }
	public function profileApprove()
    {
		$result = DB::table('users')->where('verify_document','!=','')->paginate(20);
        return view('admin/profile-approve-list')->with(['result'=>$result]);
    }
}