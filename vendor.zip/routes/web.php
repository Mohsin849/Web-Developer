<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/dashboard', 'HomeController@dashboard')->name('dashboard');
Route::get('/matches', 'HomeController@matches')->name('matches');

Route::get('/showemailsettings', 'HomeController@showEmailSettings')->name('showemailsettings');
Route::post('/showemailsettings', 'HomeController@postEmailSettings')->name('showemailsettings');
Route::get('/showpasswordsettings', 'HomeController@showPasswordSettings')->name('showpasswordsettings');
Route::post('/showpasswordsettings', 'HomeController@postPasswordSettings')->name('showpasswordsettings');
Route::get('/showprofilesettings', 'HomeController@showProfileSettings')->name('showprofilesettings');
Route::post('/showprofilesettings', 'HomeController@postProfileSettings')->name('showprofilesettings');
Route::get('/shownotificationsettings', 'HomeController@showNotificationSettings')->name('shownotificationsettings');
Route::post('/shownotificationsettings', 'HomeController@postNotificationSettings')->name('shownotificationsettings');
Route::get('/auth/redirect/{provider}', 'SocialController@redirect');
Route::get('/callback/{provider}', 'SocialController@callback');

Route::post('/get/state', 'Auth\RegisterController@getState');
Route::post('/get/city', 'Auth\RegisterController@getCity');


Route::get('/show-profile/{username}/{id}', 'HomeController@showProfile')->name('show-profile');
Route::get('/editmyprofile', 'HomeController@editMyProfile')->name('editmyprofile');
Route::post('/editmyprofile', 'HomeController@postMyProfile')->name('editmyprofile');
Route::get('/editprofilephotos', 'HomeController@editProfilePhotos')->name('editprofilephotos');
Route::get('/editmatchinfo', 'HomeController@editMatchInfo')->name('editmatchinfo');
Route::post('/editmatchinfo', 'HomeController@postMatchInfo')->name('editmatchinfo');
Route::get('/editinterestinfo', 'HomeController@editInterestInfo')->name('editinterestinfo');
Route::get('/editpersonalityinfo', 'HomeController@editPersonalityInfo')->name('editpersonalityinfo');
Route::post('/editpersonalityinfo', 'HomeController@postPersonalityInfo')->name('editpersonalityinfo');
Route::get('/verifyprofile', 'HomeController@verifyProfile')->name('verifyprofile');
Route::post('/verifyprofile', 'HomeController@postVerifyProfile')->name('verifyprofile');
Route::post('/editprofilephotos', 'HomeController@postProfilePhotos')->name('editprofilephotos');
Route::post('/editinterestinfo', 'HomeController@postInterestInfo')->name('editinterestinfo');

Route::post('/save/interestInUser', 'HomeController@interestInUser')->name('/save/interestInUser');
Route::post('/save/blockUser', 'HomeController@blockUser')->name('/save/blockUser');
Route::post('/save/favoritUser', 'HomeController@favoritUser')->name('/save/favoritUser');

Route::post('/delete/deleteInterestInUser', 'HomeController@deleteInterestInUser')->name('/delete/deleteInterestInUser');
Route::post('/delete/deleteBlockUser', 'HomeController@deleteBlockUser')->name('/delete/deleteBlockUser');
Route::post('/delete/deleteProfileView', 'HomeController@deleteProfileView')->name('/delete/deleteProfileView');
Route::post('/delete/deleteFavoritUser', 'HomeController@deleteFavoritUser')->name('/delete/deleteFavoritUser');

Route::get('/privacy', 'SocialController@privacyPolicy');
Route::get('/about', 'SocialController@aboutUs');
Route::get('/contact', 'SocialController@contactUs');
Route::get('/termsofuse', 'SocialController@termUse');
Route::get('/datingsafety', 'SocialController@datingSafety');
Route::get('/general/success', 'SocialController@stories');



//

Route::get('/interested-in-me', 'HomeController@interestedInMe')->name('interested-in-me');
Route::get('/favorited-in-me', 'HomeController@favoritedInMe')->name('favorited-in-me');
Route::get('/viewed-my-profile', 'HomeController@viewedMyProfile')->name('viewed-my-profile');
Route::get('/my-interest', 'HomeController@myInterest')->name('my-interest');
Route::get('/my-favorites', 'HomeController@myFavorites')->name('favorites');
Route::get('/profile-view', 'HomeController@profileView')->name('profile-view');
Route::get('/block-list', 'HomeController@blockList')->name('block-list');

Route::get('/messageList', 'MessageController@messageList')->name('message');
Route::get('message/{id}', 'MessageController@chatHistory')->name('message.read');

Route::group(['prefix'=>'ajax', 'as'=>'ajax::'], function() {
   Route::post('message/send', 'MessageController@ajaxSendMessage')->name('message.new');
   Route::delete('message/delete/{id}', 'MessageController@ajaxDeleteMessage')->name('message.delete');
});

Route::get('/admin', 'AdminController@admin')    
    ->middleware('is_admin')    
    ->name('admin');

Route::get('/admin/userList', 'AdminController@userList')    
    ->middleware('is_admin')    
    ->name('userList');	
	
Route::get('/admin/pageList', 'AdminController@pageList')    
    ->middleware('is_admin')    
    ->name('pageList');	

Route::get('/admin/pageEdit/{id}', 'AdminController@pageEdit')    
    ->middleware('is_admin')    
    ->name('pageEdit');	

Route::post('/admin/edit-page-data/{id}', 'AdminController@pageEditData')    
    ->middleware('is_admin')    
    ->name('edit-page-data');

Route::get('/admin/emailList', 'AdminController@emailList')    
    ->middleware('is_admin')    
    ->name('emailList');	

Route::get('/admin/emailEdit/{id}', 'AdminController@emailEdit')    
    ->middleware('is_admin')    
    ->name('emailEdit');	

Route::post('/admin/edit-email-data/{id}', 'AdminController@emailEditData')    
    ->middleware('is_admin')    
    ->name('edit-email-data');
	
Route::get('/admin/profileApprove', 'AdminController@profileApprove')    
    ->middleware('is_admin')    
    ->name('profileApprove');	
	

