@extends('layouts.app')
@section('content')
<style>
.sectionHeading{
	    background-color: #f1f1f1;
    padding-bottom: 10px;
    display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
	display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
    list-style-type: none;
}
.sectionHeading h2 {
    font-size: 14px;
    font-weight: 700;
    float: left;
    width: 450px;
	font-family: inherit;
	line-height: 20px;

}
a, button, input {
	outline: medium none !important;
    color: initial;
}
.tab.tab-icon .nav-tabs li {
    width: 16.667%;
    text-align: center;
    float: left;
    position: relative;
}
  div.file {
            position: relative;
            overflow: hidden;
        }
        
        .file input {
            position: absolute;
            font-size: 50px;
            opacity: 0;
            right: 0;
            top: 0;
        }
</style>
<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
      <div class="col-md-12">
        <div class="tab tab-icon clearfix"> 
          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li>
				<a href="{{URL::to('/editprofilephotos')}}" >
					<span>Photos</span>
				</a>
				
			</li>
            <li>
				<a href="{{URL::to('/editmyprofile')}}">
					<span>Profile</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editmatchinfo')}}">
					<span>Match</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editinterestinfo')}}" >
					<span>Interest</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/editpersonalityinfo')}}" >
					<span>Personality</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/verifyprofile')}}" class="active">
					<span>Verify Profile</span>
				</a>
			</li>
          </ul>
          <!-- Tab panes -->
			<div class="tab-content">
				@if(session('success'))
					<div class="alert alert-success" role="alert">{{session('success')}}</div>
				@endif
				@if(session('errors'))
					<div class="alert alert-danger" role="alert">{{session('errors')}}</div>
				@endif
				<div role="tabpanel" class="tab-pane fade active in" id="tab2-1">
					<h3 class="text-warning text-center mb-5">Verify Your Profile And Get The Badge</h3>
					<div class="row text-center pb-5">
						<div class="col-md-4">
							<i class="fa fa-check-circle fa-3x text-warning float-sm-none float-left"></i>
							<p class="lead mt-2 float-sm-none float-left">Get more attention from singles</p>

						</div>
						<div class="col-md-4">
							<i class="fa fa-check-circle fa-3x text-warning float-sm-none float-left"></i>
							<p class="lead mt-2 float-sm-none float-left">Help improve member safety</p>
						</div>
						<div class="col-md-4">
							<i class="fa fa-check-circle fa-3x text-warning float-sm-none float-left"></i>
							<p class="lead mt-2 float-sm-none float-left">Rank higher in search results</p>
						</div>
					</div>
					<div class="card">
						<h5 class="card-header font-weight-bold">Profile Verification</h5>
						<div class="card-body">
							<h4 class="card-title text-center">Complete Your Profile Verification</h4>
							<p class="card-text text-center">Upload a scanned color copy or photo of your identification and get the badge!</p>
							<div class="row">
								<div class="col-md-6 pt-3" style="border-right: 1px solid;border-color: gainsboro;">
									<h5 class="text-center">Upload Verification Document Image</h5>
									<div class="row justify-content-center mt-4">
										<form method="post" data-parsley-validate="" enctype="multipart/form-data">
										@csrf
										<div class="file button btn-lg btn-theme full-rounded animated right-icn">
											&plus; Upload
											
												<input type="file"   name="verifyDocument" id="verifyDocument" required />
										</div>
										<div style="text-align:center;" class="col-md-12">
											<button type="submit" class="btn btn-success">Save</button>
										</div>	
										</form>
									</div>
								</div>
								<div class="col-md-6 pt-3 pl-5">
									<h5>Accepted Identification</h5>
									<ul>
										<li> <i class="fa fa-check-circle text-warning" style="font-size: 18px;" aria-hidden="true"></i> Passport
										</li>
										<li> <i class="fa fa-check-circle text-warning" style="font-size: 18px;" aria-hidden="true"></i> Driver's Licence
										</li>
										<li> <i class="fa fa-check-circle text-warning" style="font-size: 18px;" aria-hidden="true"></i> National ID Card
										</li>
									</ul>
								</div>
							</div>
							<p class="pt-3 text-center"><i class="fa fa-lock text-warning mr-2" style="font-size: 18px;" aria-hidden="true"></i>The information you provide is only used for profile verification and is not shared with other members or third parties.</p>
							<hr>
							<h5> You can also choose to send a color copy of the document through the following methods:</h5>
							<ul>
								<li><strong>Email:</strong> team@pinaypartners.com </li>
								<li><strong>Post:</strong> PO Box 9304 Gold Coast MC QLD 9726 Australia</li>
							</ul>
						</div>
					</div>
				</div>
           </div>
        </div>
      </div>
    </div>
  </div>
</section>
@endsection
