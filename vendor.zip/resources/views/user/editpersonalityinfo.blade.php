@extends('layouts.app')
@section('content')
<style>
.sectionHeading{
	    background-color: #f1f1f1;
    padding-bottom: 10px;
    display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
	display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
    list-style-type: none;
}
.sectionHeading h2 {
    font-size: 14px;
    font-weight: 700;
    float: left;
    width: 450px;
	font-family: inherit;
	line-height: 20px;

}
a, button, input {
	outline: medium none !important;
    color: initial;
}
.tab.tab-icon .nav-tabs li {
    width: 16.667%;
    text-align: center;
    float: left;
    position: relative;
}
</style>
<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
      <div class="col-md-12">
        <div class="tab tab-icon clearfix"> 
          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li>
				<a href="{{URL::to('/editprofilephotos')}}" >
					<span>Photos</span>
				</a>
				
			</li>
            <li>
				<a href="{{URL::to('/editmyprofile')}}">
					<span>Profile</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editmatchinfo')}}">
					<span>Match</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editinterestinfo')}}" >
					<span>Interest</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/editpersonalityinfo')}}" class="active">
					<span>Personality</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/verifyprofile')}}" >
					<span>Verify Profile</span>
				</a>
			</li>
          </ul>
          <!-- Tab panes -->
			<div class="tab-content">
				@if(session('success'))
					<div class="alert alert-success" role="alert">{{session('success')}}</div>
				@endif
				@if(session('errors'))
					<div class="alert alert-danger" role="alert">{{session('errors')}}</div>
				@endif
				<div role="tabpanel" class="tab-pane fade active in" id="tab2-1">
					<p class="mb-1">
						Let your personality shine. Express yourself in your own words to give other users a better understanding of who you are. Answer at least 7 questions below to complete this section.
					</p>
					<span class="sectionHeading clearfix">
						<h2>Edit Personality Profile</h2>
					</span>
					<form method="post" data-parsley-validate="">
					@csrf
						@foreach($userPersonality as $item)
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">What is your favorite movie?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="favorite_movie" id="favorite_movie" >{{$item->favorite_movie}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">What is your favorite book?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="favorite_book" id="favorite_book" >{{$item->favorite_book}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">What sort of food do you like?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="food_like" id="food_like" >{{$item->food_like}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">What sort of music do you like?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="music_like" id="music_like" >{{$item->music_like}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">What are your hobbies and interests?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="hobbie_interest" id="hobbie_interest" >{{$item->hobbie_interest}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">How would you describe your dress sense and physical appearance?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="physical_appearance" id="physical_appearance" >{{$item->physical_appearance}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">How would you describe your sense of humor?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="sense_humor" id="sense_humor" >{{$item->sense_humor}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">How would you describe your personality?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="personality" id="personality" >{{$item->personality}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Where have you traveled or would like to travel to?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="travel_to" id="travel_to" >{{$item->travel_to}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">How adaptive are you to having a partner from a different culture to your own?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="culture_own" id="culture_own" >{{$item->culture_own}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">How would you spend a perfect romantic weekend?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="romantic_weekend" id="romantic_weekend" >{{$item->romantic_weekend}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2">
							<div class="row">
								<div class="col-md-3">What sort of person would be your perfect match?</div>  
								<div class="col-md-6">
									<textarea  class="form-control" name="perfect_match" id="perfect_match" >{{$item->perfect_match}}</textarea>
								</div>
							</div>
						</div>
						@endforeach
						<div style="text-align:center;" class="col-md-12">
							<button type="submit" class="btn btn-success">Save</button>
						</div>
					</form>	
				</div>
           </div>
        </div>
      </div>
    </div>
  </div>
</section>
@endsection
