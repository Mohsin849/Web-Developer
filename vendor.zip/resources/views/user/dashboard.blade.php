@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <div class="row no-gutters mt-5 mb-5">
			
            <?php foreach($userList as $item) {?>
            <div class="col-lg-2 col-md-4 col-sm-4 m-2">
                <div class="card">
				    <a href="{{URL::to('/')}}/show-profile/{{$item->name}}/{{$item->id}}">
                    @if($item->avatar_1 == '')
						<img class="card-img-top" src="{{URL::to('/')}}/resources/assets/images/profile/avatar-1.png?w=300&h=400&fit=crop" alt="Card image" style="width:100%">
                    @else
						<img class="card-img-top" src="{{URL::to('/')}}/resources/assets/images/profile/{{$item->avatar_1}}?w=300&h=400&fit=crop" alt="Card image" style="width:100%">
                    @endif
					</a>
                    <div class="card-body">
                        <h5><a  href="{{URL::to('/')}}/show-profile/{{$item->name}}/{{$item->id}}" class="card-title text-center" 
							style="color:#505656">
								{{$item->name}}
								<span class="fa fa-user"></span>
								<span class="fa fa-circle ml-2" style="font-size:15px;color:#7faf41"></span>
						</a>
						</h5> 
                        <p class="card-text text-center"> 
							{{$item->age}}.{{$item->userCity['name']}}, {{$item->userState['name']}}, {{$item->userCountry['name']}}
						</p>
						<p class="card-text mt-0 text-center">
							Seeking: 
							@if($item->UserMatch['gender']==1)
							Male
							@else
							Female
							@endif
							 {{$item->UserMatch['age_min']}} - {{$item->UserMatch['age_max']}}<br>
						</p>
						<?php $countImages =0; ?>
						@if(!empty($item->avatar_2))
						    <?php $countImages++; ?>
						@endif
						@if(!empty($item->avatar_3))
						    <?php $countImages++; ?>
						@endif
						@if(!empty($item->avatar_4))
						    <?php $countImages++; ?>
						@endif
						@if(!empty($item->avatar_5))
						    <?php $countImages++; ?>
						@endif
						
						
                        <p class="text-center h4" style="color:#505656">
                            @if(in_array($item->id,$resultInterest))
							 <a id="{{$item->id}}" title="You showed interest in {{$item->name}}"><span style="color:red;" class="fa fa-heart float-left"></span></a>
							@else
							 <a id="{{$item->id}}" class="interestedme interestedme{{$item->id}}" title="Show interest in {{$item->name}}"><span class=" heart{{$item->id}} fa fa-heart float-left"></span></a>
							@endif
							
							<i class="fa fa-envelope"></i><span class="ml-2 float-right">{{$countImages}}</span><span class="fa fa-camera float-right"></span>
						</p>
                    </div>
                </div>
            </div>
            <?php } ?>
			
			<div class="col-md-12">{{$userList->render()}}</div>
        </div>
    </div>
@endsection
