@extends('layouts.app')
@section('content')
<style>
.sectionHeading{
	    background-color: #f1f1f1;
    padding-bottom: 10px;
    display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
	display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
    list-style-type: none;
}
.sectionHeading h2 {
    font-size: 14px;
    font-weight: 700;
    float: left;
    width: 450px;
	font-family: inherit;
	line-height: 20px;

}
a, button, input {
	outline: medium none !important;
    color: initial;
}
</style>
<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
      <div class="col-md-12">
        <div class="tab tab-icon clearfix"> 
          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li>
				<a href="{{URL::to('/showemailsettings')}}" >
					<span>Email Address</span>
				</a>
				
			</li>
            <li>
				<a href="{{URL::to('/showpasswordsettings')}}" class="active">
					<span>Password</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/showprofilesettings')}}">
					<span>Profile Settings</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/shownotificationsettings')}}" >
					<span>Notifications</span>
				</a>
			</li>
          </ul>
          <!-- Tab panes -->
          <div class="tab-content">
            <div role="tabpanel" class="tab-pane fade active in" id="tab2-1">
				@if(session('success'))
				<div class="alert alert-success" role="alert">{{session('success')}}</div>
				@endif
				@foreach ($errors->all() as $error)
					<div class="alert alert-danger" role="alert">{{ $error }}</div>
				@endforeach
				<div  class="col-md-12">
					<p style="margin-bottom: 0;">
						To help keep your account secure we recommend that you routinely change your password.
					</p>
					<strong>	
						Important: For extra security ensure that your new password is NOT the same as your email password.
					</strong>
				</div><br />
				<span class="sectionHeading clearfix">
					<h2>Enter your current password</h2>
				</span>
				<form method="post" data-parsley-validate="">
				@csrf
					<div style="padding:20px;" class="col-md-6">
						Current Password :  
						<span style="float:right;">
							<input style="width:300px;" type="password" name="oldPassword" id="oldPassword" placeholder="Old password" required >
						</span>
						<br/><br/>
					</div>
					<span class="sectionHeading clearfix">
						<h2>Enter your current password</h2>
					</span>
					<div style="padding:20px;" class="col-md-6">
						New Password :  
						<span style="float:right;">
							<input style="width:300px;" type="password" name="newPassword" id="newPassword" placeholder="New Password"  required>
						</span>
						 <br/><br/>
					</div>
					<div  class="col-md-6">
							Confirm Password :  
							<span style="float:right;">
								<input style="width:306px;" type="password" name="confPassword" id="confPassword" placeholder="Confirm Password" data-equalto="#newPassword" required>
							</span>
						 <br/><br/>
					</div>
					<div style="text-align:center;" class="col-md-12">
							<button type="submit" class="btn btn-success">Save</button>
					</div>
				</form>
			</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection
