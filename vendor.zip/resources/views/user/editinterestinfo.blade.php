@extends('layouts.app')
@section('content')
<style>
.sectionHeading{
	    background-color: #f1f1f1;
    padding-bottom: 10px;
    display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
	display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
    list-style-type: none;
}
.sectionHeading h2 {
    font-size: 14px;
    font-weight: 700;
    float: left;
    width: 450px;
	font-family: inherit;
	line-height: 20px;

}
a, button, input {
	outline: medium none !important;
    color: initial;
}
.tab.tab-icon .nav-tabs li {
    width: 16.667%;
    text-align: center;
    float: left;
    position: relative;
}
</style>
<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
      <div class="col-md-12">
        <div class="tab tab-icon clearfix"> 
          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li>
				<a href="{{URL::to('/editprofilephotos')}}" >
					<span>Photos</span>
				</a>
				
			</li>
            <li>
				<a href="{{URL::to('/editmyprofile')}}">
					<span>Profile</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editmatchinfo')}}">
					<span>Match</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editinterestinfo')}}" class="active">
					<span>Interest</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/editpersonalityinfo')}}">
					<span>Personality</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/verifyprofile')}}" >
					<span>Verify Profile</span>
				</a>
			</li>
          </ul>
          <!-- Tab panes -->
			<div class="tab-content">
				@if(session('success'))
					<div class="alert alert-success" role="alert">{{session('success')}}</div>
				@endif
				@if(session('errors'))
					<div class="alert alert-danger" role="alert">{{session('errors')}}</div>
				@endif
				<div role="tabpanel" class="tab-pane fade active in" id="tab2-1">
					<p class="mb-1">
						Let others know what your interests are and help us connect you with other users that may have similar interests. Answer all questions below to complete this step.
					</p>
					<span class="sectionHeading clearfix">
						<h2>Edit Hobbies & Interests</h2>
					</span>
					<form method="post" data-parsley-validate="">
					@csrf
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-4">What do you do for fun / entertainment?</div>  
								<div class="col-md-8">
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="antiques" id="antiques" value="Antiques" @if(!empty($interestInfo->antiques)) checked @endif>Antiques
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="art_painting" id="art_painting" value="Art / Painting" @if(!empty($interestInfo->art_painting)) checked @endif>Art / Painting
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="astrology" id="astrology" value="Astrology" @if(!empty($interestInfo->astrology)) checked @endif>Astrology
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="ballet" id="ballet" value="Ballet" @if(!empty($interestInfo->ballet)) checked @endif>Ballet
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="bars_pubs_nightclubs" id="bars_pubs_nightclubs" value="Bars / Pubs / Nightclubs" @if(!empty($interestInfo->bars_pubs_nightclubs)) checked @endif>Bars / Pubs / Nightclubs
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="beach_parks" id="beach_parks" value="Beach Parks" @if(!empty($interestInfo->beach_parks)) checked @endif>Beach Parks
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="board_card_game" id="board_card_game" value="Board / Card Games" @if(!empty($interestInfo->board_card_game)) checked @endif>Board / Card Games
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="camping" id="camping" value="Camping / Nature" @if(!empty($interestInfo->camping)) checked @endif>Camping / Nature
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="cars_mechanics" id="cars_mechanics" value="Cars / Mechanics"  @if(!empty($interestInfo->cars_mechanics)) checked @endif>Cars / Mechanics
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="casino_gambling" id="casino_gambling" value="Casino / Gambling"  @if(!empty($interestInfo->casino_gambling)) checked @endif>Casino / Gambling
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="collecting" id="collecting" value="Collecting"  @if(!empty($interestInfo->collecting)) checked @endif>Collecting
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="comedy_clubs" id="comedy_clubs" value="Comedy Clubs"  @if(!empty($interestInfo->comedy_clubs)) checked @endif>Comedy Clubs
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="computer_internet" id="computer_internet" value="Computers / Internet"  @if(!empty($interestInfo->computer_internet)) checked @endif>Computers / Internet
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="concerts_live_music" id="concerts_live_music" value="Concerts / Live Music"  @if(!empty($interestInfo->concerts_live_music)) checked @endif>Concerts / Live Music
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="cooking_food" id="cooking_food" value="Cooking / Food and Wine"  @if(!empty($interestInfo->cooking_food)) checked @endif>Cooking / Food and Wine
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="crafts" id="crafts" value="Crafts"  @if(!empty($interestInfo->crafts)) checked @endif>Crafts
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="dancing" id="dancing" value="Dancing"  @if(!empty($interestInfo->dancing)) checked @endif>Dancing
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="dining_out" id="dining_out" value="Dining Out"  @if(!empty($interestInfo->dining_out)) checked @endif>Dining Out
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="dancing_parties" id="dancing_parties" value="Dinner Parties"  @if(!empty($interestInfo->dancing_parties)) checked @endif>Dinner Parties
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="education" id="education" value="Education"  @if(!empty($interestInfo->education)) checked @endif>Education
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="family" id="family" value="Family" @if(!empty($interestInfo->family)) checked @endif>Family
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="fashion_events" id="fashion_events" value="Fashion Events" @if(!empty($interestInfo->fashion_events)) checked @endif>Fashion Events
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="gardening" id="gardening" value="Gardening / Landscaping" @if(!empty($interestInfo->gardening)) checked @endif>Gardening / Landscaping
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="home_improvement" id="home_improvement" value="Home Improvement" @if(!empty($interestInfo->home_improvement)) checked @endif>Home Improvement
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="investing_finance" id="investing_finance" value="Investing / Finance" @if(!empty($interestInfo->investing_finance)) checked @endif>Investing / Finance
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="karaoke_sing_along" id="karaoke_sing_along" value="Karaoke / Sing-along" @if(!empty($interestInfo->karaoke_sing_along)) checked @endif>Karaoke / Sing-along
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="library" id="library" value="Library" @if(!empty($interestInfo->library)) checked @endif>Library
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="meditation" id="meditation" value="Meditation" @if(!empty($interestInfo->meditation)) checked @endif>Meditation
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="motorcycles" id="motorcycles" value="Motorcycles" @if(!empty($interestInfo->motorcycles)) checked @endif>Motorcycles
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="movies_cinema" id="movies_cinema" value="Movies / Cinema" @if(!empty($interestInfo->movies_cinema)) checked @endif>Movies / Cinema
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="museums" id="museums" value="Museums / Galleries" @if(!empty($interestInfo->museums)) checked @endif>Museums / Galleries
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="music_listening" id="music_listening" value="Music (Listening)" @if(!empty($interestInfo->music_listening)) checked @endif>Music (Listening)
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="music_playing" id="music_playing" value="Music (Playing)" @if(!empty($interestInfo->music_playing)) checked @endif>Music (Playing)
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="news_politics" id="news_politics" value="News / Politics" @if(!empty($interestInfo->news_politics)) checked @endif>News / Politics
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="pets" id="pets" value="Pets" @if(!empty($interestInfo->pets)) checked @endif>Pets
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="philosophy_spirituality" id="philosophy_spirituality" value="Philosophy / Spirituality" @if(!empty($interestInfo->philosophy_spirituality)) checked @endif>Philosophy / Spirituality
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="photography" id="photography" value="Photography" @if(!empty($interestInfo->photography)) checked @endif>Photography
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="poetry" id="poetry" value="Poetry" @if(!empty($interestInfo->poetry)) checked @endif>Poetry
											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="reading" id="reading" value="Reading" @if(!empty($interestInfo->reading)) checked @endif>Reading
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="science_and_technology" id="science_and_technology" value="Science and Technology" @if(!empty($interestInfo->science_and_technology)) checked @endif>Science and Technology

											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="shopping" id="shopping" value="Shopping" @if(!empty($interestInfo->shopping)) checked @endif>Shopping
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="social_causes_activism" id="social_causes_activism" value="Social Causes / Activism" @if(!empty($interestInfo->social_causes_activism)) checked @endif>Social Causes / Activism

											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="tv_education_news" id="tv_education_news" value="TV: Educational / News" @if(!empty($interestInfo->tv_education_news)) checked @endif>TV: Educational / News
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="tv_entertainment" id="tv_entertainment" value="TV: Entertainment" @if(!empty($interestInfo->tv_entertainment)) checked @endif>TV: Entertainment

											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="theatre" id="theatre" value="Theatre" @if(!empty($interestInfo->theatre)) checked @endif>Theatre
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="traveling" id="traveling" value="Traveling" @if(!empty($interestInfo->traveling)) checked @endif>Traveling

											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="video_online_game" id="video_online_game" value="Video / Online Games" @if(!empty($interestInfo->video_online_game)) checked @endif>Video / Online Games
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="volunteering" id="volunteering" value="Volunteering" @if(!empty($interestInfo->volunteering)) checked @endif>Volunteering

											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="watching_sports" id="watching_sports" value="Watching Sports" @if(!empty($interestInfo->watching_sports)) checked @endif>Watching Sports
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="wine_tasting" id="wine_tasting" value="Wine Tasting" @if(!empty($interestInfo->wine_tasting)) checked @endif>Wine Tasting

											</label>
										</div>
									</div>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="writing" id="writing" value="Writing" @if(!empty($interestInfo->writing)) checked @endif>Writing
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="other_fun" id="other_fun" value="Other" @if(!empty($interestInfo->other_fun)) checked @endif>Other
											</label>
										</div>
									</div>
									
								</div>
							</div>
						</div>
						
						<div style="text-align:center;" class="col-md-12">
							<button type="submit" class="btn btn-success">Save</button>
						</div>
					</form>	
				</div>
           </div>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection
