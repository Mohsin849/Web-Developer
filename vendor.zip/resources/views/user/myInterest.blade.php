@extends('layouts.app')
@section('content')

<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
		<div class="col-md-12">
		@foreach($myInterest as $item)
		
		<div class="card card-horizontal float-left deleteInterestedme{{$item['id']}}" style="width: 365px; margin-left:15px;">
		  <div class="row">
			<div class="activity-profile-image circle border relative flex-none me2" data-effect="grayscale" style="margin-top: 5px;margin-left: 12px;">
				<div class="flex items-center height-12 circle overflow-hidden card-image-bg-color">
					<a class="flex items-center col-12 height-12" href="/en/profile/showProfile/ID/14211683?searchposition=1&amp;searchtotal=12"> 
						@if($item['user']['avatar_1'] == '')
							@php $avatorImage = 'avatar-1.png'; @endphp
						@else
							@php $avatorImage = $item['user']['avatar_1']; @endphp
						@endif
						<div class="profile-bg overflow-hidden circle" 
							 data-cm-modal-url="" 
							 style="background-image:url('{{URL::to('/')}}/resources/assets/images/profile/{{$avatorImage}}')"></div>
					</a>
				</div>
            </div>
			
			<div class="col-sm-7">
			  <div class="flex flex-column flex-auto overflow-hidden">
				<h3 class="h3 color-dark-grey inline-block align-middle m0 truncate font-famly-rebort">{{$item['user']['name']}}</h3>
				<div class="h5 truncate font-famly-rebort">{{$item['user']['age']}} @if(!empty($item['user']['age'])).@endif  Cebu City, Cebu, Philippines</div>
				<div class="h5 mt1 text-truncate-multi text-truncate-multi-2 font-famly-rebort">Seeking: @if($item['userMatch']['gender'] == 1) Male @else Female @endif {{$item['userMatch']['age_min']}} - {{$item['userMatch']['age_max']}}
				<br /><span class="color-medium-grey">Last active: {{$item['user']['last_login']}}</span></div>
                <div class="h5 my1 text-truncate-multi text-truncate-multi-2"><span class="bold">Sent:</span>: {{$item['created_at']}}</div>
				<p class=" h4" style="color:#505656">
                    <a  title="You showed interest in {{$item['user']['name']}} {{$item['created_at']}}">
						<span style="color:red;" class="heart17 fa fa-heart float-left"></span>
					</a>
					<i class="fa fa-envelope ml-2"></i>
					<?php $countImages =0; ?>
						@if(!empty($item['user']['avatar_2']))
						    <?php $countImages++; ?>
						@endif
						@if(!empty($item['user']['avatar_3']))
						    <?php $countImages++; ?>
						@endif
						@if(!empty($item['user']['avatar_4']))
						    <?php $countImages++; ?>
						@endif
						@if(!empty($item['user']['avatar_5']))
						    <?php $countImages++; ?>
						@endif
					<span class="fa fa-camera ml-2"></span>
					<span class="ml-2">{{$countImages}}</span>
					<span class="fa fa-trash float-right deleteInterestedme" id="{{$item['id']}}" style="color: red;"></span>
				</p>
			  </div>
			</div>
		  </div>
		</div>
		@endforeach
		<input type="hidden" name="fieldType" id="fieldType" value="1">
	  
	  </div>
    </div>
  </div>
</section>
@endsection
