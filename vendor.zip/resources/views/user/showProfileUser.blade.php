@extends('layouts.app')
@section('content')
<section class="page-section-ptb pb-50 sm-pb-0 columns-section">
        <div class="container">

            <div class="row">

                <div class="col-md-5">
                    @if($userProfile->avatar_1 == '')
                    <img src="{{URL::to('/')}}/resources/assets/images/profile/avatar-1.png" class="img-fluid">
                    @else
                    <img src="{{URL::to('/')}}/resources/assets/images/profile/{{$userProfile->avatar_1}}" class="img-fluid">
                    @endif
                </div>

                <div class="col-md-7">
					
                    <h3 class="font-weight-bold mt-1">{{$userProfile->name}}</h3>
                    <p class="mt-1">{{$userProfile->age}} <span>•</span> {{@$cityList->name}},{{@$countryList->name}} </p>
                    <p> @if($userProfile->gender == 1)
							Male /
						@else
							FeMale /
						@endif
					<span class="font-weight-bold">ID: 14047644</span> </p>
                    <p>Seeking Female 20 - 35</p>
                    <p>I'm Online</p>
                    @if(Auth::user()->id != $userProfile->id)
						@if($myInterest > 0)
							<a class="pull-right" title="You showed interest in {{$userProfile->name}}" style="float: right;
							font-size: 25px;"><span style="color:red;" class="fa fa-heart float-left"></span></a>
						@else
							<a id="{{$userProfile->id}}" class="interestedme interestedme{{$userProfile->id}} pull-right " style="float: right;
							font-size: 25px;" title="Show interest in {{$userProfile->name}}"><span class="heart{{$userProfile->id}} fa fa-heart float-left"></span></a>
						@endif
					    @if($blockUser > 0)
							<a class="pull-right " style="float: right;
							font-size: 25px;" title="Block User"><span style="color:red;" class="fa fa-ban float-left"></span></a>
						@else
							<a id="{{$userProfile->id}}" class="blockUser blockUser{{$userProfile->id}} pull-right " style="float: right;
							font-size: 25px;" title="Block User"><span class="block{{$userProfile->id}} fa fa-ban float-left"></span></a>
						@endif
						
						@if($favoriteUser > 0)
							<a class="pull-right " style="float: right;
							font-size: 25px;" ><span style="color:red;" class="fa fa-star float-left"></span></a>
						@else
							<a id="{{$userProfile->id}}" class="favoritUser favoritUser{{$userProfile->id}} pull-right " style="float: right;
							font-size: 25px;" title="Add {{$userProfile->name}} to your favorites"><span class="favorit{{$userProfile->id}} fa fa-star float-left"></span></a>
						@endif
						
    
					
 @endif
                    <table class="table table-sm table-striped">
                        <thead class="bg-warning">
                            <tr class="text-center">
                                <th>Overview</th>
                                <th>{{$userProfile->name}}</th>
                                <th>He's Looking For</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="tr-bg text-center">
                                <td class="font-weight-bold">Education:</td>
                                <td>
									@if(!empty($userBackground->education))
									{{$userBackground->education}}
									@else
										No Answer
									@endif
									</td>
                                <td>
									@if(!empty($userMatch->education))
									{{$userMatch->education}}
									@else
										Any
									@endif
								</td>
                            </tr>
                            <tr class="text-center">
                                <td class="font-weight-bold ">Have children:</td>
                                <td>
									@if(!empty($userLifestyle->children_have))
										{{$userLifestyle->children_have}}
									@else
										No Answer
									@endif
								</td>
                                <td>
									@if(!empty($userMatch->have_children))
										{{$userMatch->have_children}}
									@else
										Any
									@endif
								</td>
                            </tr>
                            <tr class="tr-bg text-center">
                                <td class="font-weight-bold">Drink:</td>
                                <td>
									@if(!empty($userLifestyle->drink))
										{{$userLifestyle->drink}}
									@else
										No Answer
									@endif
								</td>
                                <td>
									@if(!empty($userMatch->drink))
										{{$userMatch->drink}}
									@else
										Any
									@endif
								</td>
                            </tr>
                            <tr class="tr-bg text-center">
                                <td class="font-weight-bold">Smoke:</td>
                                <td>
									@if(!empty($userLifestyle->smoke))
										{{$userLifestyle->smoke}}
									@else
										No Answer
									@endif
								</td>
                                <td>
									@if(!empty($userMatch->smoke))
										{{$userMatch->smoke}}
									@else
										Any
									@endif
								</td>
                            </tr>
                            <tr class="tr-bg text-center">
                                <td class="font-weight-bold">Religion:</td>
                                <td>
									@if(!empty($userBackground->religion))
										{{$userBackground->religion}}
									@else
										No Answer
									@endif
									
								</td>
                                <td>
									@if(!empty($userMatch->religion))
										{{$userMatch->religion}}
									@else
										Any
									@endif
								</td>
                            </tr>
                            <tr class="tr-bg text-center">
                                <td class="font-weight-bold">Occupation:</td>
                                <td>
									@if(!empty($userLifestyle->occupation))
									{{$userLifestyle->occupation}}
									@else
										No Answer
									@endif
								</td>
                                <td>
									@if(!empty($userMatch->occupation))
										{{$userMatch->occupation}}
									@else
										Any
									@endif
								</td>
                            </tr>
                        </tbody>
                    </table>




                </div>

            </div>
            <h3 class="mt-3">Member Overview</h3>
            <p>{{$userProfile->about_yourself}}</p>

            <h3 class="mt-3">Seeking</h3>
            <p>{{$userProfile->looking_partner}}</p>

            <h3 class="mt-3">More About Me</h3>

            <h4 class="mt-3 h4">Basic</h4>
            <table class="table table-sm mt-3 table-striped">
                <thead class="bg-warning">
                    <tr class="text-center">
                        <th>Overview</th>
                        <th>{{$userProfile->name}}</th>
                        <th>He's Looking For</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Gender:</td>
                        <td>
							@if($userProfile->gender == 1)
								Male
							@else
								FeMale
							@endif
						</td>
                        <td>
							@if(!empty($userMatch->gender))
								@if($userMatch->gender == 1)
									Male
								@else
									FeMale
								@endif
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="text-center">
                        <td class="font-weight-bold ">Age:</td>
                        <td>
							@if(!empty($userProfile->age))
								{{$userProfile->age}}
							@else
								No Answer
							@endif
						</td>
                        <td>
							@if(!empty($userMatch->age_min))
								{{$userMatch->age_min}} - {{$userMatch->age_max}}
							@else
								Any
							@endif
						</td>
                    </tr>
					
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Lives in: </td>
                        <td>
						@if(!empty(@$cityList->name) || !empty(@$countryList->name))
							{{@$cityList->name}},{{@$countryList->name}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							
								Any
							
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Relocate:</td>
                        <td>
						@if(!empty($userLifestyle->relocate))
							{{$userLifestyle->relocate}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->relocate))
								{{$userMatch->relocate}}
							@else
								Any
							@endif
						</td>
                    </tr>
                </tbody>
            </table>

            <h3 class="mt-3">Appearence</h3>
            <table class="table table-sm mt-3 table-striped">
                <thead class="bg-warning">
                    <tr class="text-center">
                        <th>Overview</th>
                        <th>
						@if(!empty($userProfile->name))
							{{$userProfile->name}}
						@else
							No Answer
						@endif
						</th>
                        <th>He's Looking For</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Hair color:</td>
                        <td>
						@if(!empty($userAppericens->hair_color))
							{{$userAppericens->hair_color}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->hair_color))
								{{$userMatch->hair_color}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="text-center">
                        <td class="font-weight-bold ">Hair length:</td>
                        <td>
						@if(!empty($userAppericens->hair_length))
							{{$userAppericens->hair_length}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->hair_length))
								{{$userMatch->hair_length}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Hair type:</td>
                        <td>
						@if(!empty($userAppericens->hair_type))
							{{$userAppericens->hair_type}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->hair_type))
								{{$userMatch->hair_type}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Eye color:</td>
                        <td>
						@if(!empty($userAppericens->eye_color))
							{{$userAppericens->eye_color}}
						@else
							No Answer
						@endif	
						</td>
                        <td>
							@if(!empty($userMatch->eye_color))
								{{$userMatch->eye_color}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Eye wear:</td>
                        <td>
						@if(!empty($userAppericens->eye_wear))
							{{$userAppericens->eye_wear}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->eye_wear))
								{{$userMatch->eye_wear}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Height:</td>
                        <td>
							@if(!empty($userAppericens->height))
								{{$userAppericens->height}}
							@else
								No Answer
							@endif
						</td>
                        <td>
							@if(!empty($userMatch->height_min))
								{{$userMatch->height_min}} - {{$userMatch->height_max}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Weight:</td>
                        <td>
						@if(!empty($userAppericens->weight))
							{{$userAppericens->weight}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->weight_min))
								{{$userMatch->weight_min}} - {{$userMatch->weight_max}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Body style:</td>
                        <td>
						@if(!empty($userAppericens->body_type))
							{{$userAppericens->body_type}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->body_type))
								{{$userMatch->body_type}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Ethnicity:</td>
                        <td>
						@if(!empty($userAppericens->ethnicity))
							{{$userAppericens->ethnicity}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->ethnicity))
								{{$userMatch->ethnicity}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Facial hair:</td>
                        <td>
						@if(!empty($userAppericens->facial_hair))
							{{$userAppericens->facial_hair}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->hair_type))
								{{$userMatch->hair_type}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Best feature:</td>
                        <td>
						@if(!empty($userAppericens->best_feature))
							{{$userAppericens->best_feature}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->best_feature))
								{{$userMatch->best_feature}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Body art:</td>
                        <td>
						@if(!empty($userAppericens->body_art))
							{{$userAppericens->body_art}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->body_art))
								{{$userMatch->body_art}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Appearance:</td>
                        <td>
						@if(!empty($userAppericens->appearance))
							{{$userAppericens->appearance}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->appearance))
								{{$userMatch->appearance}}
							@else
								Any
							@endif
						</td>
                    </tr>
                </tbody>
            </table>
			<h3 class="mt-3">Lifestyle</h3>
            <table class="table table-sm mt-3 table-striped">
                <thead class="bg-warning">
                    <tr class="text-center">
                        <th>Overview</th>
                        <th>{{$userProfile->name}}</th>
                        <th>He's Looking For</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Drink:</td>
                        <td>
						@if(!empty($userLifestyle->drink))
							{{$userLifestyle->drink}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->drink))
								{{$userMatch->drink}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="text-center">
                        <td class="font-weight-bold ">Smoke:</td>
                        <td>
						@if(!empty($userLifestyle->smoke))
							{{$userLifestyle->smoke}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->smoke))
								{{$userMatch->smoke}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Marital Status:</td>
                        <td>
						@if(!empty($userLifestyle->marital_status))
							{{$userLifestyle->marital_status}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->marital_status))
								{{$userMatch->marital_status}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Have children:</td>
                        <td>
						@if(!empty($userLifestyle->children_have))
							{{$userLifestyle->children_have}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->have_children))
								{{$userMatch->have_children}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Number of children:</td>
                        <td>
						@if(!empty($userLifestyle->children_number))
							{{$userLifestyle->children_number}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->number_of_children))
								{{$userMatch->number_of_children}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Oldest child:</td>
                        <td>
						@if(!empty($userLifestyle->children_oldest))
							{{$userLifestyle->children_oldest}}
						@else
							No Answer
						@endif
						</td>
                        <td>Any</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Youngest child:</td>
                        <td>
						@if(!empty($userLifestyle->youngest_child))
							{{$userLifestyle->youngest_child}}
						@else
							No Answer
						@endif
						</td>
                        <td>Any</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Want (more) children:</td>
                        <td>
						@if(!empty($userLifestyle->children_want))
							{{$userLifestyle->children_want}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->more_children))
								{{$userMatch->more_children}}
							@else
								Any
							@endif
						</td>
                    </tr>
					
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Occupation:</td>
                        <td>
						@if(!empty($userLifestyle->occupation))
							{{$userLifestyle->occupation}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->occupation))
								{{$userMatch->occupation}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Employment status:</td>
                        <td>
						@if(!empty($userLifestyle->employment_status))
							{{$userLifestyle->employment_status}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->employment_status))
								{{$userMatch->employment_status}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Income:</td>
                        <td>
						@if(!empty($userLifestyle->home_type))
							{{$userLifestyle->home_type}}
						@else
							No Answer
						@endif
						</td>
                        <td>Any</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Home type:</td>
                        <td>
						@if(!empty($userLifestyle->living_situation))
							{{$userLifestyle->living_situation}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->home_type))
								{{$userMatch->home_type}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Living situation:</td>
                        <td>
						@if(!empty($userLifestyle->relocate))
							{{$userLifestyle->relocate}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->living_situation))
								{{$userMatch->living_situation}}
							@else
								Any
							@endif
						</td>
                    </tr>
                </tbody>
            </table>
			<h3 class="mt-3">Background / Cultural Values</h3>
            <table class="table table-sm mt-3 table-striped">
                <thead class="bg-warning">
                    <tr class="text-center">
                        <th>Overview</th>
                        <th>{{$userProfile->name}}</th>
                        <th>He's Looking For</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Nationality:</td>
                        <td>
						@if(!empty($userBackground->nationality))
							{{$userBackground->nationality}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->nationality))
								{{$userMatch->nationality}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="text-center">
                        <td class="font-weight-bold ">Education:</td>
                        <td>
						@if(!empty($userBackground->education))
							{{$userBackground->education}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->education))
								{{$userMatch->education}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">English ability:</td>
                        <td>
						@if(!empty($userBackground->english_ability))
							{{$userBackground->english_ability}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->language_ability))
								{{$userMatch->language_ability}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Religion:</td>
                        <td>
						@if(!empty($userBackground->religion))
							{{$userBackground->religion}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->religion))
								{{$userMatch->religion}}
							@else
								Any
							@endif
						</td>
                    </tr>
                    <tr class="tr-bg text-center">
                        <td class="font-weight-bold">Religious values: </td>
                        <td>
						@if(!empty($userBackground->religion_values))
							{{$userBackground->religion_values}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->religious_values))
								{{$userMatch->religious_values}}
							@else
								Any
							@endif
						</td>
                    </tr>
					<tr class="tr-bg text-center">
                        <td class="font-weight-bold">Star sign: </td>
                        <td>
						@if(!empty($userBackground->star_sign))	
							{{$userBackground->star_sign}}
						@else
							No Answer
						@endif
						</td>
                        <td>
							@if(!empty($userMatch->star_ssign))
								{{$userMatch->star_ssign}}
							@else
								Any
							@endif
						</td>
                    </tr>
				</tbody>
            </table>
			
			<div class="sm-col-10 lg-col-9 content-max-width mx-auto mb3 pt-3 line-height-4">
				<div class="max-width-3">
					<h4 class="mb1">Safety Tip - Beware of fake photos</h4>
					Some scammers from Ghana, Nigeria, Russia or other countries will email or share fake photos with you. Always request as many photos of the person as possible and try to receive photos in many different situations such as at home, at work, at events, with other people etc. Most scammers will send only a small number of photos and usually photos that are not in a group setting. It is very important to also verify the appearance of the person by chatting on webcam. 
					<div class="mt2">
					  <a class="button rounded py1 px2 relative overflow-hidden bg-light-grey color-dark-grey" href="#;">For more safety tips click here</a>
					</div>
				</div>
			</div>

        </div>
    </section>

@endsection
