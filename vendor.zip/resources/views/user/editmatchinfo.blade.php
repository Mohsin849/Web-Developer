@extends('layouts.app')
@section('content')
<style>
.sectionHeading{
	    background-color: #f1f1f1;
    padding-bottom: 10px;
    display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
	display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
    list-style-type: none;
}
.sectionHeading h2 {
    font-size: 14px;
    font-weight: 700;
    float: left;
    width: 450px;
	font-family: inherit;
	line-height: 20px;

}
a, button, input {
	outline: medium none !important;
    color: initial;
}
.tab.tab-icon .nav-tabs li {
    width: 16.667%;
    text-align: center;
    float: left;
    position: relative;
}
</style>
<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
      <div class="col-md-12">
        <div class="tab tab-icon clearfix"> 
          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li>
				<a href="{{URL::to('/editprofilephotos')}}" >
					<span>Photos</span>
				</a>
				
			</li>
            <li>
				<a href="{{URL::to('/editmyprofile')}}">
					<span>Profile</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editmatchinfo')}}" class="active">
					<span>Match</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editinterestinfo')}}" >
					<span>Interest</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/editpersonalityinfo')}}" >
					<span>Personality</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/verifyprofile')}}" >
					<span>Verify Profile</span>
				</a>
			</li>
          </ul>
          <!-- Tab panes -->
			<div class="tab-content">
				@if(session('success'))
					<div class="alert alert-success" role="alert">{{session('success')}}</div>
				@endif
				@if(session('errors'))
					<div class="alert alert-danger" role="alert">{{session('errors')}}</div>
				@endif
				<div role="tabpanel" class="tab-pane fade active in" id="tab2-1">
					<p class="mb-1">
						Let your personality shine. Express yourself in your own words to give other users a better understanding of who you are. Answer at least 7 questions below to complete this section.
					</p>
					<span class="sectionHeading clearfix">
						<h2>Their Basic Details</h2>
					</span>
					<form method="post" data-parsley-validate="">
					@csrf
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">I'm seeking a:</div>  
								<div class="col-md-6">
									<select name="gender" id ="gender" class="">
										<option value="1" @if($useMatch->gender == 1)selected="selected" @endif>Male</option>
										<option value="2" @if($useMatch->gender == 2)selected="selected" @endif>Female</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Aged between:</div>  
								<div class="col-md-6">
									<select name="age_min" id ="age_min" class="">
										<option value="18" @if($useMatch->age_min == 18)selected="selected" @endif>18</option>
										<option value="19" @if($useMatch->age_min == 19)selected="selected" @endif>19</option>
										<option value="20" @if($useMatch->age_min == 20)selected="selected" @endif>20</option>
										<option value="21" @if($useMatch->age_min == 21)selected="selected" @endif>21</option>
										<option value="22" @if($useMatch->age_min == 22)selected="selected" @endif>22</option>
										<option value="23" @if($useMatch->age_min == 23)selected="selected" @endif>23</option>
										<option value="24" @if($useMatch->age_min == 24)selected="selected" @endif>24</option>
										<option value="25" @if($useMatch->age_min == 25)selected="selected" @endif>25</option>
										<option value="26" @if($useMatch->age_min == 26)selected="selected" @endif>26</option>
										<option value="27" @if($useMatch->age_min == 27)selected="selected" @endif>27</option>
										<option value="28" @if($useMatch->age_min == 28)selected="selected" @endif>28</option>
										<option value="29" @if($useMatch->age_min == 29)selected="selected" @endif>29</option>
										<option value="30" @if($useMatch->age_min == 30)selected="selected" @endif>30</option>
										<option value="31" @if($useMatch->age_min == 31)selected="selected" @endif>31</option>
										<option value="32" @if($useMatch->age_min == 32)selected="selected" @endif>32</option>
										<option value="33" @if($useMatch->age_min == 33)selected="selected" @endif>33</option>
										<option value="34" @if($useMatch->age_min == 34)selected="selected" @endif>34</option>
										<option value="35" @if($useMatch->age_min == 35)selected="selected" @endif>35</option>
										<option value="36" @if($useMatch->age_min == 36)selected="selected" @endif>36</option>
										<option value="37" @if($useMatch->age_min == 37)selected="selected" @endif>37</option>
										<option value="38" @if($useMatch->age_min == 38)selected="selected" @endif>38</option>
										<option value="39" @if($useMatch->age_min == 39)selected="selected" @endif>39</option>
										<option value="40" @if($useMatch->age_min == 40)selected="selected" @endif>40</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Country</div>  
								<div class="col-md-6">
									<select class="" name="country" id="country" onchange="getState(this);" >
										<option value="">Country</option>
										@foreach($countryList as $item)
											<option value="{{$item->id}}" @if($item->id == $useMatch->country)selected="selected" @endif>{{$item->name}}</option>
										@endforeach
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">State</div>  
								<div class="col-md-6">
									<select class="" name="state" id="state" onchange="getCity(this);" >
										<option value="">State</option>
										@foreach($stateList as $item)
											<option value="{{$item->id}}" @if($item->id == $useMatch->state)selected="selected" @endif>{{$item->name}}</option>
										@endforeach
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">City</div>  
								<div class="col-md-6">
									<select class="" name="city" id="city" >
										<option value="">City</option>
										@foreach($cityList as $item)
											<option value="{{$item->id}}" @if($item->id == $useMatch->city)selected="selected" @endif>{{$item->name}}</option>
										@endforeach
									</select>
								</div>
							</div>
						</div>
						<span class="sectionHeading clearfix">
						<h2>Their Appearance</h2>
					</span>
					<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Height:</div>  
								<div class="col-md-6">
									<select class="" name="height_min" id="height" >
										<option value="">Please Select</option>
										<option value="1" @if($useMatch->height_min == 1)selected="selected" @endif>4'7" (140 cm)</option>
										<option value="2" @if($useMatch->height_min == 2)selected="selected" @endif>4'8" (143 cm)</option>
										<option value="3" @if($useMatch->height_min == 3)selected="selected" @endif>4'9" (145 cm)</option>
										<option value="4" @if($useMatch->height_min == 4)selected="selected" @endif>4'10" (148 cm)</option>
										<option value="5" @if($useMatch->height_min == 5)selected="selected" @endif>4'11" (150 cm)</option>
										<option value="6" @if($useMatch->height_min == 6)selected="selected" @endif>5' (153 cm)</option>
										<option value="7" @if($useMatch->height_min == 7)selected="selected" @endif>5'1" (155 cm)</option>
										<option value="8" @if($useMatch->height_min == 8)selected="selected" @endif>5'2" (158 cm)</option>
										<option value="9" @if($useMatch->height_min == 9)selected="selected" @endif>5'3" (161 cm)</option>
										<option value="10" @if($useMatch->height_min == 10)selected="selected" @endif>5'4" (163 cm)</option>
										<option value="11" @if($useMatch->height_min == 11)selected="selected" @endif>5'5" (166 cm)</option>
										<option value="12" @if($useMatch->height_min == 12)selected="selected" @endif>5'6" (168 cm)</option>
										<option value="13" @if($useMatch->height_min == 13)selected="selected" @endif>5'7" (171 cm)</option>
										<option value="14" @if($useMatch->height_min == 14)selected="selected" @endif>5'8" (173 cm)</option>
										<option value="15" @if($useMatch->height_min == 15)selected="selected" @endif>5'9" (176 cm)</option>
										<option value="16" @if($useMatch->height_min == 16)selected="selected" @endif>5'10" (178 cm)</option>
										<option value="17" @if($useMatch->height_min == 17)selected="selected" @endif>5'11" (181 cm)</option>
										<option value="18" @if($useMatch->height_min == 18)selected="selected" @endif>6' (183 cm)</option>
										<option value="19" @if($useMatch->height_min == 19)selected="selected" @endif>6'1" (186 cm)</option>
										<option value="20" @if($useMatch->height_min == 20)selected="selected" @endif>6'2" (188 cm)</option>
										<option value="21" @if($useMatch->height_min == 21)selected="selected" @endif>6'3" (191 cm)</option>
										<option value="22" @if($useMatch->height_min == 22)selected="selected" @endif>6'4" (194 cm)</option>
										<option value="23" @if($useMatch->height_min == 23)selected="selected" @endif>6'5" (196 cm)</option>
										<option value="24" @if($useMatch->height_min == 24)selected="selected" @endif>6'6" (199 cm)</option>
										<option value="25" @if($useMatch->height_min == 25)selected="selected" @endif>6'7" (201 cm)</option>
										<option value="26" @if($useMatch->height_min == 26)selected="selected" @endif>6'8" (204 cm)</option>
										<option value="27" @if($useMatch->height_min == 27)selected="selected" @endif>6'9 (206 cm)</option>
										<option value="28" @if($useMatch->height_min == 28)selected="selected" @endif>6'10" (209 cm)</option>
										<option value="29" @if($useMatch->height_min == 29)selected="selected" @endif>6'11" (211 cm)</option>
										<option value="30" @if($useMatch->height_min == 30)selected="selected" @endif>7' (214 cm)</option>
										<option value="31" @if($useMatch->height_min == 31)selected="selected" @endif>7'1" (216 cm)</option>
										<option value="32" @if($useMatch->height_min == 32)selected="selected" @endif>7'2" (219 cm)</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Weight:</div>  
								<div class="col-md-6">
									<select class="" name="weight_min" id="weight" >
										<option value="">Please Select</option>
										<option value="40" @if($useMatch->weight_min == 40)selected="selected" @endif>40 kg (88 lb)</option>
										<option value="41" @if($useMatch->weight_min == 41)selected="selected" @endif>41 kg (90 lb)</option>
										<option value="42" @if($useMatch->weight_min == 42)selected="selected" @endif>42 kg (93 lb)</option>
										<option value="43" @if($useMatch->weight_min == 43)selected="selected" @endif>43 kg (95 lb)</option>
										<option value="44" @if($useMatch->weight_min == 44)selected="selected" @endif>44 kg (97 lb)</option>
										<option value="45" @if($useMatch->weight_min == 45)selected="selected" @endif>45 kg (99 lb)</option>
										<option value="46" @if($useMatch->weight_min == 46)selected="selected" @endif>46 kg (101 lb)</option>
										<option value="47" @if($useMatch->weight_min == 47)selected="selected" @endif>47 kg (104 lb)</option>
										<option value="48" @if($useMatch->weight_min == 48)selected="selected" @endif>48 kg (106 lb)</option>
										<option value="49" @if($useMatch->weight_min == 49)selected="selected" @endif>49 kg (108 lb)</option>
										<option value="50" @if($useMatch->weight_min == 50)selected="selected" @endif>50 kg (110 lb)</option>
										<option value="51" @if($useMatch->weight_min == 51)selected="selected" @endif>51 kg (112 lb)</option>
										<option value="52" @if($useMatch->weight_min == 52)selected="selected" @endif>52 kg (115 lb)</option>
										<option value="53" @if($useMatch->weight_min == 53)selected="selected" @endif>53 kg (117 lb)</option>
										<option value="54" @if($useMatch->weight_min == 54)selected="selected" @endif>54 kg (119 lb)</option>
										<option value="55" @if($useMatch->weight_min == 55)selected="selected" @endif>55 kg (121 lb)</option>
										<option value="56" @if($useMatch->weight_min == 56)selected="selected" @endif>56 kg (123 lb)</option>
										<option value="57" @if($useMatch->weight_min == 57)selected="selected" @endif>57 kg (126 lb)</option>
										<option value="58" @if($useMatch->weight_min == 58)selected="selected" @endif>58 kg (128 lb)</option>
										<option value="59" @if($useMatch->weight_min == 59)selected="selected" @endif>59 kg (130 lb)</option>
										<option value="60" @if($useMatch->weight_min == 60)selected="selected" @endif>60 kg (132 lb)</option>
										<option value="61" @if($useMatch->weight_min == 61)selected="selected" @endif>61 kg (134 lb)</option>
										<option value="62" @if($useMatch->weight_min == 62)selected="selected" @endif>62 kg (137 lb)</option>
										<option value="63" @if($useMatch->weight_min == 63)selected="selected" @endif>63 kg (139 lb)</option>
										<option value="64" @if($useMatch->weight_min == 64)selected="selected" @endif>64 kg (141 lb)</option>
										<option value="65" @if($useMatch->weight_min == 65)selected="selected" @endif>65 kg (143 lb)</option>
										<option value="66" @if($useMatch->weight_min == 66)selected="selected" @endif>66 kg (146 lb)</option>
										<option value="67" @if($useMatch->weight_min == 67)selected="selected" @endif>67 kg (148 lb)</option>
										<option value="68" @if($useMatch->weight_min == 68)selected="selected" @endif>68 kg (150 lb)</option>
										<option value="69" @if($useMatch->weight_min == 69)selected="selected" @endif>69 kg (152 lb)</option>
										<option value="70" @if($useMatch->weight_min == 70)selected="selected" @endif>70 kg (154 lb)</option>
										<option value="71" @if($useMatch->weight_min == 71)selected="selected" @endif>71 kg (157 lb)</option>
										<option value="72" @if($useMatch->weight_min == 72)selected="selected" @endif>72 kg (159 lb)</option>
										<option value="73" @if($useMatch->weight_min == 73)selected="selected" @endif>73 kg (161 lb)</option>
										<option value="74" @if($useMatch->weight_min == 74)selected="selected" @endif>74 kg (163 lb)</option>
										<option value="75" @if($useMatch->weight_min == 75)selected="selected" @endif>75 kg (165 lb)</option>
										<option value="76" @if($useMatch->weight_min == 76)selected="selected" @endif>76 kg (168 lb)</option>
										<option value="77" @if($useMatch->weight_min == 77)selected="selected" @endif>77 kg (170 lb)</option>
										<option value="78" @if($useMatch->weight_min == 78)selected="selected" @endif>78 kg (172 lb)</option>
										<option value="79" @if($useMatch->weight_min == 79)selected="selected" @endif>79 kg (174 lb)</option>
										<option value="80" @if($useMatch->weight_min == 80)selected="selected" @endif>80 kg (176 lb)</option>
										<option value="81" @if($useMatch->weight_min == 81)selected="selected" @endif>81 kg (179 lb)</option>
										<option value="82" @if($useMatch->weight_min == 82)selected="selected" @endif>82 kg (181 lb)</option>
										<option value="83" @if($useMatch->weight_min == 83)selected="selected" @endif>83 kg (183 lb)</option>
										<option value="84" @if($useMatch->weight_min == 84)selected="selected" @endif>84 kg (185 lb)</option>
										<option value="85" @if($useMatch->weight_min == 85)selected="selected" @endif>85 kg (187 lb)</option>
										<option value="86" @if($useMatch->weight_min == 86)selected="selected" @endif>86 kg (190 lb)</option>
										<option value="87" @if($useMatch->weight_min == 87)selected="selected" @endif>87 kg (192 lb)</option>
										<option value="88" @if($useMatch->weight_min == 88)selected="selected" @endif>88 kg (194 lb)</option>
										<option value="89" @if($useMatch->weight_min == 89)selected="selected" @endif>89 kg (196 lb)</option>
										<option value="90" @if($useMatch->weight_min == 90)selected="selected" @endif>90 kg (198 lb)</option>
										<option value="91" @if($useMatch->weight_min == 91)selected="selected" @endif>91 kg (201 lb)</option>
										<option value="92" @if($useMatch->weight_min == 92)selected="selected" @endif>92 kg (203 lb)</option>
										<option value="93" @if($useMatch->weight_min == 93)selected="selected" @endif>93 kg (205 lb)</option>
										<option value="94" @if($useMatch->weight_min == 94)selected="selected" @endif>94 kg (207 lb)</option>
										<option value="95" @if($useMatch->weight_min == 95)selected="selected" @endif>95 kg (209 lb)</option>
										<option value="96" @if($useMatch->weight_min == 96)selected="selected" @endif>96 kg (212 lb)</option>
										<option value="97" @if($useMatch->weight_min == 97)selected="selected" @endif>97 kg (214 lb)</option>
										<option value="98" @if($useMatch->weight_min == 98)selected="selected" @endif>98 kg (216 lb)</option>
										<option value="99" @if($useMatch->weight_min == 99)selected="selected" @endif>99 kg (218 lb)</option>
										<option value="100" @if($useMatch->weight_min == 100)selected="selected" @endif>100 kg (220 lb)</option>
										<option value="101" @if($useMatch->weight_min == 101)selected="selected" @endif>101 kg (223 lb)</option>
										<option value="102" @if($useMatch->weight_min == 102)selected="selected" @endif>102 kg (225 lb)</option>
										<option value="103" @if($useMatch->weight_min == 103)selected="selected" @endif>103 kg (227 lb)</option>
										<option value="104" @if($useMatch->weight_min == 104)selected="selected" @endif>104 kg (229 lb)</option>
										<option value="105" @if($useMatch->weight_min == 105)selected="selected" @endif>105 kg (231 lb)</option>
										<option value="106" @if($useMatch->weight_min == 106)selected="selected" @endif>106 kg (234 lb)</option>
										<option value="107" @if($useMatch->weight_min == 107)selected="selected" @endif>107 kg (236 lb)</option>
										<option value="108" @if($useMatch->weight_min == 108)selected="selected" @endif>108 kg (238 lb)</option>
										<option value="109" @if($useMatch->weight_min == 109)selected="selected" @endif>109 kg (240 lb)</option>
										<option value="110" @if($useMatch->weight_min == 110)selected="selected" @endif>110 kg (243 lb)</option>
										<option value="111" @if($useMatch->weight_min == 111)selected="selected" @endif>111 kg (245 lb)</option>
										<option value="112" @if($useMatch->weight_min == 112)selected="selected" @endif>112 kg (247 lb)</option>
										<option value="113" @if($useMatch->weight_min == 113)selected="selected" @endif>113 kg (249 lb)</option>
										<option value="114" @if($useMatch->weight_min == 114)selected="selected" @endif>114 kg (251 lb)</option>
										<option value="115" @if($useMatch->weight_min == 115)selected="selected" @endif>115 kg (254 lb)</option>
										<option value="116" @if($useMatch->weight_min == 119)selected="selected" @endif>116 kg (256 lb)</option>
										<option value="117" @if($useMatch->weight_min == 117)selected="selected" @endif>117 kg (258 lb)</option>
										<option value="118" @if($useMatch->weight_min == 119)selected="selected" @endif>118 kg (260 lb)</option>
										<option value="119" @if($useMatch->weight_min == 119)selected="selected" @endif>119 kg (262 lb)</option>
										<option value="120" @if($useMatch->weight_min == 120)selected="selected" @endif>120 kg (265 lb)</option>
										<option value="121" @if($useMatch->weight_min == 121)selected="selected" @endif>121 kg (267 lb)</option>
										<option value="122" @if($useMatch->weight_min == 122)selected="selected" @endif>122 kg (269 lb)</option>
										<option value="123" @if($useMatch->weight_min == 123)selected="selected" @endif>123 kg (271 lb)</option>
										<option value="124" @if($useMatch->weight_min == 124)selected="selected" @endif>124 kg (273 lb)</option>
										<option value="125" @if($useMatch->weight_min == 125)selected="selected" @endif>125 kg (276 lb)</option>
										<option value="126" @if($useMatch->weight_min == 126)selected="selected" @endif>126 kg (278 lb)</option>
										<option value="127" @if($useMatch->weight_min == 127)selected="selected" @endif>127 kg (280 lb)</option>
										<option value="128" @if($useMatch->weight_min == 128)selected="selected" @endif>128 kg (282 lb)</option>
										<option value="129" @if($useMatch->weight_min == 129)selected="selected" @endif>129 kg (284 lb)</option>
										<option value="130" @if($useMatch->weight_min == 130)selected="selected" @endif>130 kg (287 lb)</option>
										<option value="131" @if($useMatch->weight_min == 131)selected="selected" @endif>131 kg (289 lb)</option>
										<option value="132" @if($useMatch->weight_min == 132)selected="selected" @endif>132 kg (291 lb)</option>
										<option value="133" @if($useMatch->weight_min == 133)selected="selected" @endif>133 kg (293 lb)</option>
										<option value="134" @if($useMatch->weight_min == 134)selected="selected" @endif>134 kg (295 lb)</option>
										<option value="135" @if($useMatch->weight_min == 135)selected="selected" @endif>135 kg (298 lb)</option>
										<option value="136" @if($useMatch->weight_min == 136)selected="selected" @endif>136 kg (300 lb)</option>
										<option value="137" @if($useMatch->weight_min == 137)selected="selected" @endif>137 kg (302 lb)</option>
										<option value="138" @if($useMatch->weight_min == 138)selected="selected" @endif>138 kg (304 lb)</option>
										<option value="139" @if($useMatch->weight_min == 139)selected="selected" @endif>139 kg (306 lb)</option>
										<option value="140" @if($useMatch->weight_min == 140)selected="selected" @endif>140 kg (309 lb)</option>
										<option value="141" @if($useMatch->weight_min == 141)selected="selected" @endif>141 kg (311 lb)</option>
										<option value="142" @if($useMatch->weight_min == 142)selected="selected" @endif>142 kg (313 lb)</option>
										<option value="143" @if($useMatch->weight_min == 143)selected="selected" @endif>143 kg (315 lb)</option>
										<option value="144" @if($useMatch->weight_min == 144)selected="selected" @endif>144 kg (317 lb)</option>
										<option value="145" @if($useMatch->weight_min == 145)selected="selected" @endif>145 kg (320 lb)</option>
										<option value="146" @if($useMatch->weight_min == 146)selected="selected" @endif>146 kg (322 lb)</option>
										<option value="147" @if($useMatch->weight_min == 147)selected="selected" @endif>147 kg (324 lb)</option>
										<option value="148" @if($useMatch->weight_min == 148)selected="selected" @endif>148 kg (326 lb)</option>
										<option value="149" @if($useMatch->weight_min == 149)selected="selected" @endif>149 kg (328 lb)</option>
										<option value="150" @if($useMatch->weight_min == 150)selected="selected" @endif>150 kg (331 lb)</option>
										<option value="151" @if($useMatch->weight_min == 151)selected="selected" @endif>151 kg (333 lb)</option>
										<option value="152" @if($useMatch->weight_min == 152)selected="selected" @endif>152 kg (335 lb)</option>
										<option value="153" @if($useMatch->weight_min == 153)selected="selected" @endif>153 kg (337 lb)</option>
										<option value="154" @if($useMatch->weight_min == 154)selected="selected" @endif>154 kg (340 lb)</option>
										<option value="155" @if($useMatch->weight_min == 155)selected="selected" @endif>155 kg (342 lb)</option>
										<option value="156" @if($useMatch->weight_min == 156)selected="selected" @endif>156 kg (344 lb)</option>
										<option value="157" @if($useMatch->weight_min == 157)selected="selected" @endif>157 kg (346 lb)</option>
										<option value="158" @if($useMatch->weight_min == 158)selected="selected" @endif>158 kg (348 lb)</option>
										<option value="159" @if($useMatch->weight_min == 159)selected="selected" @endif>159 kg (351 lb)</option>
										<option value="160" @if($useMatch->weight_min == 160)selected="selected" @endif>160 kg (353 lb)</option>
										<option value="161" @if($useMatch->weight_min == 161)selected="selected" @endif>161 kg (355 lb)</option>
										<option value="162" @if($useMatch->weight_min == 162)selected="selected" @endif>162 kg (357 lb)</option>
										<option value="163" @if($useMatch->weight_min == 163)selected="selected" @endif>163 kg (359 lb)</option>
										<option value="164" @if($useMatch->weight_min == 164)selected="selected" @endif>164 kg (362 lb)</option>
										<option value="165" @if($useMatch->weight_min == 165)selected="selected" @endif>165 kg (364 lb)</option>
										<option value="166" @if($useMatch->weight_min == 166)selected="selected" @endif>166 kg (366 lb)</option>
										<option value="167" @if($useMatch->weight_min == 167)selected="selected" @endif>167 kg (368 lb)</option>
										<option value="168" @if($useMatch->weight_min == 168)selected="selected" @endif>168 kg (370 lb)</option>
										<option value="169" @if($useMatch->weight_min == 169)selected="selected" @endif>169 kg (373 lb)</option>
										<option value="170" @if($useMatch->weight_min == 170)selected="selected" @endif>170 kg (375 lb)</option>
										<option value="171" @if($useMatch->weight_min == 171)selected="selected" @endif>171 kg (377 lb)</option>
										<option value="172" @if($useMatch->weight_min == 172)selected="selected" @endif>172 kg (379 lb)</option>
										<option value="173" @if($useMatch->weight_min == 173)selected="selected" @endif>173 kg (381 lb)</option>
										<option value="174" @if($useMatch->weight_min == 174)selected="selected" @endif>174 kg (384 lb)</option>
										<option value="175" @if($useMatch->weight_min == 175)selected="selected" @endif>175 kg (386 lb)</option>
										<option value="176" @if($useMatch->weight_min == 176)selected="selected" @endif>176 kg (388 lb)</option>
										<option value="177" @if($useMatch->weight_min == 177)selected="selected" @endif>177 kg (390 lb)</option>
										<option value="178" @if($useMatch->weight_min == 178)selected="selected" @endif>178 kg (392 lb)</option>
										<option value="179" @if($useMatch->weight_min == 179)selected="selected" @endif>179 kg (395 lb)</option>
										<option value="180" @if($useMatch->weight_min == 180)selected="selected" @endif>180 kg (397 lb)</option>
										<option value="181" @if($useMatch->weight_min == 181)selected="selected" @endif>181 kg (399 lb)</option>
										<option value="182" @if($useMatch->weight_min == 182)selected="selected" @endif>182 kg (401 lb)</option>
										<option value="183" @if($useMatch->weight_min == 183)selected="selected" @endif>183 kg (403 lb)</option>
										<option value="184" @if($useMatch->weight_min == 184)selected="selected" @endif>184 kg (406 lb)</option>
										<option value="185" @if($useMatch->weight_min == 185)selected="selected" @endif>185 kg (408 lb)</option>
										<option value="186" @if($useMatch->weight_min == 186)selected="selected" @endif>186 kg (410 lb)</option>
										<option value="187" @if($useMatch->weight_min == 187)selected="selected" @endif>187 kg (412 lb)</option>
										<option value="188" @if($useMatch->weight_min == 188)selected="selected" @endif>188 kg (414 lb)</option>
										<option value="189" @if($useMatch->weight_min == 189)selected="selected" @endif>189 kg (417 lb)</option>
										<option value="190" @if($useMatch->weight_min == 190)selected="selected" @endif>190 kg (419 lb)</option>
										<option value="191" @if($useMatch->weight_min == 191)selected="selected" @endif>191 kg (421 lb)</option>
										<option value="192" @if($useMatch->weight_min == 192)selected="selected" @endif>192 kg (423 lb)</option>
										<option value="193" @if($useMatch->weight_min == 193)selected="selected" @endif>193 kg (425 lb)</option>
										<option value="194" @if($useMatch->weight_min == 194)selected="selected" @endif>194 kg (428 lb)</option>
										<option value="195" @if($useMatch->weight_min == 195)selected="selected" @endif>195 kg (430 lb)</option>
										<option value="196" @if($useMatch->weight_min == 196)selected="selected" @endif>196 kg (432 lb)</option>
										<option value="197" @if($useMatch->weight_min == 197)selected="selected" @endif>197 kg (434 lb)</option>
										<option value="198" @if($useMatch->weight_min == 198)selected="selected" @endif>198 kg (437 lb)</option>
										<option value="199" @if($useMatch->weight_min == 190)selected="selected" @endif>199 kg (439 lb)</option>
										<option value="200" @if($useMatch->weight_min == 200)selected="selected" @endif>200 kg (441 lb)</option>
										<option value="201" @if($useMatch->weight_min == 201)selected="selected" @endif>201 kg (443 lb)</option>
										<option value="202" @if($useMatch->weight_min == 202)selected="selected" @endif>202 kg (445 lb)</option>
										<option value="203" @if($useMatch->weight_min == 203)selected="selected" @endif>203 kg (448 lb)</option>
										<option value="204" @if($useMatch->weight_min == 204)selected="selected" @endif>204 kg (450 lb)</option>
										<option value="205" @if($useMatch->weight_min == 205)selected="selected" @endif>205 kg (452 lb)</option>
										<option value="206" @if($useMatch->weight_min == 206)selected="selected" @endif>206 kg (454 lb)</option>
										<option value="207" @if($useMatch->weight_min == 207)selected="selected" @endif>207 kg (456 lb)</option>
										<option value="208" @if($useMatch->weight_min == 208)selected="selected" @endif>208 kg (459 lb)</option>
										<option value="209" @if($useMatch->weight_min == 209)selected="selected" @endif>209 kg (461 lb)</option>
										<option value="210" @if($useMatch->weight_min == 210)selected="selected" @endif>210 kg (463 lb)</option>
										<option value="211" @if($useMatch->weight_min == 211)selected="selected" @endif>211 kg (465 lb)</option>
										<option value="212" @if($useMatch->weight_min == 212)selected="selected" @endif>212 kg (467 lb)</option>
										<option value="213" @if($useMatch->weight_min == 213)selected="selected" @endif>213 kg (470 lb)</option>
										<option value="214" @if($useMatch->weight_min == 214)selected="selected" @endif>214 kg (472 lb)</option>
										<option value="215" @if($useMatch->weight_min == 215)selected="selected" @endif>215 kg (474 lb)</option>
										<option value="216" @if($useMatch->weight_min == 216)selected="selected" @endif>216 kg (476 lb)</option>
										<option value="217" @if($useMatch->weight_min == 217)selected="selected" @endif>217 kg (478 lb)</option>
										<option value="218" @if($useMatch->weight_min == 218)selected="selected" @endif>218 kg (481 lb)</option>
										<option value="219" @if($useMatch->weight_min == 219)selected="selected" @endif>219 kg (483 lb)</option>
										<option value="220" @if($useMatch->weight_min == 220)selected="selected" @endif>220 kg (485 lb)</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<?php
								$boyType = explode(",",$useMatch->body_type);
								
								?>
								<div class="col-md-3">Body type:</div>  
								<div class="col-md-8">
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_type[]" id="body_type" @if(in_array("Any", $boyType) || empty($useMatch->body_type)) checked="checked" @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="body_type[]" id="Petite" @if(in_array("Petite", $boyType)) checked="checked" @endif value="Petite" >Petite
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_type[]" id="Slim" @if(in_array("Slim", $boyType)) checked="checked" @endif value="Slim" >Slim
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_type[]" id="Athletic" @if(in_array("Athletic", $boyType)) checked="checked" @endif value="Athletic" >Athletic
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_type[]" id="Average" @if(in_array("Average", $boyType)) checked="checked" @endif value="Average" >Average
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_type[]" id="few_extra_[ounds" @if(in_array("Few Extra Pounds", $boyType)) checked="checked" @endif value="Few Extra Pounds" >Few Extra Pounds
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_type[]" id="full_figured" @if(in_array("Full Figured", $boyType)) checked="checked" @endif value="Full Figured" >Full Figured
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_type[]" id="larg_and_lovely" @if(in_array("Large and Lovely", $boyType)) checked="checked" @endif value="Large and Lovely" >Large and Lovely
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Their ethnicity is mostly:</div>  
								<div class="col-md-8">
									<?php
									 $ethnicity = explode(",",$useMatch->ethnicity);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="ethnicity" @if(in_array("Any", $ethnicity) || empty($useMatch->ethnicity)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="arab" @if(in_array("Arab (Middle Eastern)", $ethnicity)) checked @endif value="Arab (Middle Eastern)" >Arab (Middle Eastern)
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="asian" @if(in_array("Asian", $ethnicity)) checked @endif value="Asian" >Asian
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="black" @if(in_array("Black", $ethnicity)) checked @endif value="Black" >Black
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="white" @if(in_array("Caucasian (White)", $ethnicity)) checked @endif value="Caucasian (White)" >Caucasian (White)
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="latino" @if(in_array("Hispanic / Latino", $ethnicity)) checked @endif value="Hispanic / Latino" >Hispanic / Latino
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="indian" @if(in_array("Indian", $ethnicity)) checked @endif value="Indian" >Indian
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="mixed" @if(in_array("Mixed", $ethnicity)) checked @endif value="Mixed" >Mixed
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="pacific" @if(in_array("Pacific Islander", $ethnicity)) checked @endif value="Pacific Islander">Pacific Islander
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="ethnicity[]" id="other" @if(in_array("Other", $ethnicity)) checked @endif value="Other" >Other
											</label>
										</div>
									</div>
								
								
									
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Consider their appearance as:</div>  
								<div class="col-md-8">
									<?php
									 $appearance = explode(",",$useMatch->appearance);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="appearance[]" id="appearance"  @if(in_array("Any", $appearance) || empty($useMatch->appearance)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="appearance[]" id="art_painting" @if(in_array("Below average", $appearance)) checked @endif value="Below average
">Below average
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="appearance[]" id="average" @if(in_array("Average", $appearance)) checked @endif value="Average" >Average
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="appearance[]" id="attractive"  @if(in_array("Attractive", $appearance)) checked @endif value="Attractive" >Attractive
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="appearance[]" id="very_attractive" @if(in_array("Very Attractive", $appearance)) checked @endif value="Very Attractive" >Very Attractive
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<?php
							 $hair_color = explode(",",$useMatch->hair_color);
							?>
							<div class="row">
								<div class="col-md-3">Hair color:</div>  
								<div class="col-md-8">
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_color[]" id="hair_color" @if(in_array("Any", $hair_color) || empty($useMatch->hair_color)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="hair_color[]" id="blad" @if(in_array("Bald / Shaved", $hair_color)) checked @endif value="Bald / Shaved" >Bald / Shaved
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_color[]" id="black" @if(in_array("Black", $hair_color)) checked @endif value="Black" >Black
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="hair_color[]" id="blonde" @if(in_array("Blonde", $hair_color)) checked @endif value="Blonde" >Blonde
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="hair_color[]" id="brown" @if(in_array("Brown", $hair_color)) checked @endif value="Brown" >Brown
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_color[]" id="grey" @if(in_array("Grey / White", $hair_color)) checked @endif value="Grey / White" >Grey / White
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="hair_color[]" id="light_brown" @if(in_array("Light Brown", $hair_color)) checked @endif value="Light Brown" >Light Brown
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_color[]" id="red" @if(in_array("Red", $hair_color)) checked @endif value="Red" >Red
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="hair_color[]" id="frequently" @if(in_array("Changes frequently", $hair_color)) checked @endif value="Changes frequently" >Changes frequently
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<?php
							 $hair_length = explode(",",$useMatch->hair_length);
							?>
							<div class="row">
								<div class="col-md-3">Hair length:</div>  
								<div class="col-md-8">
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_length[]" id="hair_length" @if(in_array("Any", $hair_length) || empty($useMatch->hair_length)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_length[]" id="hair_bald" @if(in_array("Bald", $hair_length)) checked @endif value="Bald" >Bald
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_length[]" id="blade_top" @if(in_array("Bald on Top", $hair_length)) checked @endif value="Bald on Top" >Bald on Top
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_length[]" id="shaved" @if(in_array("Shaved", $hair_length)) checked @endif value="Shaved" >Shaved
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_length[]" id="short" @if(in_array("Short", $hair_length)) checked @endif value="Short" >Short
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_length[]" id="medium" @if(in_array("Medium", $hair_length)) checked @endif value="Medium" >Medium
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_length[]" id="long" @if(in_array("Long", $hair_length)) checked @endif value="Long" >Long
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_length[]" id="prefer_not" @if(in_array("Prefer not to say", $hair_length)) checked @endif value="Prefer not to say" >Prefer not to say
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<?php
							 $hair_type = explode(",",$useMatch->hair_type);
							?>
							<div class="row">
								<div class="col-md-3">Hair type:</div>  
								<div class="col-md-8">
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_type[]" id="hair_type"  @if(in_array("Any", $hair_type) || empty($useMatch->hair_type)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="hair_type[]" id="straight" @if(in_array("Straight", $hair_type)) checked @endif value="Straight" >Straight
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_type[]" id="wavy" @if(in_array("Wavy", $hair_type)) checked @endif value="Wavy" >Wavy
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="hair_type[]" id="curly" @if(in_array("Curly", $hair_type)) checked @endif value="Curly" >Curly
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="hair_type[]" id="hair_other" @if(in_array("Other", $hair_type)) checked @endif value="Other" >Other
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="hair_type[]" id="hair_prefer_not" @if(in_array("Prefer not to say", $hair_type)) checked @endif value="Prefer not to say" >Prefer not to say
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<?php
							 $eye_color = explode(",",$useMatch->eye_color);
							?>
							<div class="row">
								<div class="col-md-3">Eye color:</div>  
								<div class="col-md-8">
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="eye_color[]" id="eye_color" @if(in_array("Any", $eye_color) || empty($useMatch->eye_color)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="eye_color[]" id="black" @if(in_array("Black", $eye_color)) checked @endif value="Black" >Black
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="eye_color[]" id="blue" @if(in_array("Blue", $eye_color)) checked @endif value="Blue" >Blue
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="eye_color[]" id="brown" @if(in_array("Brown", $eye_color)) checked @endif value="Brown" >Brown
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="eye_color[]" id="green" @if(in_array("Green", $eye_color)) checked @endif value="Green" >Green
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="eye_color[]" id="grey" @if(in_array("Grey", $eye_color)) checked @endif value="Grey" >Grey
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="eye_color[]" id="hazel" @if(in_array("Hazel", $eye_color)) checked @endif value="Hazel" >Hazel
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Eye wear:</div>  
								<div class="col-md-8">
									<?php
									 $eye_wear = explode(",",$useMatch->eye_wear);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="eye_wear[]" id="eye_wear" @if(in_array("Any", $eye_wear) || empty($useMatch->eye_wear)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="eye_wear[]" id="contacts" @if(in_array("Contacts", $eye_wear)) checked @endif value="Contacts" >Contacts
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="eye_wear[]" id="glasses" @if(in_array("Glasses", $eye_wear)) checked @endif value="Glasses" >Glasses
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="eye_wear[]" id="none" @if(in_array("None", $eye_wear)) checked @endif value="None" >None
											</label>
										</div>
										
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Their best feature:</div>  
								<div class="col-md-8">
									<?php
									 $best_feature = explode(",",$useMatch->best_feature);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="best_feature" @if(in_array("Any", $best_feature) || empty($useMatch->best_feature)) checked @endif  value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_arms" @if(in_array("My Arms", $best_feature)) checked @endif  value="My Arms" >My Arms
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_butt" @if(in_array("My Butt", $best_feature)) checked @endif value="My Butt" >My Butt
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_chest" @if(in_array("My Chest", $best_feature)) checked @endif value="My Chest" >My Chest
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_eyes" @if(in_array("My Eyes", $best_feature)) checked @endif value="My Eyes" >My Eyes
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_hands" @if(in_array("My Hands", $best_feature)) checked @endif value="My Hands" >My Hands
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_legs" @if(in_array("My Legs", $best_feature)) checked @endif value="My Legs" >My Legs
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_lips" @if(in_array("My Lips", $best_feature)) checked @endif value="My Lips" >My Lips
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_personality" @if(in_array("My Personality", $best_feature)) checked @endif value="My Personality" >My Personality
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_smile" @if(in_array("My Smile", $best_feature)) checked @endif value="My Smile" >My Smile
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_wallet" @if(in_array("My Wallet", $best_feature)) checked @endif value="My Wallet" >My Wallet
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_late" @if(in_array("If You're lucky I'll show you later", $best_feature)) checked @endif value="If You're lucky I'll show you later" >If You're lucky I'll show you later
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="my_other" @if(in_array("Other", $best_feature)) checked @endif value="Other" >Other
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="best_feature[]" id="dont_know" @if(in_array("Don't Know", $best_feature)) checked @endif value="Don't Know" >Don't Know
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Body art:</div>  
								<div class="col-md-8">
									<?php
									 $body_art = explode(",",$useMatch->body_art);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_art[]" id="body_art" @if(in_array("Any", $body_art) || empty($useMatch->body_art)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="body_art[]" id="branding" @if(in_array("Branding", $body_art)) checked @endif value="Branding" >Branding
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_art[]" id="earrings" @if(in_array("Earrings", $body_art)) checked @endif value="Earrings" >Earrings
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="body_art[]" id="piercing" @if(in_array("Piercing", $body_art)) checked @endif value="Piercing" >Piercing
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="body_art[]" id="tattoo" @if(in_array("Tattoo", $body_art)) checked @endif value="Tattoo" >Tattoo
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="body_art[]" id="body_art_other" @if(in_array("Other", $body_art)) checked @endif value="Other" >Other
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<span class="sectionHeading clearfix">
						    <h2>Their Lifestyle</h2>
					    </span>
					    <div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<?php
									 $smoke = explode(",",$useMatch->smoke);
								?>
								<div class="col-md-3">Do they smoke?</div>  
								<div class="col-md-8">
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="smoke[]" id="smoke" @if(in_array("Any", $smoke) || empty($useMatch->smoke)) checked @endif  value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="smoke[]" id="do_smoke" @if(in_array("Do smoke", $smoke)) checked @endif value="Do smoke" >Do smoke
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="smoke[]" id="not_smoke" @if(in_array("Don't smoke", $smoke)) checked @endif value="Don't smoke" >Don't smoke
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="smoke[]" id="occasionally_smoke" @if(in_array("Occasionally smoke", $smoke)) checked @endif value="Occasionally smoke" >Occasionally smoke
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Do they drink?</div>  
								<div class="col-md-8">
									<?php
										 $drink = explode(",",$useMatch->drink);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="drink[]" id="drink" @if(in_array("Any", $drink) || empty($useMatch->drink)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="drink[]" id="do_drink" @if(in_array("Do drink", $drink)) checked @endif value="Do drink" >Do drink
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="drink[]" id="not_drink" @if(in_array("Don't drink", $drink)) checked @endif value="Don't drink" >Don't drink
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="drink[]" id="occasionally_drink" @if(in_array("Occasionally drink", $drink)) checked @endif value="Occasionally drink" >Occasionally drink
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Willing to relocate:</div>  
								<div class="col-md-8">
									<?php
										 $relocate = explode(",",$useMatch->relocate);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="relocate[]" id="relocate" @if(in_array("Any", $relocate) || empty($useMatch->relocate)) checked @endif  value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="relocate[]" id="relocate_country" @if(in_array("Willing to relocate within my country", $relocate)) checked @endif value="Willing to relocate within my country" >Willing to relocate within my country
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="relocate[]" id="relocate_other_country" @if(in_array("Willing to relocate to another country", $relocate)) checked @endif value="Willing to relocate to another country" >Willing to relocate to another country
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="relocate[]" id="relocate_not_willing" @if(in_array("Not willing to relocate", $relocate)) checked @endif value="Not willing to relocate" >Not willing to relocate
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="relocate[]" id="not_sure_relocate" @if(in_array("Not sure about relocating", $relocate)) checked @endif value="Not sure about relocating" >Not sure about relocating
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Marital Status:</div>  
								<div class="col-md-8">
									<?php
										 $marital_status = explode(",",$useMatch->marital_status);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="marital_status[]" id="marital_status" @if(in_array("Any", $marital_status) || empty($useMatch->marital_status)) checked @endif   value="Any" >Any 
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="marital_status[]" id="single" @if(in_array("Single", $marital_status)) checked @endif value="Single" >Single
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="marital_status[]" id="separated" @if(in_array("Separated", $marital_status)) checked @endif  value="Separated" >Separated 
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="marital_status[]" id="widowed" @if(in_array("Widowed", $marital_status)) checked @endif  value="Widowed" >Widowed
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="marital_status[]" id="divorced" @if(in_array("Divorced", $marital_status)) checked @endif  value="Divorced" >Divorced 
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="marital_status[]" id="marital_other" @if(in_array("Other", $marital_status)) checked @endif  value="Other" >Other
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Do they have children?</div>  
								<div class="col-md-8">
									<?php
										 $have_children = explode(",",$useMatch->have_children);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="have_children[]" id="have_children" @if(in_array("Any", $have_children) || empty($useMatch->have_children)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="have_children[]" id="no" @if(in_array("No", $have_children)) checked @endif value="No" >No
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="have_children[]" id="yes_sometime" @if(in_array("Yes - sometimes live at home", $have_children)) checked @endif value="Yes - sometimes live at home" >Yes - sometimes live at home
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="have_children[]" id="yes_not" @if(in_array("Yes - don't live at home", $have_children)) checked @endif value="Yes - don't live at home" >Yes - don't live at home
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="have_children[]" id="yes_at_home" @if(in_array("Yes - live at home", $have_children)) checked @endif value="Yes - live at home" >Yes - live at home
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Do they want (more) children?</div>  
								<div class="col-md-8">
									<?php
										 $more_children = explode(",",$useMatch->more_children);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="more_child[]" id="more_child" @if(in_array("Any", $more_children) || empty($useMatch->more_children)) checked @endif  value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="more_child[]" id="more_child" @if(in_array("Yes", $more_children)) checked @endif value="Yes" >Yes
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="more_child[]" id="more_childnot_sure" @if(in_array("Not Sure", $more_children)) checked @endif value="Not Sure" >Not Sure
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="more_child[]" id="more_child_no" @if(in_array("No", $more_children)) checked @endif value="No" >No
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Occupation:</div>  
								<div class="col-md-8">
									<?php
										 $occupation = explode(",",$useMatch->occupation);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="employment" @if(in_array("Any", $occupation) || empty($useMatch->occupation)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="administrative" @if(in_array("Administrative / Secretarial / Clerical", $occupation)) checked @endif value="Administrative / Secretarial / Clerical" >Administrative / Secretarial / Clerical
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="media" @if(in_array("Advertising / Media", $occupation)) checked @endif value="Advertising / Media" >Advertising / Media
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="creative" @if(in_array("Artistic / Creative / Performance", $occupation)) checked @endif value="Artistic / Creative / Performance" >Artistic / Creative / Performance
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="traders" @if(in_array("Construction / Trades", $occupation)) checked @endif value="Construction / Trades" >Construction / Trades
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="domestic" @if(in_array("Domestic Helper", $occupation)) checked @endif value="Domestic Helper" >Domestic Helper
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="academic" @if(in_array("Education / Academic", $occupation)) checked @endif value="Education / Academic" >Education / Academic
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="media" @if(in_array("Entertainment / Media", $occupation)) checked @endif value="Entertainment / Media" >Entertainment / Media
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="management" @if(in_array("Executive / Management / HR", $occupation)) checked @endif value="Executive / Management / HR" >Executive / Management / HR
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="farming" @if(in_array("Farming / Agriculture", $occupation)) checked @endif value="Farming / Agriculture" >Farming / Agriculture
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="banking" @if(in_array("Finance / Banking / Real Estate", $occupation)) checked @endif value="Finance / Banking / Real Estate" >Finance / Banking / Real Estate
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="fire" @if(in_array("Fire / law enforcement / security", $occupation)) checked @endif value="Fire / law enforcement / security" >Fire / law enforcement / security
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="hair" @if(in_array("Hair Dresser / Personal Grooming", $occupation)) checked @endif value="Hair Dresser / Personal Grooming" >Hair Dresser / Personal Grooming
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="it" @if(in_array("IT / Communications", $occupation)) checked @endif value="IT / Communications" >IT / Communications
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="laborer" @if(in_array("Laborer / Manufacturing", $occupation)) checked @endif value="Laborer / Manufacturing" >Laborer / Manufacturing
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="legal" @if(in_array("Legal", $occupation)) checked @endif value="Legal" >Legal
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="dental" @if(in_array("Medical / Dental / Veterinary", $occupation)) checked @endif value="Medical / Dental / Veterinary" >Medical / Dental / Veterinary
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="military" @if(in_array("Military", $occupation)) checked @endif value="Military" >Military
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="nanny" @if(in_array("Nanny / Child care", $occupation)) checked @endif value="Nanny / Child care" >Nanny / Child care
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="occupation" @if(in_array("No occupation / Stay at home", $occupation)) checked @endif value="No occupation / Stay at home" >No occupation / Stay at home
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="clergy" @if(in_array("Non-profit / clergy / social services", $occupation)) checked @endif value="Non-profit / clergy / social services" >Non-profit / clergy / social services
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="govt" @if(in_array("Political / Govt / Civil Service", $occupation)) checked @endif value="Political / Govt / Civil Service" >Political / Govt / Civil Service
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="retail" @if(in_array("Retail / Food services", $occupation)) checked @endif value="Retail / Food services" >Retail / Food services
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="retired" @if(in_array("Retired", $occupation)) checked @endif value="Retired" >Retired
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="sales" @if(in_array("Sales / Marketing", $occupation)) checked @endif value="Sales / Marketing" >Sales / Marketing
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="self_employment" @if(in_array("Self Employed", $occupation)) checked @endif value="Self Employed" >Self Employed
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="sports" @if(in_array("Sports / recreation", $occupation)) checked @endif value="Sports / recreation" >Sports / recreation
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="student" @if(in_array("Student", $occupation)) checked @endif value="Student" >Student
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="technical" @if(in_array("Technical / Science / Engineering", $occupation)) checked @endif value="Technical / Science / Engineering" >Technical / Science / Engineering
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="transportation" @if(in_array("Transportation", $occupation)) checked @endif value="Transportation" >Transportation
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="travel" @if(in_array("Travel / Hospitality", $occupation)) checked @endif value="Travel / Hospitality" >Travel / Hospitality
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="unemployed" @if(in_array("Unemployed", $occupation)) checked @endif value="Unemployed" >Unemployed
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment[]" id="employment_other" @if(in_array("Other", $occupation)) checked @endif value="Other" >Other
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Employment status:</div>  
								<div class="col-md-8">
									<?php
										 $employment_status = explode(",",$useMatch->employment_status);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="employment_status[]" id="employment_status" @if(in_array("Any", $employment_status) || empty($useMatch->employment_status)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="employment_status[]" id="student" @if(in_array("Student", $employment_status)) checked @endif value="Student" >Student
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="employment_status[]" id="part_time" @if(in_array("Part Time", $employment_status)) checked @endif value="Part Time" >Part Time
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="employment_status[]" id="full_time" @if(in_array("Full Time", $employment_status)) checked @endif value="Full Time" >Full Time
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="employment_status[]" id="homemaker" @if(in_array("Homemaker", $employment_status)) checked @endif value="Homemaker" >Homemaker
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="employment_status[]" id="retired" @if(in_array("Retired", $employment_status)) checked @endif value="Retired" >Retired
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="employment_status[]" id="not_employed" @if(in_array("Not Employed", $employment_status)) checked @endif value="Not Employed" >Not Employed
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="employment_status[]" id="employment_status_other" @if(in_array("Other", $employment_status)) checked @endif value="Other" >Other
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="employment_status[]" id="employment_status_prefer" @if(in_array("Prefer not to say", $employment_status)) checked @endif value="Prefer not to say" >Prefer not to say
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Home type:</div>  
								<div class="col-md-8">
									<?php
										 $home_type = explode(",",$useMatch->home_type);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="home_type[]" id="home_type" @if(in_array("Any", $home_type) || empty($useMatch->home_type)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="home_type[]" id="apartment" @if(in_array("Apartment / Flat", $home_type)) checked @endif value="Apartment / Flat" >Apartment / Flat
											</label>
										</div>
										
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="home_type[]" id="condominium" @if(in_array("Condominium", $home_type)) checked @endif value="Condominium" >Condominium
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="home_type[]" id="farm" @if(in_array("Farm", $home_type)) checked @endif value="Farm" >Farm
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="home_type[]" id="house" @if(in_array("House", $home_type)) checked @endif value="House" >House
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="home_type[]" id="town_house_other" @if(in_array("Other", $home_type)) checked @endif value="Other" >Other
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="home_type[]" id="home_type_prefer" @if(in_array("Prefer not to say", $home_type)) checked @endif value="Prefer not to say" >Prefer not to say
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Living situation:</div>  
								<div class="col-md-8">
									<?php
										 $living_situation = explode(",",$useMatch->living_situation);
									?>
									<div class="row">
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="living[]" id="living" @if(in_array("Any", $living_situation) || empty($useMatch->living_situation)) checked @endif value="Any" >Any
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline text-dark">
												<input type="checkbox" class="mr-2" name="living[]" id="live_alone" @if(in_array("Live Alone", $living_situation)) checked @endif value="Live Alone" >Live Alone
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="living[]" id="living_with" @if(in_array("Live with friends", $living_situation)) checked @endif value="Live with friends" >Live with friends
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="living[]" id="living_family" @if(in_array("Live with family", $living_situation)) checked @endif value="Live with family" >Live with family
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="living[]" id="living_kids" @if(in_array("Live with kids", $living_situation)) checked @endif value="Live with kids" >Live with kids
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="living[]" id="living_spouse" @if(in_array("Live with spouse", $living_situation)) checked @endif value="Live with spouse" >Live with spouse
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="living[]" id="living_other" @if(in_array("Other", $living_situation)) checked @endif value="Other" >Other
											</label>
										</div>
										<div class="col-md-4">
											<label class="checkbox-inline pr-3 text-dark">
												<input type="checkbox" class="mr-2" name="living[]" id="living_prefer" @if(in_array("Prefer not to say", $living_situation)) checked @endif value="Prefer not to say" >Prefer not to say
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>
					    <span class="sectionHeading clearfix">
						    <h2>Their Background / Cultural Values</h2>
					    </span>
					    <div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Nationality:</div>  
								<div class="col-md-6">
									<?php
										 $nationality = explode(",",$useMatch->nationality);
									?>
									<select class="" name="nationality[]" id="nationality" multiple>
										<option value="">Please Select</option>
										@foreach($countryList as $item)
											<option value="{{$item->id}}" @if(in_array($item->id, $nationality)) selected="selected" @endif >{{$item->name}}</option>
										@endforeach
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Education:</div>  
								<div class="col-md-6">
									<?php
										 $education = explode(",",$useMatch->education);
									?>
									<select class="" name="education[]" id="education" multiple>
										<option value="">Please Select</option>
										<option value="Primary (Elementary) School" @if(in_array("Primary (Elementary) School", $education)) selected="selected" @endif >Primary (Elementary) School</option>
										<option value="Middle School / Junior High" @if(in_array("Middle School / Junior High", $education)) selected="selected" @endif >Middle School / Junior High</option>
										<option value="High School" @if(in_array("High School", $education)) selected="selected" @endif >High School</option>
										<option value="Vocational College" @if(in_array("Vocational College", $education)) selected="selected" @endif >Vocational College</option>
										<option value="Bachelors Degree" @if(in_array("Bachelors Degree", $education)) selected="selected" @endif >Bachelors Degree</option>
										<option value="Masters Degree" @if(in_array("Masters Degree", $education)) selected="selected" @endif >Masters Degree</option>
										<option value="PhD or Doctorate" @if(in_array("PhD or Doctorate", $education)) selected="selected" @endif >PhD or Doctorate</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">English language ability:</div>  
								<div class="col-md-6">
									<?php
										 $language_ability = explode(",",$useMatch->language_ability);
									?>
									<select class="" name="english_ability[]" id="english_ability"  multiple>
										<option value="">Please Select</option>
										<option value="None" @if(in_array("None", $language_ability)) selected="selected" @endif >None</option>
										<option value="Some" @if(in_array("Some", $language_ability)) selected="selected" @endif  >Some</option>
										<option value="Good" @if(in_array("Good", $language_ability)) selected="selected" @endif >Good</option>
										<option value="Very Good" @if(in_array("Very Good", $language_ability)) selected="selected" @endif >Very Good</option>
										<option value="Fluent" @if(in_array("Fluent", $language_ability)) selected="selected" @endif >Fluent</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Religion:</div>  
								<div class="col-md-6">
									<?php
										 $religion = explode(",",$useMatch->religion);
									?>
									<select class="" name="religion" id="religion" >
										<option value="">Please Select</option>
										<option value="Bahá'í" @if(in_array("Bahá'í", $religion)) selected="selected" @endif >Bahá'í</option>
										<option value="Buddhist" @if(in_array("Buddhist", $religion)) selected="selected" @endif >Buddhist</option>
										<option value="Christian - Catholic" @if(in_array("Christian - Catholic", $religion)) selected="selected" @endif >Christian - Catholic</option>
										<option value="Christian - Other" @if(in_array("Christian - Other", $religion)) selected="selected" @endif >Christian - Other</option>
										<option value="Christian - Protestant" @if(in_array("Christian - Protestant", $religion)) selected="selected" @endif >Christian - Protestant</option>
										<option value="Hindu" @if(in_array("Hindu", $religion)) selected="selected" @endif >Hindu</option>
										<option value="Islam" @if(in_array("Islam", $religion)) selected="selected" @endif >Islam</option>
										<option value="Jainism" @if(in_array("Jainism", $religion)) selected="selected" @endif >Jainism</option>
										<option value="Jewish" @if(in_array("Jewish", $religion)) selected="selected" @endif >Jewish</option>
										<option value="Parsi" @if(in_array("Parsi", $religion)) selected="selected" @endif >Parsi</option>
										<option value="Shintoism" @if(in_array("Shintoism", $religion)) selected="selected" @endif >Shintoism</option>
										<option value="Sikhism" @if(in_array("Sikhism", $religion)) selected="selected" @endif >Sikhism</option>
										<option value="Taoism" @if(in_array("Taoism", $religion)) selected="selected" @endif >Taoism</option>
										<option value="Other" @if(in_array("Other", $religion)) selected="selected" @endif >Other</option>
										<option value="No religion" @if(in_array("No religion", $religion)) selected="selected" @endif >No religion</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Religious values:</div>  
								<div class="col-md-6">
									<?php
										 $religious_values = explode(",",$useMatch->religious_values);
									?>
									<select class="" name="religion_values[]" id="religion_values" multiple>
										<option value="">Please Select</option>
										 <option value="Not Religious" @if(in_array("Not Religious", $religious_values)) selected="selected" @endif>Not Religious</option>
										<option value="Religious" @if(in_array("Religious", $religious_values)) selected="selected" @endif>Religious</option>
										<option value="Very Religious" @if(in_array("Very Religious", $religious_values)) selected="selected" @endif>Very Religious</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Star sign:</div>  
								<div class="col-md-6">
									<?php
										 $star_ssign = explode(",",$useMatch->star_ssign);
									?>
									<select class="" name="star_sign[]" id="star_sign"  multiple>
										<option value="">Please Select</option>
										<option value="Aquarius" @if(in_array("Aquarius", $star_ssign)) selected="selected" @endif>Aquarius</option>
										<option value="Aries" @if(in_array("Aries", $star_ssign)) selected="selected" @endif>Aries</option>
										<option value="Cancer" @if(in_array("Cancer", $star_ssign)) selected="selected" @endif>Cancer</option>
										<option value="Capricorn" @if(in_array("Capricorn", $star_ssign)) selected="selected" @endif>Capricorn</option>
										<option value="Gemini" @if(in_array("Gemini", $star_ssign)) selected="selected" @endif>Gemini</option>
										<option value="Leo" @if(in_array("Leo", $star_ssign)) selected="selected" @endif>Leo</option>
										<option value="Libra" @if(in_array("Libra", $star_ssign)) selected="selected" @endif>Libra</option>
										<option value="Pisces" @if(in_array("Pisces", $star_ssign)) selected="selected" @endif>Pisces</option>
										<option value="Sagittarius" @if(in_array("Sagittarius", $star_ssign)) selected="selected" @endif>Sagittarius</option>
										<option value="Scorpio" @if(in_array("Scorpio", $star_ssign)) selected="selected" @endif>Scorpio</option>
										<option value="Taurus" @if(in_array("Taurus", $star_ssign)) selected="selected" @endif>Taurus</option>
										<option value="Virgo" @if(in_array("Virgo", $star_ssign)) selected="selected" @endif>Virgo</option>
										<option value="Don't Know" @if(in_array("Don't Know", $star_ssign)) selected="selected" @endif>Don't Know</option>
									</select>
								</div>
							</div>
						</div>
						<div style="text-align:center;" class="col-md-12">
							<button type="submit" class="btn btn-success">Save</button>
						</div>
					</form>	
				</div>
           </div>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection
