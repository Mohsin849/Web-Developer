@extends('layouts.app')
@section('content')
<style>
.sectionHeading{
	    background-color: #f1f1f1;
    padding-bottom: 10px;
    display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
	display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
    list-style-type: none;
}
.sectionHeading h2 {
    font-size: 14px;
    font-weight: 700;
    float: left;
    width: 450px;
	font-family: inherit;
	line-height: 20px;

}
a, button, input {
	outline: medium none !important;
    color: initial;
}
.tab.tab-icon .nav-tabs li {
    width: 16.667%;
    text-align: center;
    float: left;
    position: relative;
}
</style>
<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
      <div class="col-md-12">
        <div class="tab tab-icon clearfix"> 
          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li>
				<a href="{{URL::to('/editprofilephotos')}}" >
					<span>Photos</span>
				</a>
				
			</li>
            <li>
				<a href="{{URL::to('/editmyprofile')}}" class="active">
					<span>Profile</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editmatchinfo')}}">
					<span>Match</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editinterestinfo')}}" >
					<span>Interest</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/editpersonalityinfo')}}" >
					<span>Personality</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/verifyprofile')}}" >
					<span>Verify Profile</span>
				</a>
			</li>
          </ul>
          <!-- Tab panes -->
			<div class="tab-content">
				@if(session('success'))
					<div class="alert alert-success" role="alert">{{session('success')}}</div>
				@endif
				@if(session('errors'))
					<div class="alert alert-danger" role="alert">{{session('errors')}}</div>
				@endif
				<div role="tabpanel" class="tab-pane fade active in" id="tab2-1">
					<p class="mb-1">
						Let your personality shine. Express yourself in your own words to give other users a better understanding of who you are. Answer at least 7 questions below to complete this section.
					</p>
					<span class="sectionHeading clearfix">
						<h2>Your Basic</h2>
					</span>
					<form method="post" data-parsley-validate="">
					@csrf
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">First Name</div>  
								<div class="col-md-6">
									<input type="text"  class="" name="name" id="name" required value="{{Auth::user()->name}}">
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">I am a</div>  
								<div class="col-md-6">
									<select name="gender" id ="gender" class="">
										<option value="1" @if(Auth::user()->gender == 1)selected="selected" @endif>Male</option>
										<option value="2" @if(Auth::user()->gender == 2)selected="selected" @endif>Female</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Date of birth</div>  
								<div class="col-md-6">
									<input type="text" class="" name="dob" id="dob" required value="{{Auth::user()->date_of_birth}}">
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Country</div>  
								<div class="col-md-6">
									<select class="" name="country" id="country" onchange="getState(this);" required>
										<option value="">Country</option>
										@foreach($countryList as $item)
											<option value="{{$item->id}}" @if($item->id == Auth::user()->country)selected="selected" @endif>{{$item->name}}</option>
										@endforeach
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">State</div>  
								<div class="col-md-6">
									<select class="" name="state" id="state" onchange="getCity(this);" required>
										<option value="">State</option>
										@foreach($stateList as $item)
											<option value="{{$item->id}}" @if($item->id == Auth::user()->state)selected="selected" @endif>{{$item->name}}</option>
										@endforeach
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">City</div>  
								<div class="col-md-6">
									<select class="" name="city" id="city" required>
										<option value="">City</option>
										@foreach($cityList as $item)
											<option value="{{$item->id}}" @if($item->id == Auth::user()->city)selected="selected" @endif>{{$item->name}}</option>
										@endforeach
									</select>
								</div>
							</div>
						</div>
						<span class="sectionHeading clearfix">
							<h2>Your Appericens</h2>
						</span>
						
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Hair color:</div>  
								<div class="col-md-6">
									<select class="" name="hair_color" id="hair_color" required>
										<option value="">Please Select</option>
										<option value="Bald / Shaved" @if($userAppericens->hair_color == "Bald / Shaved")selected="selected" @endif>Bald / Shaved</option>
										<option value="Black" @if($userAppericens->hair_color == "Black")selected="selected" @endif>Black</option>
										<option value="Blonde" @if($userAppericens->hair_color == "Blonde")selected="selected" @endif>Blonde</option>
										<option value="Brown" @if($userAppericens->hair_color == "Brown")selected="selected" @endif>Brown</option>
										<option value="Grey / White" @if($userAppericens->hair_color == "Grey / White")selected="selected" @endif>Grey / White</option>
										<option value="Light Brown" @if($userAppericens->hair_color == "Light Brown")selected="selected" @endif>Light Brown</option>
										<option value="Red" @if($userAppericens->hair_color == "Red")selected="selected" @endif>Red</option>
										<option value="Changes frequently" @if($userAppericens->hair_color == "Changes frequently")selected="selected" @endif>Changes frequently</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Hair length:</div>  
								<div class="col-md-6">
									<select class="" name="hair_length" id="hair_length" required>
										<option value="">Please Select</option>
										<option value="Bald" @if($userAppericens->hair_length == "Bald")selected="selected" @endif>Bald</option>
										<option value="Bald on Top" @if($userAppericens->hair_length == "Bald on Top")selected="selected" @endif>Bald on Top</option>
										<option value="Shaved" @if($userAppericens->hair_length == "Shaved")selected="selected" @endif>Shaved</option>
										<option value="Short" @if($userAppericens->hair_length == "Short")selected="selected" @endif>Short</option>
										<option value="Medium" @if($userAppericens->hair_length == "Medium")selected="selected" @endif>Medium</option>
										<option value="Long" @if($userAppericens->hair_length == "Long")selected="selected" @endif>Long</option>
										<option value="Prefer not to say" @if($userAppericens->hair_length == "Prefer not to say")selected="selected" @endif>Prefer not to say</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Hair type:</div>  
								<div class="col-md-6">
									<select class="" name="hair_type" id="hair_type" required>
										<option value="">Please Select</option>
										<option value="Straight" @if($userAppericens->hair_type == "Straight")selected="selected" @endif>Straight</option>
										<option value="Wavy" @if($userAppericens->hair_type == "Wavy")selected="selected" @endif>Wavy</option>
										<option value="Curly" @if($userAppericens->hair_type == "Curly")selected="selected" @endif>Curly</option>
										<option value="Other" @if($userAppericens->hair_type == "Other")selected="selected" @endif>Other</option>
										<option value="Prefer not to say" @if($userAppericens->hair_type == "Prefer not to say")selected="selected" @endif>Prefer not to say</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Eye color:</div>  
								<div class="col-md-6">
									<select class="" name="eye_color" id="eye_color" required>
										<option value="">Please Select</option>
										<option value="Black" @if($userAppericens->eye_color == "Black")selected="selected" @endif>Black</option>
										<option value="Blue" @if($userAppericens->eye_color == "Blue")selected="selected" @endif>Blue</option>
										<option value="Brown" @if($userAppericens->eye_color == "Brown")selected="selected" @endif>Brown</option>
										<option value="Green" @if($userAppericens->eye_color == "Green")selected="selected" @endif>Green</option>
										<option value="Grey" @if($userAppericens->eye_color == "Grey")selected="selected" @endif>Grey</option>
										<option value="Hazel" @if($userAppericens->eye_color == "Hazel")selected="selected" @endif>Hazel</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Eye wear:</div>  
								<div class="col-md-6">
									<select class="" name="eye_wear" id="eye_wear" required>
										<option value="">Please Select</option>
										<option value="Contacts" @if($userAppericens->eye_wear == "Contacts")selected="selected" @endif>Contacts</option>
										<option value="Glasses" @if($userAppericens->eye_wear == "Glasses")selected="selected" @endif>Glasses</option>
										<option value="None" @if($userAppericens->eye_wear == "None")selected="selected" @endif>None</option>
										<option value="Prefer not to say" @if($userAppericens->eye_wear == "Prefer not to say")selected="selected" @endif>Prefer not to say</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Height:</div>  
								<div class="col-md-6">
									<select class="" name="height" id="height" required>
										<option value="">Please Select</option>
										<option value="1" @if($userAppericens->height == 1)selected="selected" @endif>4'7" (140 cm)</option>
										<option value="2" @if($userAppericens->height == 2)selected="selected" @endif>4'8" (143 cm)</option>
										<option value="3" @if($userAppericens->height == 3)selected="selected" @endif>4'9" (145 cm)</option>
										<option value="4" @if($userAppericens->height == 4)selected="selected" @endif>4'10" (148 cm)</option>
										<option value="5" @if($userAppericens->height == 5)selected="selected" @endif>4'11" (150 cm)</option>
										<option value="6" @if($userAppericens->height == 6)selected="selected" @endif>5' (153 cm)</option>
										<option value="7" @if($userAppericens->height == 7)selected="selected" @endif>5'1" (155 cm)</option>
										<option value="8" @if($userAppericens->height == 8)selected="selected" @endif>5'2" (158 cm)</option>
										<option value="9" @if($userAppericens->height == 9)selected="selected" @endif>5'3" (161 cm)</option>
										<option value="10" @if($userAppericens->height == 10)selected="selected" @endif>5'4" (163 cm)</option>
										<option value="11" @if($userAppericens->height == 11)selected="selected" @endif>5'5" (166 cm)</option>
										<option value="12" @if($userAppericens->height == 12)selected="selected" @endif>5'6" (168 cm)</option>
										<option value="13" @if($userAppericens->height == 13)selected="selected" @endif>5'7" (171 cm)</option>
										<option value="14" @if($userAppericens->height == 14)selected="selected" @endif>5'8" (173 cm)</option>
										<option value="15" @if($userAppericens->height == 15)selected="selected" @endif>5'9" (176 cm)</option>
										<option value="16" @if($userAppericens->height == 16)selected="selected" @endif>5'10" (178 cm)</option>
										<option value="17" @if($userAppericens->height == 17)selected="selected" @endif>5'11" (181 cm)</option>
										<option value="18" @if($userAppericens->height == 18)selected="selected" @endif>6' (183 cm)</option>
										<option value="19" @if($userAppericens->height == 19)selected="selected" @endif>6'1" (186 cm)</option>
										<option value="20" @if($userAppericens->height == 20)selected="selected" @endif>6'2" (188 cm)</option>
										<option value="21" @if($userAppericens->height == 21)selected="selected" @endif>6'3" (191 cm)</option>
										<option value="22" @if($userAppericens->height == 22)selected="selected" @endif>6'4" (194 cm)</option>
										<option value="23" @if($userAppericens->height == 23)selected="selected" @endif>6'5" (196 cm)</option>
										<option value="24" @if($userAppericens->height == 24)selected="selected" @endif>6'6" (199 cm)</option>
										<option value="25" @if($userAppericens->height == 25)selected="selected" @endif>6'7" (201 cm)</option>
										<option value="26" @if($userAppericens->height == 26)selected="selected" @endif>6'8" (204 cm)</option>
										<option value="27" @if($userAppericens->height == 27)selected="selected" @endif>6'9 (206 cm)</option>
										<option value="28" @if($userAppericens->height == 28)selected="selected" @endif>6'10" (209 cm)</option>
										<option value="29" @if($userAppericens->height == 29)selected="selected" @endif>6'11" (211 cm)</option>
										<option value="30" @if($userAppericens->height == 30)selected="selected" @endif>7' (214 cm)</option>
										<option value="31" @if($userAppericens->height == 31)selected="selected" @endif>7'1" (216 cm)</option>
										<option value="32" @if($userAppericens->height == 32)selected="selected" @endif>7'2" (219 cm)</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Weight:</div>  
								<div class="col-md-6">
									<select class="" name="weight" id="weight" required>
										<option value="">Please Select</option>
										<option value="40" @if($userAppericens->weight == 40)selected="selected" @endif>40 kg (88 lb)</option>
										<option value="41" @if($userAppericens->weight == 41)selected="selected" @endif>41 kg (90 lb)</option>
										<option value="42" @if($userAppericens->weight == 42)selected="selected" @endif>42 kg (93 lb)</option>
										<option value="43" @if($userAppericens->weight == 43)selected="selected" @endif>43 kg (95 lb)</option>
										<option value="44" @if($userAppericens->weight == 44)selected="selected" @endif>44 kg (97 lb)</option>
										<option value="45" @if($userAppericens->weight == 45)selected="selected" @endif>45 kg (99 lb)</option>
										<option value="46" @if($userAppericens->weight == 46)selected="selected" @endif>46 kg (101 lb)</option>
										<option value="47" @if($userAppericens->weight == 47)selected="selected" @endif>47 kg (104 lb)</option>
										<option value="48" @if($userAppericens->weight == 48)selected="selected" @endif>48 kg (106 lb)</option>
										<option value="49" @if($userAppericens->weight == 49)selected="selected" @endif>49 kg (108 lb)</option>
										<option value="50" @if($userAppericens->weight == 50)selected="selected" @endif>50 kg (110 lb)</option>
										<option value="51" @if($userAppericens->weight == 51)selected="selected" @endif>51 kg (112 lb)</option>
										<option value="52" @if($userAppericens->weight == 52)selected="selected" @endif>52 kg (115 lb)</option>
										<option value="53" @if($userAppericens->weight == 53)selected="selected" @endif>53 kg (117 lb)</option>
										<option value="54" @if($userAppericens->weight == 54)selected="selected" @endif>54 kg (119 lb)</option>
										<option value="55" @if($userAppericens->weight == 55)selected="selected" @endif>55 kg (121 lb)</option>
										<option value="56" @if($userAppericens->weight == 56)selected="selected" @endif>56 kg (123 lb)</option>
										<option value="57" @if($userAppericens->weight == 57)selected="selected" @endif>57 kg (126 lb)</option>
										<option value="58" @if($userAppericens->weight == 58)selected="selected" @endif>58 kg (128 lb)</option>
										<option value="59" @if($userAppericens->weight == 59)selected="selected" @endif>59 kg (130 lb)</option>
										<option value="60" @if($userAppericens->weight == 60)selected="selected" @endif>60 kg (132 lb)</option>
										<option value="61" @if($userAppericens->weight == 61)selected="selected" @endif>61 kg (134 lb)</option>
										<option value="62" @if($userAppericens->weight == 62)selected="selected" @endif>62 kg (137 lb)</option>
										<option value="63" @if($userAppericens->weight == 63)selected="selected" @endif>63 kg (139 lb)</option>
										<option value="64" @if($userAppericens->weight == 64)selected="selected" @endif>64 kg (141 lb)</option>
										<option value="65" @if($userAppericens->weight == 65)selected="selected" @endif>65 kg (143 lb)</option>
										<option value="66" @if($userAppericens->weight == 66)selected="selected" @endif>66 kg (146 lb)</option>
										<option value="67" @if($userAppericens->weight == 67)selected="selected" @endif>67 kg (148 lb)</option>
										<option value="68" @if($userAppericens->weight == 68)selected="selected" @endif>68 kg (150 lb)</option>
										<option value="69" @if($userAppericens->weight == 69)selected="selected" @endif>69 kg (152 lb)</option>
										<option value="70" @if($userAppericens->weight == 70)selected="selected" @endif>70 kg (154 lb)</option>
										<option value="71" @if($userAppericens->weight == 71)selected="selected" @endif>71 kg (157 lb)</option>
										<option value="72" @if($userAppericens->weight == 72)selected="selected" @endif>72 kg (159 lb)</option>
										<option value="73" @if($userAppericens->weight == 73)selected="selected" @endif>73 kg (161 lb)</option>
										<option value="74" @if($userAppericens->weight == 74)selected="selected" @endif>74 kg (163 lb)</option>
										<option value="75" @if($userAppericens->weight == 75)selected="selected" @endif>75 kg (165 lb)</option>
										<option value="76" @if($userAppericens->weight == 76)selected="selected" @endif>76 kg (168 lb)</option>
										<option value="77" @if($userAppericens->weight == 77)selected="selected" @endif>77 kg (170 lb)</option>
										<option value="78" @if($userAppericens->weight == 78)selected="selected" @endif>78 kg (172 lb)</option>
										<option value="79" @if($userAppericens->weight == 79)selected="selected" @endif>79 kg (174 lb)</option>
										<option value="80" @if($userAppericens->weight == 80)selected="selected" @endif>80 kg (176 lb)</option>
										<option value="81" @if($userAppericens->weight == 81)selected="selected" @endif>81 kg (179 lb)</option>
										<option value="82" @if($userAppericens->weight == 82)selected="selected" @endif>82 kg (181 lb)</option>
										<option value="83" @if($userAppericens->weight == 83)selected="selected" @endif>83 kg (183 lb)</option>
										<option value="84" @if($userAppericens->weight == 84)selected="selected" @endif>84 kg (185 lb)</option>
										<option value="85" @if($userAppericens->weight == 85)selected="selected" @endif>85 kg (187 lb)</option>
										<option value="86" @if($userAppericens->weight == 86)selected="selected" @endif>86 kg (190 lb)</option>
										<option value="87" @if($userAppericens->weight == 87)selected="selected" @endif>87 kg (192 lb)</option>
										<option value="88" @if($userAppericens->weight == 88)selected="selected" @endif>88 kg (194 lb)</option>
										<option value="89" @if($userAppericens->weight == 89)selected="selected" @endif>89 kg (196 lb)</option>
										<option value="90" @if($userAppericens->weight == 90)selected="selected" @endif>90 kg (198 lb)</option>
										<option value="91" @if($userAppericens->weight == 91)selected="selected" @endif>91 kg (201 lb)</option>
										<option value="92" @if($userAppericens->weight == 92)selected="selected" @endif>92 kg (203 lb)</option>
										<option value="93" @if($userAppericens->weight == 93)selected="selected" @endif>93 kg (205 lb)</option>
										<option value="94" @if($userAppericens->weight == 94)selected="selected" @endif>94 kg (207 lb)</option>
										<option value="95" @if($userAppericens->weight == 95)selected="selected" @endif>95 kg (209 lb)</option>
										<option value="96" @if($userAppericens->weight == 96)selected="selected" @endif>96 kg (212 lb)</option>
										<option value="97" @if($userAppericens->weight == 97)selected="selected" @endif>97 kg (214 lb)</option>
										<option value="98" @if($userAppericens->weight == 98)selected="selected" @endif>98 kg (216 lb)</option>
										<option value="99" @if($userAppericens->weight == 99)selected="selected" @endif>99 kg (218 lb)</option>
										<option value="100" @if($userAppericens->weight == 100)selected="selected" @endif>100 kg (220 lb)</option>
										<option value="101" @if($userAppericens->weight == 101)selected="selected" @endif>101 kg (223 lb)</option>
										<option value="102" @if($userAppericens->weight == 102)selected="selected" @endif>102 kg (225 lb)</option>
										<option value="103" @if($userAppericens->weight == 103)selected="selected" @endif>103 kg (227 lb)</option>
										<option value="104" @if($userAppericens->weight == 104)selected="selected" @endif>104 kg (229 lb)</option>
										<option value="105" @if($userAppericens->weight == 105)selected="selected" @endif>105 kg (231 lb)</option>
										<option value="106" @if($userAppericens->weight == 106)selected="selected" @endif>106 kg (234 lb)</option>
										<option value="107" @if($userAppericens->weight == 107)selected="selected" @endif>107 kg (236 lb)</option>
										<option value="108" @if($userAppericens->weight == 108)selected="selected" @endif>108 kg (238 lb)</option>
										<option value="109" @if($userAppericens->weight == 109)selected="selected" @endif>109 kg (240 lb)</option>
										<option value="110" @if($userAppericens->weight == 110)selected="selected" @endif>110 kg (243 lb)</option>
										<option value="111" @if($userAppericens->weight == 111)selected="selected" @endif>111 kg (245 lb)</option>
										<option value="112" @if($userAppericens->weight == 112)selected="selected" @endif>112 kg (247 lb)</option>
										<option value="113" @if($userAppericens->weight == 113)selected="selected" @endif>113 kg (249 lb)</option>
										<option value="114" @if($userAppericens->weight == 114)selected="selected" @endif>114 kg (251 lb)</option>
										<option value="115" @if($userAppericens->weight == 115)selected="selected" @endif>115 kg (254 lb)</option>
										<option value="116" @if($userAppericens->weight == 119)selected="selected" @endif>116 kg (256 lb)</option>
										<option value="117" @if($userAppericens->weight == 117)selected="selected" @endif>117 kg (258 lb)</option>
										<option value="118" @if($userAppericens->weight == 119)selected="selected" @endif>118 kg (260 lb)</option>
										<option value="119" @if($userAppericens->weight == 119)selected="selected" @endif>119 kg (262 lb)</option>
										<option value="120" @if($userAppericens->weight == 120)selected="selected" @endif>120 kg (265 lb)</option>
										<option value="121" @if($userAppericens->weight == 121)selected="selected" @endif>121 kg (267 lb)</option>
										<option value="122" @if($userAppericens->weight == 122)selected="selected" @endif>122 kg (269 lb)</option>
										<option value="123" @if($userAppericens->weight == 123)selected="selected" @endif>123 kg (271 lb)</option>
										<option value="124" @if($userAppericens->weight == 124)selected="selected" @endif>124 kg (273 lb)</option>
										<option value="125" @if($userAppericens->weight == 125)selected="selected" @endif>125 kg (276 lb)</option>
										<option value="126" @if($userAppericens->weight == 126)selected="selected" @endif>126 kg (278 lb)</option>
										<option value="127" @if($userAppericens->weight == 127)selected="selected" @endif>127 kg (280 lb)</option>
										<option value="128" @if($userAppericens->weight == 128)selected="selected" @endif>128 kg (282 lb)</option>
										<option value="129" @if($userAppericens->weight == 129)selected="selected" @endif>129 kg (284 lb)</option>
										<option value="130" @if($userAppericens->weight == 130)selected="selected" @endif>130 kg (287 lb)</option>
										<option value="131" @if($userAppericens->weight == 131)selected="selected" @endif>131 kg (289 lb)</option>
										<option value="132" @if($userAppericens->weight == 132)selected="selected" @endif>132 kg (291 lb)</option>
										<option value="133" @if($userAppericens->weight == 133)selected="selected" @endif>133 kg (293 lb)</option>
										<option value="134" @if($userAppericens->weight == 134)selected="selected" @endif>134 kg (295 lb)</option>
										<option value="135" @if($userAppericens->weight == 135)selected="selected" @endif>135 kg (298 lb)</option>
										<option value="136" @if($userAppericens->weight == 136)selected="selected" @endif>136 kg (300 lb)</option>
										<option value="137" @if($userAppericens->weight == 137)selected="selected" @endif>137 kg (302 lb)</option>
										<option value="138" @if($userAppericens->weight == 138)selected="selected" @endif>138 kg (304 lb)</option>
										<option value="139" @if($userAppericens->weight == 139)selected="selected" @endif>139 kg (306 lb)</option>
										<option value="140" @if($userAppericens->weight == 140)selected="selected" @endif>140 kg (309 lb)</option>
										<option value="141" @if($userAppericens->weight == 141)selected="selected" @endif>141 kg (311 lb)</option>
										<option value="142" @if($userAppericens->weight == 142)selected="selected" @endif>142 kg (313 lb)</option>
										<option value="143" @if($userAppericens->weight == 143)selected="selected" @endif>143 kg (315 lb)</option>
										<option value="144" @if($userAppericens->weight == 144)selected="selected" @endif>144 kg (317 lb)</option>
										<option value="145" @if($userAppericens->weight == 145)selected="selected" @endif>145 kg (320 lb)</option>
										<option value="146" @if($userAppericens->weight == 146)selected="selected" @endif>146 kg (322 lb)</option>
										<option value="147" @if($userAppericens->weight == 147)selected="selected" @endif>147 kg (324 lb)</option>
										<option value="148" @if($userAppericens->weight == 148)selected="selected" @endif>148 kg (326 lb)</option>
										<option value="149" @if($userAppericens->weight == 149)selected="selected" @endif>149 kg (328 lb)</option>
										<option value="150" @if($userAppericens->weight == 150)selected="selected" @endif>150 kg (331 lb)</option>
										<option value="151" @if($userAppericens->weight == 151)selected="selected" @endif>151 kg (333 lb)</option>
										<option value="152" @if($userAppericens->weight == 152)selected="selected" @endif>152 kg (335 lb)</option>
										<option value="153" @if($userAppericens->weight == 153)selected="selected" @endif>153 kg (337 lb)</option>
										<option value="154" @if($userAppericens->weight == 154)selected="selected" @endif>154 kg (340 lb)</option>
										<option value="155" @if($userAppericens->weight == 155)selected="selected" @endif>155 kg (342 lb)</option>
										<option value="156" @if($userAppericens->weight == 156)selected="selected" @endif>156 kg (344 lb)</option>
										<option value="157" @if($userAppericens->weight == 157)selected="selected" @endif>157 kg (346 lb)</option>
										<option value="158" @if($userAppericens->weight == 158)selected="selected" @endif>158 kg (348 lb)</option>
										<option value="159" @if($userAppericens->weight == 159)selected="selected" @endif>159 kg (351 lb)</option>
										<option value="160" @if($userAppericens->weight == 160)selected="selected" @endif>160 kg (353 lb)</option>
										<option value="161" @if($userAppericens->weight == 161)selected="selected" @endif>161 kg (355 lb)</option>
										<option value="162" @if($userAppericens->weight == 162)selected="selected" @endif>162 kg (357 lb)</option>
										<option value="163" @if($userAppericens->weight == 163)selected="selected" @endif>163 kg (359 lb)</option>
										<option value="164" @if($userAppericens->weight == 164)selected="selected" @endif>164 kg (362 lb)</option>
										<option value="165" @if($userAppericens->weight == 165)selected="selected" @endif>165 kg (364 lb)</option>
										<option value="166" @if($userAppericens->weight == 166)selected="selected" @endif>166 kg (366 lb)</option>
										<option value="167" @if($userAppericens->weight == 167)selected="selected" @endif>167 kg (368 lb)</option>
										<option value="168" @if($userAppericens->weight == 168)selected="selected" @endif>168 kg (370 lb)</option>
										<option value="169" @if($userAppericens->weight == 169)selected="selected" @endif>169 kg (373 lb)</option>
										<option value="170" @if($userAppericens->weight == 170)selected="selected" @endif>170 kg (375 lb)</option>
										<option value="171" @if($userAppericens->weight == 171)selected="selected" @endif>171 kg (377 lb)</option>
										<option value="172" @if($userAppericens->weight == 172)selected="selected" @endif>172 kg (379 lb)</option>
										<option value="173" @if($userAppericens->weight == 173)selected="selected" @endif>173 kg (381 lb)</option>
										<option value="174" @if($userAppericens->weight == 174)selected="selected" @endif>174 kg (384 lb)</option>
										<option value="175" @if($userAppericens->weight == 175)selected="selected" @endif>175 kg (386 lb)</option>
										<option value="176" @if($userAppericens->weight == 176)selected="selected" @endif>176 kg (388 lb)</option>
										<option value="177" @if($userAppericens->weight == 177)selected="selected" @endif>177 kg (390 lb)</option>
										<option value="178" @if($userAppericens->weight == 178)selected="selected" @endif>178 kg (392 lb)</option>
										<option value="179" @if($userAppericens->weight == 179)selected="selected" @endif>179 kg (395 lb)</option>
										<option value="180" @if($userAppericens->weight == 180)selected="selected" @endif>180 kg (397 lb)</option>
										<option value="181" @if($userAppericens->weight == 181)selected="selected" @endif>181 kg (399 lb)</option>
										<option value="182" @if($userAppericens->weight == 182)selected="selected" @endif>182 kg (401 lb)</option>
										<option value="183" @if($userAppericens->weight == 183)selected="selected" @endif>183 kg (403 lb)</option>
										<option value="184" @if($userAppericens->weight == 184)selected="selected" @endif>184 kg (406 lb)</option>
										<option value="185" @if($userAppericens->weight == 185)selected="selected" @endif>185 kg (408 lb)</option>
										<option value="186" @if($userAppericens->weight == 186)selected="selected" @endif>186 kg (410 lb)</option>
										<option value="187" @if($userAppericens->weight == 187)selected="selected" @endif>187 kg (412 lb)</option>
										<option value="188" @if($userAppericens->weight == 188)selected="selected" @endif>188 kg (414 lb)</option>
										<option value="189" @if($userAppericens->weight == 189)selected="selected" @endif>189 kg (417 lb)</option>
										<option value="190" @if($userAppericens->weight == 190)selected="selected" @endif>190 kg (419 lb)</option>
										<option value="191" @if($userAppericens->weight == 191)selected="selected" @endif>191 kg (421 lb)</option>
										<option value="192" @if($userAppericens->weight == 192)selected="selected" @endif>192 kg (423 lb)</option>
										<option value="193" @if($userAppericens->weight == 193)selected="selected" @endif>193 kg (425 lb)</option>
										<option value="194" @if($userAppericens->weight == 194)selected="selected" @endif>194 kg (428 lb)</option>
										<option value="195" @if($userAppericens->weight == 195)selected="selected" @endif>195 kg (430 lb)</option>
										<option value="196" @if($userAppericens->weight == 196)selected="selected" @endif>196 kg (432 lb)</option>
										<option value="197" @if($userAppericens->weight == 197)selected="selected" @endif>197 kg (434 lb)</option>
										<option value="198" @if($userAppericens->weight == 198)selected="selected" @endif>198 kg (437 lb)</option>
										<option value="199" @if($userAppericens->weight == 190)selected="selected" @endif>199 kg (439 lb)</option>
										<option value="200" @if($userAppericens->weight == 200)selected="selected" @endif>200 kg (441 lb)</option>
										<option value="201" @if($userAppericens->weight == 201)selected="selected" @endif>201 kg (443 lb)</option>
										<option value="202" @if($userAppericens->weight == 202)selected="selected" @endif>202 kg (445 lb)</option>
										<option value="203" @if($userAppericens->weight == 203)selected="selected" @endif>203 kg (448 lb)</option>
										<option value="204" @if($userAppericens->weight == 204)selected="selected" @endif>204 kg (450 lb)</option>
										<option value="205" @if($userAppericens->weight == 205)selected="selected" @endif>205 kg (452 lb)</option>
										<option value="206" @if($userAppericens->weight == 206)selected="selected" @endif>206 kg (454 lb)</option>
										<option value="207" @if($userAppericens->weight == 207)selected="selected" @endif>207 kg (456 lb)</option>
										<option value="208" @if($userAppericens->weight == 208)selected="selected" @endif>208 kg (459 lb)</option>
										<option value="209" @if($userAppericens->weight == 209)selected="selected" @endif>209 kg (461 lb)</option>
										<option value="210" @if($userAppericens->weight == 210)selected="selected" @endif>210 kg (463 lb)</option>
										<option value="211" @if($userAppericens->weight == 211)selected="selected" @endif>211 kg (465 lb)</option>
										<option value="212" @if($userAppericens->weight == 212)selected="selected" @endif>212 kg (467 lb)</option>
										<option value="213" @if($userAppericens->weight == 213)selected="selected" @endif>213 kg (470 lb)</option>
										<option value="214" @if($userAppericens->weight == 214)selected="selected" @endif>214 kg (472 lb)</option>
										<option value="215" @if($userAppericens->weight == 215)selected="selected" @endif>215 kg (474 lb)</option>
										<option value="216" @if($userAppericens->weight == 216)selected="selected" @endif>216 kg (476 lb)</option>
										<option value="217" @if($userAppericens->weight == 217)selected="selected" @endif>217 kg (478 lb)</option>
										<option value="218" @if($userAppericens->weight == 218)selected="selected" @endif>218 kg (481 lb)</option>
										<option value="219" @if($userAppericens->weight == 219)selected="selected" @endif>219 kg (483 lb)</option>
										<option value="220" @if($userAppericens->weight == 220)selected="selected" @endif>220 kg (485 lb)</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Body type:</div>  
								<div class="col-md-6">
									<select class="" name="body_type" id="body_type" required>
										<option value="">Please Select</option>
										<option value="Petite" @if($userAppericens->body_type == "Petite")selected="selected" @endif>Petite</option>
										<option value="Slim" @if($userAppericens->body_type == "Slim")selected="selected" @endif>Slim</option>
										<option value="Athletic" @if($userAppericens->body_type == "Athletic")selected="selected" @endif>Athletic</option>
										<option value="Average" @if($userAppericens->body_type == "Average")selected="selected" @endif>Average</option>
										<option value="Few Extra Pounds" @if($userAppericens->body_type == "Few Extra Pounds")selected="selected" @endif>Few Extra Pounds</option>
										<option value="Full Figured" @if($userAppericens->body_type == "Full Figured")selected="selected" @endif>Full Figured</option>
										<option value="Large and Lovely" @if($userAppericens->body_type == "Large and Lovely")selected="selected" @endif>Large and Lovely</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Your ethnicity is mostly:</div>  
								<div class="col-md-6">
									<select class="" name="ethnicity" id="ethnicity" required>
										<option value="">Please Select</option>
										<option value="Arab (Middle Eastern)" @if($userAppericens->ethnicity == "Arab (Middle Eastern)")selected="selected" @endif>Arab (Middle Eastern)</option>
										<option value="Asian" @if($userAppericens->ethnicity == "Asian")selected="selected" @endif>Asian</option>
										<option value="Black" @if($userAppericens->ethnicity == "Black")selected="selected" @endif>Black</option>
										<option value="Caucasian" @if($userAppericens->ethnicity == "Caucasian")selected="selected" @endif>Caucasian (White)</option>
										<option value="Hispanic / Latino" @if($userAppericens->ethnicity == "Hispanic / Latino")selected="selected" @endif>Hispanic / Latino</option>
										<option value="Indian" @if($userAppericens->ethnicity == "Indian")selected="selected" @endif>Indian</option>
										<option value="Mixed" @if($userAppericens->ethnicity == "Mixed")selected="selected" @endif>Mixed</option>
										<option value="Pacific Islander" @if($userAppericens->ethnicity == "Pacific Islander")selected="selected" @endif>Pacific Islander</option>
										<option value="Other" @if($userAppericens->ethnicity == "Other")selected="selected" @endif>Other</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Facial hair:</div>  
								<div class="col-md-6">
									<select class="" name="facial_hair" id="facial_hair" required>
										<option value="">Please Select</option>
										<option value="Clean Shaven" @if($userAppericens->facial_hair == "Clean Shaven")selected="selected" @endif>Clean Shaven</option>
										<option value="Sideburns" @if($userAppericens->facial_hair == "Sideburns")selected="selected" @endif>Sideburns</option>
										<option value="Mustache" @if($userAppericens->facial_hair == "Mustache")selected="selected" @endif>Mustache</option>
										<option value="4Goatee" @if($userAppericens->facial_hair == "Goatee")selected="selected" @endif>Goatee</option>
										<option value="Short Beard" @if($userAppericens->facial_hair == "Short Beard")selected="selected" @endif>Short Beard</option>
										<option value="Medium Beard" @if($userAppericens->facial_hair == "Medium Beard")selected="selected" @endif>Medium Beard</option>
										<option value="Long Beard" @if($userAppericens->facial_hair == "Long Beard")selected="selected" @endif>Long Beard</option>
										<option value="Prefer not to say" @if($userAppericens->facial_hair == "Prefer not to say")selected="selected" @endif>Prefer not to say</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">My best feature:</div>  
								<div class="col-md-6">
									<select class="" name="best_feature" id="best_feature" required>
										<option value="">Please Select</option>
										<option value="My Arms" @if($userAppericens->best_feature == "My Arms")selected="selected" @endif>My Arms</option>
										<option value="My Butt" @if($userAppericens->best_feature == "My Butt")selected="selected" @endif>My Butt</option>
										<option value="My Chest" @if($userAppericens->best_feature == "My Chest")selected="selected" @endif>My Chest</option>
										<option value="My Eyes" @if($userAppericens->best_feature == "My Eyes")selected="selected" @endif>My Eyes</option>
										<option value="My Hands" @if($userAppericens->best_feature == "My Hands")selected="selected" @endif>My Hands</option>
										<option value="My Legs" @if($userAppericens->best_feature == "My Legs")selected="selected" @endif>My Legs</option>
										<option value="My Lips" @if($userAppericens->best_feature == "My Lips")selected="selected" @endif>My Lips</option>
										<option value="My Personality" @if($userAppericens->best_feature == "My Personality")selected="selected" @endif>My Personality</option>
										<option value="9" @if($userAppericens->best_feature == "My Smile")selected="selected" @endif>My Smile</option>
										<option value="My Wallet" @if($userAppericens->best_feature == "My Wallet")selected="selected" @endif>My Wallet</option>
										<option value="If You're lucky I'll show you later" @if($userAppericens->best_feature == "If You're lucky I'll show you later")selected="selected" @endif>If You're lucky I'll show you later</option>
										<option value="Other" @if($userAppericens->best_feature == "Other")selected="selected" @endif>Other</option>
										<option value="Don't Know" @if($userAppericens->best_feature == "Don't Know")selected="selected" @endif>Don't Know</option>
										<option value="Prefer not to say" @if($userAppericens->best_feature == "Prefer not to say")selected="selected" @endif>Prefer not to say</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Body art:</div>  
								<div class="col-md-6">
									<select class="" name="body_art" id="body_art" required>
										<option value="">Please Select</option>
										<option value="Branding" @if($userAppericens->body_art == "Branding")selected="selected" @endif>Branding</option>
										<option value="Earrings" @if($userAppericens->body_art == "Earrings")selected="selected" @endif>Earrings</option>
										<option value="Piercing" @if($userAppericens->body_art == "Piercing")selected="selected" @endif>Piercing</option>
										<option value="Tattoo" @if($userAppericens->body_art == "Tattoo")selected="selected" @endif>Tattoo</option>
										<option value="Other" @if($userAppericens->body_art == "Other")selected="selected" @endif>Other</option>
										<option value="None" @if($userAppericens->body_art == "None")selected="selected" @endif>None</option>
										<option value="Prefer not to say" @if($userAppericens->body_art == "Prefer not to say")selected="selected" @endif>Prefer not to say</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">I consider my appearance as:</div>  
								<div class="col-md-6">
									<select class="" name="appearance" id="appearance" required>
										<option value="">Please Select</option>
										<option value="Below average" @if($userAppericens->appearance == "Below average")selected="selected" @endif>Below average</option>
										<option value="Average" @if($userAppericens->appearance == "Average")selected="selected" @endif>Average</option>
										<option value="Attractive" @if($userAppericens->appearance == "Attractive")selected="selected" @endif>Attractive</option>
										<option value="Very attractive" @if($userAppericens->appearance == "Very attractive")selected="selected" @endif>Very attractive</option>
									</select>
								</div>
							</div>
						</div>
						<span class="sectionHeading clearfix">
							<h2>Your Lifestyle</h2>
						</span>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Do you drink?</div>  
								<div class="col-md-6">
									<select class="" name="drink" id="drink" required>
										<option value="">Please Select</option>
										<option value="Do drink" @if($userLifestyle->drink == "Do drink")selected="selected" @endif>Do drink</option>
										<option value="Don't drink" @if($userLifestyle->drink == "Don't drink")selected="selected" @endif>Don't drink</option>
										<option value="Occasionally drink" @if($userLifestyle->drink == "Occasionally drink")selected="selected" @endif>Occasionally drink</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Do you smoke?</div>  
								<div class="col-md-6">
									<select class="" name="smoke" id="smoke" required>
										<option value="">Please Select</option>
										<option value="Do smoke" @if($userLifestyle->smoke == "Do smoke")selected="selected" @endif>Do smoke</option>
										<option value="Don't smoke" @if($userLifestyle->smoke == "Don't smoke")selected="selected" @endif>Don't smoke</option>
										<option value="Occasionally smoke" @if($userLifestyle->smoke == "Occasionally smoke")selected="selected" @endif>Occasionally smoke</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Marital Status:</div>  
								<div class="col-md-6">
									<select class="" name="marital_status" id="marital_status" required>
										<option value="">Please Select</option>
										<option value="Single" @if($userLifestyle->marital_status == "Single")selected="selected" @endif>Single</option>
										<option value="Separated" @if($userLifestyle->marital_status == "Separated")selected="selected" @endif>Separated</option>
										<option value="Widowed" @if($userLifestyle->marital_status == "Widowed")selected="selected" @endif>Widowed</option>
										<option value="Divorced" @if($userLifestyle->marital_status == "Divorced")selected="selected" @endif>Divorced</option>
										<option value="Other" @if($userLifestyle->marital_status == "Other")selected="selected" @endif>Other</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Do you have children?</div>  
								<div class="col-md-6">
									<select class="" name="children_have" id="children_have" required>
										<option value="">Please Select</option>
										<option value="No" @if($userLifestyle->children_have == "No")selected="selected" @endif >No</option>
										<option value="Yes - don't live at home" @if($userLifestyle->children_have == "Yes - don't live at home")selected="selected" @endif>Yes - don't live at home</option>
										<option value="Yes - sometimes live at home" @if($userLifestyle->children_have == "Yes - sometimes live at home")selected="selected" @endif>Yes - sometimes live at home</option>
										<option value="Yes - live at home" @if($userLifestyle->children_have == "Yes - live at home")selected="selected" @endif>Yes - live at home</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Number of children:</div>  
								<div class="col-md-6">
									<select class="" name="children_number" id="children_number" required>
										<option value="">Please Select</option>
										<option value="0" @if($userLifestyle->children_number == 0)selected="selected" @endif>0</option>
										<option value="1" @if($userLifestyle->children_number == 1)selected="selected" @endif>1</option>
										<option value="2" @if($userLifestyle->children_number == 2)selected="selected" @endif>2</option>
										<option value="3" @if($userLifestyle->children_number == 3)selected="selected" @endif>3</option>
										<option value="4" @if($userLifestyle->children_number == 4)selected="selected" @endif>4</option>
										<option value="5" @if($userLifestyle->children_number == 5)selected="selected" @endif>5</option>
										<option value="6" @if($userLifestyle->children_number == 6)selected="selected" @endif>6</option>
										<option value="7" @if($userLifestyle->children_number == 7)selected="selected" @endif>7</option>
										<option value="8" @if($userLifestyle->children_number == 8)selected="selected" @endif>8</option>
										<option value="More than 8" @if($userLifestyle->children_number == "More than 8")selected="selected" @endif>More than 8</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Oldest child:</div>  
								<div class="col-md-6">
									<select class="" name="children_oldest" id="children_oldest" required>
										<option value="">Please Select</option>
										<option value="0" @if($userLifestyle->children_oldest == 0)selected="selected" @endif>0</option>
										<option value="1" @if($userLifestyle->children_oldest == 1)selected="selected" @endif>1</option>
										<option value="2" @if($userLifestyle->children_oldest == 2)selected="selected" @endif>2</option>
										<option value="3" @if($userLifestyle->children_oldest == 3)selected="selected" @endif>3</option>
										<option value="4" @if($userLifestyle->children_oldest == 4)selected="selected" @endif>4</option>
										<option value="5" @if($userLifestyle->children_oldest == 5)selected="selected" @endif>5</option>
										<option value="6" @if($userLifestyle->children_oldest == 6)selected="selected" @endif>6</option>
										<option value="7" @if($userLifestyle->children_oldest == 7)selected="selected" @endif>7</option>
										<option value="8" @if($userLifestyle->children_oldest == 8)selected="selected" @endif>8</option>
										<option value="9" @if($userLifestyle->children_oldest == 9)selected="selected" @endif>9</option>
										<option value="10" @if($userLifestyle->children_oldest == 10)selected="selected" @endif>10</option>
										<option value="11" @if($userLifestyle->children_oldest == 11)selected="selected" @endif>11</option>
										<option value="12" @if($userLifestyle->children_oldest == 12)selected="selected" @endif>12</option>
										<option value="13" @if($userLifestyle->children_oldest == 13)selected="selected" @endif>13</option>
										<option value="14" @if($userLifestyle->children_oldest == 14)selected="selected" @endif>14</option>
										<option value="15" @if($userLifestyle->children_oldest == 15)selected="selected" @endif>15</option>
										<option value="16" @if($userLifestyle->children_oldest == 16)selected="selected" @endif>16</option>
										<option value="17" @if($userLifestyle->children_oldest == 17)selected="selected" @endif>17</option>
										<option value="18" @if($userLifestyle->children_oldest == 18)selected="selected" @endif>18</option>
										<option value="Older than 18" @if($userLifestyle->children_oldest == "Older than 18")selected="selected" @endif>Older than 18</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Youngest child:</div>  
								<div class="col-md-6">
									<select class="" name="youngest_child" id="youngest_child" required>
										<option value="">Please Select</option>
										<option value="0" @if($userLifestyle->youngest_child == 0)selected="selected" @endif>0</option>
										<option value="1" @if($userLifestyle->youngest_child == 1)selected="selected" @endif>1</option>
										<option value="2" @if($userLifestyle->youngest_child == 3)selected="selected" @endif>3</option>
										<option value="4" @if($userLifestyle->youngest_child == 4)selected="selected" @endif>4</option>
										<option value="5" @if($userLifestyle->youngest_child == 5)selected="selected" @endif>5</option>
										<option value="6" @if($userLifestyle->youngest_child == 6)selected="selected" @endif>6</option>
										<option value="7" @if($userLifestyle->youngest_child == 7)selected="selected" @endif>7</option>
										<option value="8" @if($userLifestyle->youngest_child == 8)selected="selected" @endif>8</option>
										<option value="9" @if($userLifestyle->youngest_child == 9)selected="selected" @endif>9</option>
										<option value="10" @if($userLifestyle->youngest_child == 10)selected="selected" @endif>10</option>
										<option value="11" @if($userLifestyle->youngest_child == 11)selected="selected" @endif>11</option>
										<option value="12" @if($userLifestyle->youngest_child == 12)selected="selected" @endif>12</option>
										<option value="13" @if($userLifestyle->youngest_child == 13)selected="selected" @endif>13</option>
										<option value="14" @if($userLifestyle->youngest_child == 14)selected="selected" @endif>14</option>
										<option value="15" @if($userLifestyle->youngest_child == 15)selected="selected" @endif>15</option>
										<option value="16" @if($userLifestyle->youngest_child == 16)selected="selected" @endif>16</option>
										<option value="17" @if($userLifestyle->youngest_child == 17)selected="selected" @endif>17</option>
										<option value="18" @if($userLifestyle->youngest_child == 18)selected="selected" @endif>18</option>
										<option value="Older than 18" @if($userLifestyle->youngest_child == "Older than 18")selected="selected" @endif>Older than 18</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Do you want (more) children?</div>  
								<div class="col-md-6">
									<select class="" name="children_want" id="children_want" required>
										<option value="">Please Select</option>
										<option value="Yes" @if($userLifestyle->children_want == "Yes")selected="selected" @endif>Yes</option>
										<option value="Not Sure" @if($userLifestyle->children_want == "Not Sure")selected="selected" @endif>Not Sure</option>
										<option value="No" @if($userLifestyle->children_want == "No")selected="selected" @endif>No</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Occupation</div>  
								<div class="col-md-6">
									<select class="" name="occupation" id="occupation" required>
										<option value="">Please Select</option>
										<option value="Administrative / Secretarial / Clerical" @if($userLifestyle->occupation == "Administrative / Secretarial / Clerical")selected="selected" @endif>Administrative / Secretarial / Clerical</option>
										<option value="Advertising / Media" @if($userLifestyle->occupation == "Advertising / Media")selected="selected" @endif>Advertising / Media</option>
										<option value="Artistic / Creative / Performance" @if($userLifestyle->occupation == "Artistic / Creative / Performance")selected="selected" @endif>Artistic / Creative / Performance</option>
										<option value="Construction" @if($userLifestyle->occupation == "Construction")selected="selected" @endif>Construction / Trades</option>
										<option value="Domestic Helper" @if($userLifestyle->occupation == "Domestic Helper")selected="selected" @endif>Domestic Helper</option>
										<option value="Education / Academic" @if($userLifestyle->occupation == "Education / Academic")selected="selected" @endif>Education / Academic</option>
										<option value="Entertainment / Media" @if($userLifestyle->occupation == "Entertainment / Media")selected="selected" @endif>Entertainment / Media</option>
										<option value="Executive / Management / HR" @if($userLifestyle->occupation == "Executive / Management / HR")selected="selected" @endif>Executive / Management / HR</option>
										<option value="Farming / Agriculture" @if($userLifestyle->occupation == "Farming / Agriculture")selected="selected" @endif>Farming / Agriculture</option>
										<option value="Finance / Banking / Real Estate" @if($userLifestyle->occupation == "Finance / Banking / Real Estate")selected="selected" @endif>Finance / Banking / Real Estate</option>
										<option value="Fire / law enforcement / security" @if($userLifestyle->occupation == "Fire / law enforcement / security")selected="selected" @endif>Fire / law enforcement / security</option>
										<option value="Hair Dresser / Personal Grooming" @if($userLifestyle->occupation == "Hair Dresser / Personal Grooming")selected="selected" @endif>Hair Dresser / Personal Grooming</option>
										<option value="IT / Communications" @if($userLifestyle->occupation == "IT / Communications")selected="selected" @endif>IT / Communications</option>
										<option value="Laborer / Manufacturing" @if($userLifestyle->occupation == "Laborer / Manufacturing")selected="selected" @endif>Laborer / Manufacturing</option>
										<option value="Legal" @if($userLifestyle->occupation == "Legal")selected="selected" @endif>Legal</option>
										<option value="Medical / Dental / Veterinary" @if($userLifestyle->occupation == "Medical / Dental / Veterinary")selected="selected" @endif>Medical / Dental / Veterinary</option>
										<option value="Military" @if($userLifestyle->occupation == "Military")selected="selected" @endif>Military</option>
										<option value="Nanny / Child care" @if($userLifestyle->occupation == "Nanny / Child care")selected="selected" @endif>Nanny / Child care</option>
										<option value="No occupation / Stay at home" @if($userLifestyle->occupation == "No occupation / Stay at home")selected="selected" @endif>No occupation / Stay at home</option>
										<option value="Non-profit / clergy / social services" @if($userLifestyle->occupation == "Non-profit / clergy / social services")selected="selected" @endif>Non-profit / clergy / social services</option>
										<option value="Political / Govt / Civil Service" @if($userLifestyle->occupation == "Political / Govt / Civil Service")selected="selected" @endif>Political / Govt / Civil Service</option>
										<option value="Retail / Food services" @if($userLifestyle->occupation == "Retail / Food services")selected="selected" @endif>Retail / Food services</option>
										<option value="Retired" @if($userLifestyle->occupation == "Retired")selected="selected" @endif>Retired</option>
										<option value="Sales / Marketing" @if($userLifestyle->occupation == "Sales / Marketing")selected="selected" @endif>Sales / Marketing</option>
										<option value="Self Employed" @if($userLifestyle->occupation == "Self Employed")selected="selected" @endif>Self Employed</option>
										<option value="Sports / recreation" @if($userLifestyle->occupation == "Sports / recreation")selected="selected" @endif>Sports / recreation</option>
										<option value="Student" @if($userLifestyle->occupation == "Student")selected="selected" @endif>Student</option>
										<option value="Technical / Science / Engineering" @if($userLifestyle->occupation == "Technical / Science / Engineering")selected="selected" @endif>Technical / Science / Engineering</option>
										<option value="Transportation" @if($userLifestyle->occupation == "Transportation")selected="selected" @endif>Transportation</option>
										<option value="Travel / Hospitality" @if($userLifestyle->occupation == "Travel / Hospitality")selected="selected" @endif>Travel / Hospitality</option>
										<option value="Unemployed" @if($userLifestyle->occupation == "Unemployed")selected="selected" @endif>Unemployed</option>
										<option value="Other" @if($userLifestyle->occupation == "Other")selected="selected" @endif>Other</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Employment status:</div>  
								<div class="col-md-6">
									<select class="" name="employment_status" id="employment_status" required>
										<option value="">Please Select</option>
										<option value="Student" @if($userLifestyle->employment_status == "Student")selected="selected" @endif>Student</option>
										<option value="Part Time" @if($userLifestyle->employment_status == "Part Time")selected="selected" @endif>Part Time</option>
										<option value="Full Time" @if($userLifestyle->employment_status == "Full Time")selected="selected" @endif>Full Time</option>
										<option value="Homemaker" @if($userLifestyle->employment_status == "Homemaker")selected="selected" @endif>Homemaker</option>
										<option value="Retired" @if($userLifestyle->employment_status == "Retired")selected="selected" @endif>Retired</option>
										<option value="Not Employed" @if($userLifestyle->employment_status == "Not Employed")selected="selected" @endif>Not Employed</option>
										<option value="Other" @if($userLifestyle->employment_status == "Other")selected="selected" @endif>Other</option>
										<option value="Prefer not to say" @if($userLifestyle->employment_status == "Prefer not to say")selected="selected" @endif>Prefer not to say</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Home type:</div>  
								<div class="col-md-6">
									<select class="" name="home_type" id="home_type" required>
										<option value="">Please Select</option>
										<option value="Apartment / Flat" @if($userLifestyle->home_type == "Apartment / Flat")selected="selected" @endif>Apartment / Flat</option>
										<option value="Condominium" @if($userLifestyle->home_type == "Condominium")selected="selected" @endif>Condominium</option>
										<option value="Farm" @if($userLifestyle->home_type == "Farm")selected="selected" @endif>Farm</option>
										<option value="House" @if($userLifestyle->home_type == "House")selected="selected" @endif>House</option>
										<option value="Town house" @if($userLifestyle->home_type == "Town house")selected="selected" @endif>Town house</option>
										<option value="Other" @if($userLifestyle->home_type == "Other")selected="selected" @endif>Other</option>
										<option value="Prefer not to say" @if($userLifestyle->home_type == "Prefer not to say")selected="selected" @endif>Prefer not to say</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Living situation:</div>  
								<div class="col-md-6">
									<select class="" name="living_situation" id="living_situation" required>
										<option value="">Please Select</option>
										<option value="Live Alone" @if($userLifestyle->living_situation == "Live Alone")selected="selected" @endif>Live Alone</option>
										<option value="Live with friends" @if($userLifestyle->living_situation == "Live with friends")selected="selected" @endif>Live with friends</option>
										<option value="Live with family" @if($userLifestyle->living_situation == "Live with family")selected="selected" @endif>Live with family</option>
										<option value="Live with kids" @if($userLifestyle->living_situation == "Live with kids")selected="selected" @endif>Live with kids</option>
										<option value="Live with spouse" @if($userLifestyle->living_situation == "Live with spouse")selected="selected" @endif>Live with spouse</option>
										<option value="Other" @if($userLifestyle->living_situation == "Other")selected="selected" @endif>Other</option>
										<option value="Prefer not to say" @if($userLifestyle->living_situation == "Prefer not to say")selected="selected" @endif>Prefer not to say</option>
									</select>
								</div>
							</div>
						</div>
						
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Willing to relocate:</div>  
								<div class="col-md-6">
									<select class="" name="relocate" id="relocate" required>
										<option value="">Please Select</option>
										<option value="Willing to relocate within my country" @if($userLifestyle->relocate == "Willing to relocate within my country")selected="selected" @endif>Willing to relocate within my country</option>
										<option value="Willing to relocate to another country" @if($userLifestyle->relocate == "Willing to relocate to another country")selected="selected" @endif>Willing to relocate to another country</option>
										<option value="Not willing to relocate" @if($userLifestyle->relocate == "Not willing to relocate")selected="selected" @endif>Not willing to relocate</option>
										<option value="Not sure about relocating" @if($userLifestyle->relocate == "Not sure about relocating")selected="selected" @endif>Not sure about relocating</option>
									</select>
								</div>
							</div>
						</div>
						<span class="sectionHeading clearfix">
							<h2>Your Background / Cultural Values</h2>
						</span>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Nationality:</div>  
								<div class="col-md-6">
									<select class="" name="nationality" id="nationality" required>
										<option value="">Please Select</option>
										@foreach($countryList as $item)
											<option value="{{$item->id}}" @if($userBackground->nationality == $item->id)selected="selected" @endif >{{$item->name}}</option>
										@endforeach
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Education:</div>  
								<div class="col-md-6">
									<select class="" name="education" id="education" required>
										<option value="">Please Select</option>
										<option value="Primary (Elementary) School" @if($userBackground->education == "Primary (Elementary) School") selected="selected" @endif>Primary (Elementary) School</option>
										<option value="Middle School / Junior High" @if($userBackground->education == "Middle School / Junior High") selected="selected" @endif>Middle School / Junior High</option>
										<option value="High School" @if($userBackground->education == "High School") selected="selected" @endif>High School</option>
										<option value="Vocational College" @if($userBackground->education == "Vocational College") selected="selected" @endif>Vocational College</option>
										<option value="Bachelors Degree" @if($userBackground->education == "Bachelors Degree") selected="selected" @endif>Bachelors Degree</option>
										<option value="Masters Degree" @if($userBackground->education == "Masters Degree") selected="selected" @endif>Masters Degree</option>
										<option value="PhD or Doctorate" @if($userBackground->education == "PhD or Doctorate") selected="selected" @endif>PhD or Doctorate</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">English language ability:</div>  
								<div class="col-md-6">
									<select class="" name="english_ability" id="english_ability" required>
										<option value="">Please Select</option>
										<option value="None" @if($userBackground->english_ability == "None") selected="selected" @endif>None</option>
										<option value="Some" @if($userBackground->english_ability == "Some") selected="selected" @endif>Some</option>
										<option value="Good" @if($userBackground->english_ability == "Good") selected="selected" @endif>Good</option>
										<option value="Very Good" @if($userBackground->english_ability == "Very Good") selected="selected" @endif>Very Good</option>
										<option value="Fluent" @if($userBackground->english_ability == "Fluent") selected="selected" @endif>Fluent</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Religion:</div>  
								<div class="col-md-6">
									<select class="" name="religion" id="religion" required>
										<option value="">Please Select</option>
										<option value="Bahá'í" @if($userBackground->religion == "Bahá'í") selected="selected" @endif>Bahá'í</option>
										<option value="Buddhist" @if($userBackground->religion == "Buddhist") selected="selected" @endif>Buddhist</option>
										<option value="Christian - Catholic" @if($userBackground->religion == "Christian - Catholic") selected="selected" @endif>Christian - Catholic</option>
										<option value="Christian - Other" @if($userBackground->religion == "Christian - Other") selected="selected" @endif>Christian - Other</option>
										<option value="Christian - Protestant" @if($userBackground->religion == "Christian - Protestant") selected="selected" @endif>Christian - Protestant</option>
										<option value="Hindu" @if($userBackground->religion == "Hindu") selected="selected" @endif>Hindu</option>
										<option value="Islam" @if($userBackground->religion == "Islam") selected="selected" @endif>Islam</option>
										<option value="Jainism" @if($userBackground->religion == "Jainism") selected="selected" @endif>Jainism</option>
										<option value="Jewish" @if($userBackground->religion == "Jewish") selected="selected" @endif>Jewish</option>
										<option value="Parsi" @if($userBackground->religion == "Parsi") selected="selected" @endif>Parsi</option>
										<option value="Shintoism" @if($userBackground->religion == "Shintoism") selected="selected" @endif>Shintoism</option>
										<option value="Sikhism" @if($userBackground->religion == "Sikhism") selected="selected" @endif>Sikhism</option>
										<option value="Taoism" @if($userBackground->religion == "Taoism") selected="selected" @endif>Taoism</option>
										<option value="Other" @if($userBackground->religion == "Other") selected="selected" @endif>Other</option>
										<option value="No religion" @if($userBackground->religion == "No religion") selected="selected" @endif>No religion</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Religious values:</div>  
								<div class="col-md-6">
									<select class="" name="religion_values" id="religion_values" required>
										<option value="">Please Select</option>
										 <option value="Not Religious" @if($userBackground->religion_values == "Not Religious") selected="selected" @endif>Not Religious</option>
										<option value="Religious" @if($userBackground->religion_values == "Religious") selected="selected" @endif>Religious</option>
										<option value="Very Religious" @if($userBackground->religion_values == "Very Religious") selected="selected" @endif>Very Religious</option>
									</select>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Star sign:</div>  
								<div class="col-md-6">
									<select class="" name="star_sign" id="star_sign" required>
										<option value="">Please Select</option>
										<option value="Aquarius" @if($userBackground->star_sign == "Aquarius") selected="selected" @endif>Aquarius</option>
										<option value="Aries" @if($userBackground->star_sign == "Aries") selected="selected" @endif>Aries</option>
										<option value="Cancer" @if($userBackground->star_sign == "Cancer") selected="selected" @endif>Cancer</option>
										<option value="Capricorn" @if($userBackground->star_sign == "Capricorn") selected="selected" @endif>Capricorn</option>
										<option value="Gemini" @if($userBackground->star_sign == "Gemini") selected="selected" @endif>Gemini</option>
										<option value="Leo" @if($userBackground->star_sign == "Leo") selected="selected" @endif>Leo</option>
										<option value="Libra" @if($userBackground->star_sign == "Libra") selected="selected" @endif>Libra</option>
										<option value="Pisces" @if($userBackground->star_sign == "Pisces") selected="selected" @endif>Pisces</option>
										<option value="Sagittarius" @if($userBackground->star_sign == "Sagittarius") selected="selected" @endif>Sagittarius</option>
										<option value="Scorpio" @if($userBackground->star_sign == "Scorpio") selected="selected" @endif>Scorpio</option>
										<option value="Taurus" @if($userBackground->star_sign == "Taurus") selected="selected" @endif>Taurus</option>
										<option value="Virgo" @if($userBackground->star_sign == "Virgo") selected="selected" @endif>Virgo</option>
										<option value="Don't Know" @if($userBackground->star_sign == "Don't Know") selected="selected" @endif>Don't Know</option>
									</select>
								</div>
							</div>
						</div>
						<span class="sectionHeading clearfix">
							<h2>In your own words</h2>
						</span>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">Your profile heading:</div>  
								<div class="col-md-6">
									<input type="text"  class="" name="profile_heading" id="profile_heading" required value="{{Auth::user()->profile_heading}}">
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">A little about yourself:</div>  
								<div class="col-md-6">
									<textarea  name="about_youself" id="about_youself" required>{{Auth::user()->about_yourself}}</textarea>
								</div>
							</div>
						</div>
						<div  class="col-md-12 p-2 border border-top-0 border-left-0 border-right-0">
							<div class="row">
								<div class="col-md-3">What you're looking for in a partner:</div>  
								<div class="col-md-6">
									<textarea  name="looking_partner" id="looking_partner" required>{{Auth::user()->looking_partner}}</textarea>
								</div>
							</div>
						</div>
						<div style="text-align:center;" class="col-md-12">
							<button type="submit" class="btn btn-success">Save</button>
						</div>
					</form>	
				</div>
           </div>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection
