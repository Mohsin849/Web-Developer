@extends('layouts.app')
@section('content')
<style>
.sectionHeading{
	    background-color: #f1f1f1;
    padding-bottom: 10px;
    display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
	display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
    list-style-type: none;
}
.sectionHeading h2 {
    font-size: 14px;
    font-weight: 700;
    float: left;
    width: 450px;
	font-family: inherit;
	line-height: 20px;

}
a, button, input {
	outline: medium none !important;
    color: initial;
}
</style>
<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
      <div class="col-md-12">
        <div class="tab tab-icon clearfix"> 
          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li>
				<a href="{{URL::to('/showemailsettings')}}" >
					<span>Email Address</span>
				</a>
				
			</li>
            <li>
				<a href="{{URL::to('/showpasswordsettings')}}">
					<span>Password</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/showprofilesettings')}}" class="active">
					<span>Profile Settings</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/shownotificationsettings')}}" >
					<span>Notifications</span>
				</a>
			</li>
          </ul>
          <!-- Tab panes -->
			<div class="tab-content">
				@if(session('success'))
					<div class="alert alert-success" role="alert">{{session('success')}}</div>
				@endif
				@if(session('errors'))
					<div class="alert alert-danger" role="alert">{{session('errors')}}</div>
				@endif
				<div role="tabpanel" class="tab-pane fade active in" id="tab2-1">
					<p style="margin-bottom: 0;">
					Update your profile display options and localization.
				</p>
				<span class="sectionHeading clearfix">
					<h2>Online Options:</h2>
				</span>
				<form method="post" data-parsley-validate="">
				@csrf
					
					<div class="col-md-12 mt-3 mb-2">
						<div class="row border border-top-0 border-left-0 border-right-0">
							<div class="col-md-3">Online Status:</div>
							<div class="col-md-9">
								<label class="radio-inline pr-3 text-dark">
									<input type="radio" class="mr-2" value="1" name="onlineStatus" id="onlineStatus" @if(Auth::user()->online_status == 1)checked="checked" @endif>Show me as online
								</label>
								<label class="radio-inline text-dark">
									<input type="radio" class="mr-2" name="onlineStatus" value="2"  id="onlineStatus" @if(Auth::user()->online_status == 2)checked="checked" @endif > Show me as busy 
								</label> 
							</div>
						</div>
					</div>
					<span class="sectionHeading clearfix">
						<h2>Localization:</h2>
					</span>
					<div style="padding-top:20px;" class="col-md-6">
						Country :  
						<span style="float:right;">
							<select style="width:300px;" name="country" id="country" onchange="getState(this);" required>
								<option value="">Country</option>
								@foreach($countryList as $item)
									<option value="{{$item->id}}" @if($item->id == Auth::user()->country)selected="selected" @endif>{{$item->name}}</option>
								@endforeach
							</select>
						</span>
						 <br/><br/>
					</div>
					<div class="col-md-6">
						State :  
						<span style="float:right;">
							<select style="width:300px;" name="state" id="state" onchange="getCity(this);" required>
								<option value="">State</option>
								@foreach($stateList as $item)
									<option value="{{$item->id}}" @if($item->id == Auth::user()->state)selected="selected" @endif>{{$item->name}}</option>
								@endforeach
							</select>
						</span>
						 <br/><br/>
					</div>
					<div class="col-md-6">
						City :  {{Auth::user()->city}}
						<span style="float:right;">
							<select style="width:300px;" name="city" id="city" required>
								<option value="">City</option>
								@foreach($cityList as $item)
									<option value="{{$item->id}}" @if($item->id == Auth::user()->city)selected="selected" @endif>{{$item->name}}</option>
								@endforeach
							</select>
						</span>
						 <br/><br/>
					</div>
					<div style="text-align:center;" class="col-md-12">
						<button type="submit" class="btn btn-success">Save</button>
					</div>
				</form>	
				</div>
           </div>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection
