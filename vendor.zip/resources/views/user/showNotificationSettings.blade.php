@extends('layouts.app')
@section('content')
<style>
.sectionHeading{
	    background-color: #f1f1f1;
    padding-bottom: 10px;
    display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
	display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
    list-style-type: none;
}
.sectionHeading h2 {
    font-size: 14px;
    font-weight: 700;
    float: left;
    width: 450px;
	font-family: inherit;
	line-height: 20px;

}
a, button, input {
	outline: medium none !important;
    color: initial;
}
</style>
<?php 
$newMessage = '';
$intersme = '';
$newmatch = '';
$filpmatch = '';

foreach($notificationList as $item){
	if($item->notification_id==101){
		$newMessage = $item->notification_status;
	}
	if($item->notification_id==102){
		$intersme = $item->notification_status;
	}
	if($item->notification_id==103){
		$newmatch = $item->notification_status;
	}
	if($item->notification_id==104){
		$filpmatch = $item->notification_status;
	}
}
?>
<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
      <div class="col-md-12">
        <div class="tab tab-icon clearfix"> 
          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li>
				<a href="{{URL::to('/showemailsettings')}}" >
					<span>Email Address</span>
				</a>
				
			</li>
            <li>
				<a href="{{URL::to('/showpasswordsettings')}}">
					<span>Password</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/showprofilesettings')}}">
					<span>Profile Settings</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/shownotificationsettings')}}" class="active">
					<span>Notifications</span>
				</a>
			</li>
          </ul>
          <!-- Tab panes -->
          <div class="tab-content">
			@if(session('success'))
				<div class="alert alert-success" role="alert">{{session('success')}}</div>
			@endif
			@if(session('errors'))
				<div class="alert alert-danger" role="alert">{{session('errors')}}</div>
			@endif
            <div role="tabpanel" class="tab-pane fade active in" id="tab2-1">
				<p>Update your email and realtime notifications.</p>
				<span class="sectionHeading clearfix">
					<h2>Email Notifications:</h2>
				</span>
				<form method="post" data-parsley-validate="">
				@csrf
					<div  class="col-md-12 mt-3 mb-2">
						<div class="row border border-top-0 border-left-0 border-right-0">
							<div class="col-md-3">New messages:</div>
							<div class="col-md-9">
								<label class="radio-inline pr-3 text-dark">
									<input type="radio" class="mr-2" name="newMessage" id="newMessage" value="1" @if($newMessage == 1) checked @endif required>Yes
								</label>
								<label class="radio-inline text-dark">
									<input type="radio" class="mr-2" name="newMessage" id="" value="0" @if($newMessage == 0) checked @endif  required>No
								</label> 
							</div>
						</div>
					</div>
					<div  class="col-md-12 mt-3 mb-2">
						<div class="row border border-top-0 border-left-0 border-right-0">
							<div class="col-md-3">Interest in me:</div>
							<div class="col-md-9">
								<label class="radio-inline pr-3 text-dark">
									<input type="radio" class="mr-2" name="interestMe" id="" value="1" @if($intersme == 1) checked @endif required>Yes
								</label>
								<label class="radio-inline text-dark">
									<input type="radio" class="mr-2" name="interestMe" id="" value="0" @if($intersme == 0) checked @endif required>No
								</label> 
							</div>
						</div>
					</div>
					<div  class="col-md-12 mt-3 mb-2">
						<div class="row border border-top-0 border-left-0 border-right-0">
							<div class="col-md-3">New matches:</div>
							<div class="col-md-9">
								<label class="radio-inline pr-3 text-dark">
									<input type="radio" class="mr-2" name="newMatche" id="" value="1" @if($newmatch == 1) checked @endif required>Yes
								</label>
								<label class="radio-inline text-dark">
									<input type="radio" class="mr-2" name="newMatche" id="" value="0" @if($newmatch == 0) checked @endif required>No
								</label> 
							</div>
						</div>
					</div>
					<div  class="col-md-12 mt-3 mb-2">
						<div class="row border border-top-0 border-left-0 border-right-0">
							<div class="col-md-3">FilipinoCupid.com offers and promotions::</div>
							<div class="col-md-9">
								<label class="radio-inline pr-3 text-dark">
									<input type="radio" class="mr-2" name="promotions" id="" value="1" @if($filpmatch == 1) checked @endif required>Yes
								</label>
								<label class="radio-inline text-dark">
									<input type="radio" class="mr-2" name="promotions" id=""  value="0" @if($filpmatch == 0) checked @endif required>No
								</label> 
							</div>
						</div>
					</div>
					<div style="text-align:center;" class="col-md-12">
							<button type="submit" class="btn btn-success">Save</button>
					</div>
				</form>
			</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection
