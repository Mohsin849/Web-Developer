@extends('layouts.app')
@section('content')
<style>
.sectionHeading{
	    background-color: #f1f1f1;
    padding-bottom: 10px;
    display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
	display: block;
    padding: 7px 30px;
    border-bottom: 1px solid #ddd;
    list-style-type: none;
}
.sectionHeading h2 {
    font-size: 14px;
    font-weight: 700;
    float: left;
    width: 450px;
	font-family: inherit;
	line-height: 20px;

}
a, button, input {
	outline: medium none !important;
    color: initial;
}
 div.file {
            position: relative;
            overflow: hidden;
        }
        
        .file input {
            position: absolute;
            font-size: 50px;
            opacity: 0;
            right: 0;
            top: 0;
        }
		.tab.tab-icon .nav-tabs li {
    width: 16.667%;
    text-align: center;
    float: left;
    position: relative;
}
</style>
<section class="page-section-ptb grey-bg">
  <div class="container">
    
      <div class="row">
      <div class="col-md-12">
        <div class="tab tab-icon clearfix"> 
          <!-- Nav tabs -->
          <ul class="nav nav-tabs" role="tablist">
            <li>
				<a href="{{URL::to('/editprofilephotos')}}" class="active">
					<span>Photos</span>
				</a>
				
			</li>
            <li>
				<a href="{{URL::to('/editmyprofile')}}">
					<span>Profile</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editmatchinfo')}}">
					<span>Match</span>
				</a>
			</li>
            <li>
				<a href="{{URL::to('/editinterestinfo')}}" >
					<span>Interest</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/editpersonalityinfo')}}" >
					<span>Personality</span>
				</a>
			</li>
			<li>
				<a href="{{URL::to('/verifyprofile')}}" >
					<span>Verify Profile</span>
				</a>
			</li>
          </ul>
          <!-- Tab panes -->
			<div class="tab-content">
				@if(session('success'))
					<div class="alert alert-success" role="alert">{{session('success')}}</div>
				@endif
				@if(session('errors'))
					<div class="alert alert-danger" role="alert">{{session('errors')}}</div>
				@endif
				<div role="tabpanel" class="tab-pane fade active in" id="tab2-1">
					<div class="card">
                <h4 class="card-header text-center">Upload a photo <span class="font-italic h6">- add 4 more photos to your gallery</span></h4>
                <div class="card-body">
                    <h5 class="card-title text-center">From your computer</h5>
                    <p class="card-text text-center">With supporting text below as a natural lead-in to additional content.</p>
                    <form method="post" data-parsley-validate="" enctype="multipart/form-data">
					@csrf
					<div class="row justify-content-center">
                        <div class="file button btn-lg btn-theme full-rounded animated right-icn">
                            &plus; Upload
                            <input type="file"  name="profileImage" id="profileImage" required />
						</div>
                    </div>
					<div style="text-align:center;" class="col-md-12">
							<button type="submit" class="btn btn-success">Save</button>
						</div>
					</form>

                </div>
                <h5 class="card-header">Photo Guidelines <span class="font-italic h6 float-right">Can't upload photos? Try these alternatives »</span></h5>
                <div class="row m-3">
                    <div class="col-md-2">
                        <div class="card">
                            <img class="card-img-top" src="https://www.simplemost.com/wp-content/uploads/2017/07/531518458_ryan-gosling-750x500.jpg" alt="Card image" style="width:100%">
                            <div class="card-body">
                                <h4 class="card-title text-center">Example</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card">
                            <img class="card-img-top" src="https://www.simplemost.com/wp-content/uploads/2017/07/531518458_ryan-gosling-750x500.jpg" alt="Card image" style="width:100%">
                            <div class="card-body">
                                <h4 class="card-title text-center">Example</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 pl-3">
                        <h5>How to choose the right gallery photos:</h5>
                        <ul style="list-style-type: circle;" class="mt-1">
                            <li>Shows you doing something you enjoy</li>
                            <li>Reflects your personality</li>
                            <li>At least 1 photo shows your full body</li>
                            <li>Shows you in a unique setting (conversation-starters)</li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <br>
                        <ul style="list-style-type: circle;">
                            <li>Clearly shows your face</li>
                            <li>Good quality and well lit</li>
                            <li>MUST contain YOU</li>
                            <li>DOES NOT contain nudity</li>
                        </ul>
                    </div>
                </div>
                <h4 class="card-header text-center">Upload a photo <span class="font-italic h6">- add 4 more photos to your gallery</span></h4>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="card" style="height: 150px;">
							@if(Auth::user()->avatar_1 == '')
								<img src="{{URL::to('/')}}/resources/assets/images/profile/avatar.png" alt="Avatar" class="card-img-top" style="width:100%">
							@else
								<img src="{{URL::to('/')}}/resources/assets/images/profile/{{Auth::user()->avatar_1}}" alt="Avatar" class="card-img-top"  style="height:153px;">
								<!--<h6 class="lead font-weight-bold ml-2">Edit</h6>-->
							@endif
							</div>
                        </div>
						<div class="col-md-2">
                            <div class="card" style="height: 150px;">
							@if(Auth::user()->avatar_2 == '')
								<img src="{{URL::to('/')}}/resources/assets/images/profile/avatar.png" alt="Avatar" class="card-img-top" style="width:100%">
							@else
								<img src="{{URL::to('/')}}/resources/assets/images/profile/{{Auth::user()->avatar_2}}" alt="Avatar" class="card-img-top" style="height:153px;">
								<!--<h6 class="lead font-weight-bold ml-2">Edit</h6>-->
							@endif
							</div>
                        </div>
						<div class="col-md-2">
                            <div class="card" style="height: 150px;">
							@if(Auth::user()->avatar_3 == '')
								<img src="{{URL::to('/')}}/resources/assets/images/profile/avatar.png" alt="Avatar" class="card-img-top" style="width:100%">
							@else
								<img src="{{URL::to('/')}}/resources/assets/images/profile/{{Auth::user()->avatar_3}}" alt="Avatar" class="card-img-top"  style="height:153px;">
								<!--<h6 class="lead font-weight-bold ml-2">Edit</h6>-->
							@endif
							</div>
                        </div>
						<div class="col-md-2">
                            <div class="card" style="height: 150px;">
							@if(Auth::user()->avatar_4 == '')
								<img src="{{URL::to('/')}}/resources/assets/images/profile/avatar.png" alt="Avatar" class="card-img-top" style="width:100%">
							@else
								<img src="{{URL::to('/')}}/resources/assets/images/profile/{{Auth::user()->avatar_4}}" alt="Avatar" class="card-img-top"  style="height:153px;">
								<!--<h6 class="lead font-weight-bold ml-2">Edit</h6>-->
							@endif
							</div>
                        </div>
						<div class="col-md-2">
                            <div class="card" style="height: 150px;">
							@if(Auth::user()->avatar_5 == '')
								<img src="{{URL::to('/')}}/resources/assets/images/profile/avatar.png" alt="Avatar" class="card-img-top" style="width:100%">
							@else
								<img src="{{URL::to('/')}}/resources/assets/images/profile/{{Auth::user()->avatar_5}}" alt="Avatar" class="card-img-top" style="height:153px;">
								<!--<h6 class="lead font-weight-bold ml-2">Edit</h6>-->
							@endif
							</div>
                        </div>
                    </div>
                </div>
            </div>


				</div>
           </div>
        </div>
      </div>
    </div>
  </div>
</section>   
@endsection
