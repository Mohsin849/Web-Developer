@extends('admin/layouts.app')
@section('content')	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Add Slider</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Add Silder</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			<form class="form-horizontal form-bordered" data-parsley-validate="true" role="form" action="{{URL::to('admin/add-slider-data')}}" method="post" files="true" enctype="multipart/form-data">
                 {{ csrf_field() }}
				<div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Title:</label>
                    <div class="col-md-6 col-sm-6">
                        <input type="text" class="form-control" value="" id="sliderTitle" name="sliderTitle" required>
					</div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Description :</label>
                    <div class="col-md-6 col-sm-6">
                        <textarea class="form-control" value="" id="sliderDescription" name="sliderDescription"></textarea>
					</div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Slider Image :</label>
                    <div class="col-md-6 col-sm-6">
                        <input type="file" class="form-control" value="" id="sliderImage" name="sliderImage" required>
					</div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Status :</label>
                    <div class="col-md-6 col-sm-6">
                        <select class="form-control" name="status" id="status" required="">
                            <option value="0" >Active</option>
							<option value="1" >Disabled</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-4 col-sm-4"></label>
                    <div class="col-md-6 col-sm-6">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
		</div>
		
		
	</div>	<!--/.main-->
@endsection