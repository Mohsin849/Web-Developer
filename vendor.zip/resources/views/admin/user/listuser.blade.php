@extends('admin/layouts.app')
@section('content')
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">User Management</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">User Management</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			
            <table class="table table-striped">
                <thead>
                    <tr>

                        <th>Name</th>
                        <th>Email</th>
						<th>Mobile</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
						@foreach($users as $user)
							<tr>
								<td>{{ $user->name }}</td>
								<td>{{ $user->email }}</td>
								<td>{{ $user->phone }}</td>
								<td>
									@if($user->status == 0)
										Unverify Email
									@elseif($user->status == 1)
										Active
									@elseif($user->status == 2)
										Disabled
									@endif	
								</td>
								<td>
									<a href="{{URL::to('/')}}/admin/edit-user/{{$user->id}}" 
									   class="btn btn-success btn-icon btn-circle btn-sm" 
									   title="Edit">Edit
									</a>
									@if($user->is_admin == 0)
									<a href="{{URL::to('/')}}/admin/delete-user/{{$user->id}}" 
									   class="btn btn-success btn-icon btn-circle btn-sm" 
									   title="Delete">Delete
									</a>
									@endif
								</td>
							</tr>
						@endforeach	
				</tbody>
            </table>
		</div>
	</div>	<!--/.main-->
@endsection