@extends('admin/layouts.app')
@section('content')	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
                    <ol class="breadcrumb">
                        <li>
                            <a href="#">
                                <em class="fa fa-home"></em>
                            </a>
                        </li>
                        <li class="active">Edit Mission Text</li>
                    </ol>
		</div><!--/.row-->
		
		<div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Edit Mission Text</h1>
                    </div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
                    <form class="form-horizontal form-bordered" data-parsley-validate="true" role="form" action="{{URL::to('admin/edit-mission-data/1')}}" method="post" files="true" enctype="multipart/form-data">
                    {{ csrf_field() }}
					<div class="form-group">
						<label class="control-label col-md-4 col-sm-4" for="content">Banner Image :</label>
						<div class="col-md-6 col-sm-6">
							<input type="file" class="form-control" value="" id="bannerImage" name="bannerImage">
							<p><img src="{{ asset('public/images/'.$mission->image) }}" width="50px" height="50px"></p>
						</div>
					</div>
					<div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Banner Content:</label>
                        <div class="col-md-6 col-sm-6">
                            <textarea name="banner_description" id="banner_description" rows="6" cols="95">{{$mission->banner_description}}</textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Section One Heading:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="text" class="form-control" value="{{$mission->heading_one}}" id="heading_one" name="heading_one" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Section One Description:</label>
                        <div class="col-md-6 col-sm-6">
                            <textarea name="description_one" id="description_one" rows="4" cols="95">{{$mission->description_one}}</textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Section Two Heading:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="text" class="form-control" value="{{$mission->heading_two}}" id="heading_two" name="heading_two" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Section One Description:</label>
                        <div class="col-md-6 col-sm-6">
                            <textarea name="description_two" id="description_two" rows="4" cols="95">{{$mission->description_two}}</textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Section Three Heading:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="text" class="form-control" value="{{$mission->heading_three}}" id="heading_three" name="heading_three" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Section three Description:</label>
                        <div class="col-md-6 col-sm-6">
                            <textarea name="description_three" id="description_three" rows="4" cols="95">{{$mission->description_three}}</textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4"></label>
                        <div class="col-md-6 col-sm-6">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
	</div>	<!--/.main-->
@endsection