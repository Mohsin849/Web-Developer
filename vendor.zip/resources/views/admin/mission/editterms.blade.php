@extends('admin/layouts.app')
@section('content')	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
                    <ol class="breadcrumb">
                        <li>
                            <a href="#">
                                <em class="fa fa-home"></em>
                            </a>
                        </li>
                        <li class="active">Edit Terms Text</li>
                    </ol>
		</div><!--/.row-->
		
		<div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Edit Terms Text</h1>
                    </div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
                    <form class="form-horizontal form-bordered" data-parsley-validate="true" role="form" action="{{URL::to('admin/edit-terms-data/1')}}" method="post" files="true" enctype="multipart/form-data">
                    {{ csrf_field() }}
                   
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Content:</label>
                        <div class="col-md-6 col-sm-6">
                            <textarea name="content" id="content" rows="10" cols="95">{{$terms->content}}</textarea>
                        </div>
                    </div>
                    
                 
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4"></label>
                        <div class="col-md-6 col-sm-6">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
	</div>	<!--/.main-->
@endsection