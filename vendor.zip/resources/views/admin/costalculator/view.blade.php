@extends('admin/layouts.app')
@section('content')
<style>
  .heading3{
	color: blue;
    margin-bottom: 5px;
    font-size: 22px;
    margin-top: 15px;
}
.subheading{
	color: blue;
    font-size: 14px;
}
.db-inline{
	display:inline-block;
	width:auto;
	height: 35px;
    margin-top: 5px;
    margin-bottom: 5px;
}
.db-bock{
	width:auto;
	height: 35px;
    margin-bottom: 5px;
}
.bg-gray{
	background:lightgrey;
	margin-bottom:5px;
}
.red{
	color:red;
}
.parsley-errors-list{
    margin-left: 0px;
    padding-left: 0px;
}
li.parsley-required {
    color: red;
    list-style: none;
    margin-left: 0px;
    padding-left: 0px;
}
.field-helping{
	color: blue;
    display: block;
    margin-left: 170px;
    font-size: 12px;
}
.field-helping-50{
	color: blue;
    display: block;
    margin-left: 170px;
    font-size: 12px;
}
.field-helping-0{
    color: blue;
    display: block;
    font-size: 12px;
}
.waitsty {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    display: block;
    opacity: 0.7;
    background-color: #fff;
    z-index: 99;
    text-align: center;
    overflow: hidden;
    display: none;
    min-height: 150px;
}
label {
    display: inline-block;
    /* margin-bottom: .5rem; */
}
@media print {
    #footer {
        display: none;
    }
    .navbar.navbar-expand-md {
        display: none;
    }
    .print-header{
         display: none !important;
    }
    .bg-gray {
        background: lightgrey;
        margin-bottom: 5px;
    }
    body { 
        -webkit-print-color-adjust: exact; 
      }
}
.label-width{
	width:165px;
}
</style>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    <div class="row">
        <ol class="breadcrumb">
            <li><a href="#">
                    <em class="fa fa-home"></em>
                </a></li>
            <li class="active">View Detail</li>
        </ol>
    </div><!--/.row-->

    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">View Detail</h1>
        </div>
    </div><!--/.row-->

    <div class="panel panel-container">
        @foreach($costCalculator as $item)
        <div class="row">
            <div class="col-md-6">
                <div class="col-md-12">
                    <h2>Garments Cost Calculation</h2>
                    <h4 style="color:blue;">Garment price is now matter of Clicks</h4>
                    <h5 class="heading3">Style & Order details</h5>
                    <h6 class="subheading">Style,Buyer Order</h6>
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Buyer Name<span class='red' style="margin-right: 90px;">*</span></label>
                    <input type="hidden" value="{{$item->id}}" name="calculationId" id="calculationId">
                    <input type="text" placeholder="Enter Buyer Name" required class="form-control db-inline" value="{{$item->buyerName}}" id="buyerName" readonly="" name="buyerName" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Agent Name</label><span style="margin-right: 100px;"></span>
                    <input type="text" placeholder="Enter Agent Name" class="form-control db-inline" value="{{$item->agentName}}" id="agentName" readonly="" name="agentName" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Style Name<span class='red' style="margin-right: 100px;">*</span></label>
                    <input type="text" placeholder="Enter Style Name" required class="form-control db-inline" value="{{$item->styleName}}" id="styleName" readonly="" name="styleName" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Style Number<span class='red' style="margin-right: 82px;">*</span></label>
                    <input type="text" placeholder="Enter Style Number" required class="form-control db-inline" onchange="styleNumberVerify();" readonly="" value="{{$item->styleNumber}}" id="styleNumber" name="styleNumber" >
                    <p id="messageStylerNumberVerification" style="color:red;"></p>
                    <input type="hidden" value="1" name="stylerNumberVerification" id="stylerNumberVerification">
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Order Number</label><span style="margin-right: 82px;"></span>
                    <input type="text" placeholder="Enter Order Number" class="form-control db-inline" value="{{$item->orderNumber}}" readonly="" id="orderNumber" name="orderNumber" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Order Quanity</label><span style="margin-right: 87px;"></span>
                    <input type="text" placeholder="Enter Order Quanity" class="form-control db-inline" value="{{$item->orderQuanity}}" readonly="" id="orderQuanity" name="orderQuanity" >
                </div>
                <h2 class="heading3">FABRICATION</h2>
                <h5 class="subheading">Febrication Detail</h5>
                <div class="col-md-12 bg-gray">
                    <label>Fabric Colors <span class='red' style="margin-right: 82px;">*</span></label>
                    <select id="fabricColors" name="fabricColors" required class="form-control db-inline" readonly="">
                        <option value="black" @if($item->buyerName == 'black') selected @endif>BLACK</option>
                        <option value="solid" @if($item->buyerName == 'solid') selected @endif>SOLID</option>
                        <option value="average" @if($item->buyerName == 'average') selected @endif>AVERAGE</option>
                        <option value="white" @if($item->buyerName == 'white') selected @endif>WHITE</option>
                    </select>
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Fabric Type<span class='red' style="margin-right: 98px;">*</span></label>
                    <input type="text" placeholder="Eg: 100% Cotton" required class="form-control db-inline" value="{{$item->fabricType}}" readonly="" id="fabricType" name="fabricType" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Yarn Count<span class='red' style="margin-right: 100px;">*</span></label>
                    <input type="text" placeholder="30/1 Combed Yarn" required class="form-control db-inline" value="{{$item->YarnCount}}" readonly="" id="YarnCount" name="YarnCount" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Fabric Weight<span class='red' style="margin-right: 82px;">*</span></label>
                    <input type="text" placeholder="" required class="form-control db-inline" onchange="costFinishFabric();" value="{{$item->fabricWeight}}" readonly="" id="fabricWeight" name="fabricWeight" >
                    <span class="field-helping" style="margin-left:195px;">GSM</span>
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Fabric Wastage<span class='red' style="margin-right: 70px;">*</span></label>
                    <input type="text" placeholder="00%" required class="form-control db-inline" onchange="costFinishFabric();" value="{{$item->fabricWastage}}%" readonly="" id="fabricWastage" name="fabricWastage" >
                    <span class="field-helping" style="margin-left:195px;">% of Wastage</span>
                </div>
                <h2 class="heading3">FINISH FABRIC</h2>
                <h5 class="subheading">Cost of finish Fabric</h5>
                <div class="col-md-12 bg-gray">
                    <label>Yarn Price <span class='red' style="margin-right: 103px;">*</span></label>
                    <input type="text" placeholder="Yarn Price / kg" required class="form-control db-inline" onchange="costFinishFabric();" value="${{$item->yarnPrice}}" readonly="" id="yarnPrice" name="yarnPrice" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Spandex Type</label><span style="margin-right: 87px;"></span>
                    <input type="text" placeholder="Lycra Price / kg" class="form-control db-inline" onchange="costFinishFabric();" value="${{$item->spandexType}}" readonly="" id="spandexType" name="spandexType" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Knitting Cost <span class='red' style="margin-right: 82px;">*</span></label>
                    <input type="text" placeholder="Knitting Cost /kg" required class="form-control db-inline" onchange="costFinishFabric();" value="${{$item->knittingCost}}" readonly="" id="knittingCost" name="knittingCost" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Dying Cost <span class='red' style="margin-right: 96px;">*</span></label>
                    <input type="text" placeholder="Dying Cost / kg" required class="form-control db-inline" onchange="costFinishFabric();" value="${{$item->dyingCost}}" readonly="" id="dyingCost" name="dyingCost" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Yardage Print</label><span style="margin-right: 87px;"></span>
                    <input type="text" placeholder="All Over Print / kg" class="form-control db-inline" onchange="costFinishFabric();" value="${{$item->yardagePrint}}" readonly="" id="yardagePrint" name="yardagePrint" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Wash</label><span style="margin-right: 147px;"></span>
                    <input type="text" placeholder="Wash Cost / kg" class="form-control db-inline" onchange="costFinishFabric();" value="${{$item->wash}}" readonly="" id="wash" name="wash" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Finishing Cost</label><span style="margin-right: 87px;"></span>
                    <input type="text" placeholder="Fabric Finishing Cost /kg" class="form-control db-inline" onchange="costFinishFabric();" value="${{$item->finishCost}}" readonly="" id="finishCost" name="finishCost" >
                </div>
                <div class="col-md-12 bg-gray">
                    <label>Finish Fabric Cost</label><span style="margin-right: 61px;"></span>
                    <input type="text" placeholder="$0" class="form-control db-inline" value="${{$item->finishFabricCost}}" id="finishFabricCost" readonly name="finishFabricCost" >
                </div>
                <h3 class="heading3">TRIMS & ACCESSORIES</h3>
                <h5 class="subheading">Cost of Trims & Accessories</h5>
                <div class="col-md-12" style="background-color:lightgrey">
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label>Sewing Thread<span class='red' style="margin-right: 10px;">*</span></label>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" required class="form-control db-bock" value="${{$item->sewingThread}}" readonly="" id="sewingThread" name="sewingThread">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Care Label</label><span style="margin-right: 11px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->careLabel}}" readonly="" id="careLabel" name="careLabel">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label>Main Label</label><span style="margin-right: 46px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->mainLabel}}" readonly="" id="mainLabel" name="mainLabel">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Size Label</label><span style="margin-right: 16px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->sizeLabel}}" readonly="" id="sizeLabel" name="sizeLabel">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label>Price Sticker</label><span style="margin-right: 36px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->priceSticker}}" readonly="" id="priceSticker" name="priceSticker">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Hang Tag</label><span style="margin-right: 20px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->hangTag}}" readonly="" id="hangTag" name="hangTag">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label>Poly Sticker</label><span style="margin-right: 41px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->polySticker}}" readonly="" id="polySticker" name="polySticker">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Elastic</label><span style="margin-right: 43px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->elastic}}" readonly="" id="elastic" name="elastic">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label>Waist Tag</label><span style="margin-right: 56px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->waistTag}}" readonly="" id="waistTag" name="waistTag">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Poly<span class='red' style="margin-right: 48px;">*</span></label>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" required class="form-control db-bock" value="${{$item->poly}}" readonly="" id="poly" name="poly" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label>Carton <span class='red' style="margin-right: 64px;">*</span></label>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" required class="form-control db-bock" value="${{$item->carton}}" readonly="" id="carton" name="carton">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Carton Sticker</label><span style="margin-right: 16px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->cartonSticker}}" readonly="" id="cartonSticker" name="cartonSticker">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label>Gum / Other Tape</label><span style="margin-right: 32px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->gumTape}}" readonly="" id="gumTape" name="gumTape">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Drawsting</label><span style="margin-right: 16px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->drawsting}}" readonly="" id="drawsting" name="drawsting">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label>Button</label><span style="margin-right: 77px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->button}}" readonly=""id="button" name="button">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Chambray Fabric</label><span style="margin-right: 12px;"></span>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->chambrayFabric}}" readonly="" id="chambrayFabric" name="chambrayFabric">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label><input type="text" name="other1Label" id="other1Label" value="{{$item->other1Label}}" style="width:100px;"></label>
                            <input type="text" placeholder="$0.00" onchange="costAccessroies();" class="form-control db-bock" value="${{$item->other}}" readonly="" id="other" name="other">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Wastage<span class='red' style="margin-right: 22px;">*</span></label>
                            <input type="text" placeholder="Wastage %" onchange="costAccessroies();" required class="form-control db-bock" value="{{$item->wastage}}%" readonly="" id="wastage" name="wastage">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label>Total Accessories Cost</label>
                            <input type="text" placeholder="$0.00" readonly class="form-control db-bock" value="${{$item->totalAccessoriesCost}}" readonly="" id="totalAccessoriesCost" name="totalAccessoriesCost">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label>Cost with Wastage</label>
                            <input type="text" placeholder="$0.00" readonly class="form-control db-bock" value="${{$item->costWastage}}" readonly="" id="costWastage" name="costWastage">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div style="margin-bottom: 100px;"></div>
                <div class="col-md-12" style="margin-top:2px;">
                    <h5 class="heading3">GARMENTS CONSUMPTION</h5>
                    <h6 class="subheading">Garment size Detail Consumption</h6>
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Size Range<span class='red'>*</span></label>
                    <input type="text" placeholder="Garments Size Range" required class="form-control db-inline" value="{{$item->sizeRange}}" readonly="" id="sizeRange" name="sizeRange" >
                    <span class="field-helping">Eg: XXS-XXL</span>
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Costing Size<span class='red'>*</span></label>
                    <input type="text" placeholder="Size on Costing Done" required class="form-control db-inline" value="{{$item->costingSize}}"  readonly="" id="costingSize" name="costingSize" >
                </div>
                <div class="col-md-12" style="background-color: lightgrey">
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <select name="bodyLengthLabel" id="bodyLengthLabel" readonly="">
                                <option value="1">Body Length</option>
                                <option value="2">Out Leg Length</option>
                            </select><span class='red'>*</span>
                            <span style="display: inline-table;">
                                <input type="text" placeholder="00" class="form-control db-inline" required value="{{$item->bodyLength}}" id="bodyLength" onchange="garmentConsumptionData();" readonly="" name="bodyLength" style="width: 138px;">
                                <span class="field-helping-0">Body Length / CM</span>
                            </span>
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Wastage<span class='red'>*</span></label>
                            <span style="display: inline-table;">
                                <input type="text" placeholder="00" class="form-control db-inline" required value="{{$item->wastage1}}" id="wastage1" onchange="garmentConsumptionData();" readonly="" name="wastage1" style="width: 138px;">
                                <span class="field-helping-0">Body Wastage / CM</span>
                            </span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Sleeve Length<span class='red'>*</span></label>
                            <span style="display: inline-table;">
                                <input type="text" placeholder="00" class="form-control db-inline" required value="{{$item->sleeveLength}}" id="sleeveLength" onchange="garmentConsumptionData();" readonly="" name="sleeveLength" style="width: 138px;">
                                <span class="field-helping-0">Sleeve Length / CM</span>
                            </span>
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Wastage<span class='red'>*</span></label>
                            <span style="display: inline-table;">
                                <input type="text" placeholder="00" class="form-control db-inline" required value="{{$item->wastage2}}" id="wastage2" onchange="garmentConsumptionData();" readonly="" name="wastage2" style="width: 138px;">
                                <span class="field-helping-0">Sleeve Wastage / CM</span>
                            </span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <select name="halfChestLabel" id="halfChestLabel">
                                <option value="1">Half Chest Circum</option>
                                <option value="2">Half Thai</option>
                            </select><span class='red' style="margin-right: 2px;">*</span>
                            <span style="display: inline-table;">
                                <input type="text" placeholder="00" class="form-control db-inline" required onchange="garmentConsumptionData();" value="{{$item->halfChest}}" id="halfChest" readonly="" name="halfChest" style="width: 138px;">
                                <span class="field-helping-0">Half Chest / CM</span>
                            </span>
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Wastage<span class='red'>*</span></label>
                            <span style="display: inline-table;">
                                <input type="text" placeholder="00" class="form-control db-inline" required onchange="garmentConsumptionData();" value="{{$item->wastage3}}" id="wastage3" readonly="" name="wastage3" style="width: 138px;">
                                <span class="field-helping-0">Half Chest Wastage / CM</span>
                            </span>
                        </div>
                    </div>
                </div><br>
                <div class="col-md-12 bg-gray">
                    <label>Garments Consumption</label>
                    <input type="text" placeholder="0" class="form-control db-inline" value="{{$item->garmentsConsumption}}" id="garmentsConsumption" readonly="" name="garmentsConsumption">
                    <span class="field-helping">Total Fabric(in kg) Reguired for per DZN Garments</span>
                </div>
                <h2 class="heading3">GARMENTS COST</h2>
                <h5 class="subheading">Per Pcs Cost Analysis</h5>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Total Fabric Cost</label>
                    <input type="text" placeholder="$0" class="form-control db-inline" readonly="" value="${{$item->totalFabricCost}}" id="totalFabricCost" readonly="" name="totalFabricCost">
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Total Accessories Cost</label>
                    <input type="text" placeholder="$0" readonly=""  class="form-control db-inline" value="${{$item->totalAccessoriesCost1}}" id="totalAccessoriesCost1" readonly="" name="totalAccessoriesCost1">
                </div>
                <div class="col-md-12" style="background-color: lightgrey">
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Making Charge(CM)<span class='red'>*</span></label>
                            <input type="text" placeholder="$0.00" class="form-control db-inline" onchange="garmentsCostDznData();" required  value="${{$item->makingCharge}}" id="makingCharge" readonly="" name="makingCharge" style="width: 138px;">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Print Cost</label>
                            <input type="text" placeholder="$0.00" class="form-control db-inline" onchange="garmentsCostDznData();" value="${{$item->printCost}}" readonly="" id="printCost" name="printCost" style="width: 138px;">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Embroidery</label>
                            <input type="text" placeholder="$0.00" class="form-control db-inline" onchange="garmentsCostDznData();" value="${{$item->embroidery}}" readonly="" id="embroidery" name="embroidery" style="width: 138px;">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Wash</label>
                            <input type="text" placeholder="$0.00" class="form-control db-inline" onchange="garmentsCostDznData();" value="${{$item->wash1}}" readonly="" id="wash1" name="wash1" style="width: 138px;">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Test</label>
                            <input type="text" placeholder="$0.00" class="form-control db-inline" onchange="garmentsCostDznData();" value="${{$item->test}}" readonly="" id="test" name="test" style="width: 138px;">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label class="label-width">Commerical<span class='red'>*</span></label>
                            <input type="text" placeholder="$0.00" class="form-control db-inline" onchange="garmentsCostDznData();" required value="${{$item->commerical}}" readonly="" id="commerical" name="commerical" style="width: 138px;">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 bg-gray">
                            <label class="label-width"><input type="text" name="other2Label" id="other2Label" value="{{$item->other2Label}}" style="width:100px;"></label>
                            <input type="text" placeholder="$0.00" class="form-control db-inline" onchange="garmentsCostDznData();" value="${{$item->other2}}" readonly="" id="other2" name="other2" style="width: 138px;">
                        </div>
                        <div class="col-md-6 bg-gray">
                            <label class="label-width"><input type="text" name="other3Label" id="other3Label" value="{{$item->other3Label}}" style="width:100px;"></label>
                            <input type="text" placeholder="$0.00" class="form-control db-inline" onchange="garmentsCostDznData();" value="${{$item->other3}}" readonly="" id="other3" name="other3" style="width: 138px;">
                        </div>
                    </div>
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Garments Cost / Per DZN</label>
                    <input type="text" placeholder="$0" class="form-control db-inline" readonly="" onchange="garmentsCostDznData();" value="${{$item->garmentsCostDzn}}" readonly="" id="garmentsCostDzn" name="garmentsCostDzn">
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Garments Cost / Per Pcs</label>
                    <input type="text" placeholder="$0" class="form-control db-inline" readonly="" onchange="garmentsCostDznData();" value="${{$item->garmentsCostPcs}}" readonly=""id="garmentsCostPcs" name="garmentsCostPcs">
                </div>
                <h2 class="heading3">COST OFFERING</h2>
                <h5 class="subheading">Offer Price Considering Commission/Shipping</h5>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Garments Cost/ Per Pcs</label>
                    <input type="text" placeholder="0" class="form-control db-inline" value="{{$item->garmentsCost}}" id="garmentsCost" readonly="" name="garmentsCost">
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Agent Commission</label>
                    <input type="text" placeholder="00%" class="form-control db-inline" onchange="costOffering();" value="{{$item->agentCommission}}%" id="agentCommission" readonly="" name="agentCommission" style="width: 138px;">
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Shipping Cost</label>
                    <input type="text" placeholder="Shipping cost" class="form-control db-inline" onchange="costOffering();" value="${{$item->shippingCost}}" readonly="" id="shippingCost" name="shippingCost" style="width: 138px;">
                    <span class="field-helping">Eg:CIF AIR</span>
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Offer Price</label>
                    <input type="text" placeholder="$0" class="form-control db-inline" onchange="costOffering();" value="${{$item->offerPrice}}" id="offerPrice" readonly="" name="offerPrice" style="width: 138px;">
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Final Price</label>
                    <input type="text" placeholder="Final Price that Decied by Manul" onchange="costOffering();" class="form-control db-inline" value="{{$item->finalPrice}}" readonly="" id="finalPrice" name="finalPrice" >
                    <span class="field-helping">Manual input / Decieded by Manufacturer</span>
                </div>
                <div class="col-md-12 bg-gray">
                    <label class="label-width">Garments Image</label>
                </div>
                <div class="col-md-12" style="margin: auto;text-align: center;">
                    <img id="blah" src="{{URL::to('/')}}/public/images/{{$item->costFile}}" alt="your image" width="150px" height="150px"/>
                </div>

            </div>

        </div>
        @endforeach
    </div>


</div>	<!--/.main-->
@endsection