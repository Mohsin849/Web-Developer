@extends('admin/layouts.app')
@section('content')	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
        <div class="row">
            <ol class="breadcrumb">
                <li><a href="#">
                        <em class="fa fa-home"></em>
                </a></li>
                <li class="active">Cost Calculator List</li>
            </ol>
        </div><!--/.row-->
	<div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Cost Calculator</h1>
            </div>
        </div><!--/.row-->
		
	<div class="panel panel-container">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>User Name</th>
                        <th>Buyer Name</th>
                        <th>Style Number</th>
			<th>Created at</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($costCalculator as $item)
                    <tr>
                        <td>{{$item->name}}</td>
                        <td>{{$item->buyerName}}</td>
                        <td>{{$item->styleNumber}}</td>
                        <td>{{$item->created_at}}</td>	
                        <td>
                            <a href="{{URL::to('/')}}/admin/view-cost-calculator/{{$item->id}}" 
                               class="btn btn-success btn-icon btn-circle btn-sm" 
                               title="View">View
                            </a>
                        </td>
                    </tr>
                    @endforeach
		</tbody>
            </table>
        </div>
    </div>	<!--/.main-->
@endsection	