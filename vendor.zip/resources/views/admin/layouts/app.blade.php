<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dating</title>
	<link href="{{ asset('/resources/admin_assets/css/bootstrap.min.css') }}" rel="stylesheet">
	<link href="{{ asset('/resources/admin_assets/css/datepicker3.css') }}" rel="stylesheet">
	<link href="{{ asset('/resources/admin_assets/css/styles.css') }}" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="{{URL::to('/')}}/admin"><span>Dashboard</span></a>
				
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="http://placehold.it/50/30a5ff/fff" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name"> {{Auth::user()->name}}</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<ul class="nav menu">
			<li class="@if(Request::path() == 'admin/dashboard') active @endif"><a href="{{URL::to('/')}}/admin/"><em class="fa fa-toggle-off">&nbsp;</em>Dashboard</a></li>
			<li class="@if(Request::path() == 'admin/userList') active @endif"><a href="{{URL::to('/')}}/admin/userList"><em class="fa fa-toggle-off">&nbsp;</em>User List</a></li>
			<li class="@if(Request::path() == 'admin/pageList') active @endif"><a href="{{URL::to('/')}}/admin/pageList"><em class="fa fa-toggle-off">&nbsp;</em>Page Management</a></li>
			<li class="@if(Request::path() == 'admin/emailList') active @endif"><a href="{{URL::to('/')}}/admin/emailList"><em class="fa fa-toggle-off">&nbsp;</em>Email Template</a></li>
			<li class="@if(Request::path() == 'admin/profileApprove') active @endif"><a href="{{URL::to('/')}}/admin/profileApprove"><em class="fa fa-toggle-off">&nbsp;</em>Profile Approve List</a></li>

			<li><a href="{{URL::to('/')}}/logout" href="{{ route('logout') }}"
							   onclick="event.preventDefault();
								document.getElementById('logout-form').submit();"><em class="fa fa-toggle-off">&nbsp;</em>
								{{ __('Logout') }}
				</a>
				<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
					@csrf
				</form>
			</li>
		</ul>
	</div><!--/.sidebar-->
		<main class="py-4">
            @yield('content')
        </main>
		
	<script src="{{ asset('/resources/admin_assets/js/jquery-1.11.1.min.js') }}"></script>
	<script src="{{ asset('/resources/admin_assets/js/bootstrap.min.js') }}"></script>
	<script src="{{ asset('/resources/admin_assets/js/bootstrap-datepicker.js') }}"></script>
	<script src="{{ asset('/resources/admin_assets/js/custom.js') }}"></script>
	
		
</body>
</html>