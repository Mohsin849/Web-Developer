@extends('admin/layouts.app')
@section('content')	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
                    <ol class="breadcrumb">
                        <li>
                            <a href="#">
                                <em class="fa fa-home"></em>
                            </a>
                        </li>
                        <li class="active">Edit Setting</li>
                    </ol>
		</div><!--/.row-->
		
		<div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Edit Setting</h1>
                    </div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
                    <form class="form-horizontal form-bordered" data-parsley-validate="true" role="form" action="{{URL::to('admin/edit-setting-data/1')}}" method="post" files="true" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Email From:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="text" class="form-control" value="{{$setting->email_from}}" id="email_from" name="email_from" required>
                        </div>
                    </div>
					<div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Email To:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="text" class="form-control" value="{{$setting->send_email}}" id="send_email" name="send_email" required>
                        </div>
                    </div>
					<div class="form-group">
						<label class="control-label col-md-4 col-sm-4" for="content">Banner Image :</label>
						<div class="col-md-6 col-sm-6">
							<input type="file" class="form-control" value="" id="banner" name="banner">
							<p><img src="{{ asset('public/images/'.$setting->banner) }}" width="50px" height="50px"></p>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-4 col-sm-4" for="content">Header Logo :</label>
						<div class="col-md-6 col-sm-6">
							<input type="file" class="form-control" value="" id="header_logo" name="header_logo">
							<p><img src="{{ asset('public/images/'.$setting->header_logo) }}" width="50px" height="50px"></p>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-md-4 col-sm-4" for="content">Footer Logo :</label>
						<div class="col-md-6 col-sm-6">
							<input type="file" class="form-control" value="" id="footer_logo" name="footer_logo">
							<p><img src="{{ asset('public/images/'.$setting->footer_logo) }}" width="50px" height="50px"></p>
						</div>
					</div>
					
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Site Title:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="text" class="form-control" value="{{$setting->site_title}}" id="site_title" name="site_title" required>
                        </div>
                    </div>
					
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Button Color:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="color" class="form-control" value="{{$setting->button_color}}" id="button_color" name="button_color" required>
                        </div>
                    </div>
					<div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Thankyou Background Color:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="color" class="form-control" value="{{$setting->background_color}}" id="background_color" name="background_color" required>
                        </div>
                    </div>
					<div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Bar Color:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="color" class="form-control" value="{{$setting->bar_color}}" id="bar_color" name="bar_color" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4"></label>
                        <div class="col-md-6 col-sm-6">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
	</div>	<!--/.main-->
@endsection