@extends('admin/layouts.app')
@section('content')	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
                    <ol class="breadcrumb">
                        <li>
                            <a href="#">
                                <em class="fa fa-home"></em>
                            </a>
                        </li>
                        <li class="active">Edit Profile setting</li>
                    </ol>
		</div><!--/.row-->
		
		<div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Edit Profile setting</h1>
                    </div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
                    <form class="form-horizontal form-bordered" data-parsley-validate="true" role="form" action="{{URL::to('admin/edit-profile-setting-data/1')}}" method="post" files="true" enctype="multipart/form-data">
                    {{ csrf_field() }}
					<div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Email:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="text" class="form-control" value="{{$user->email}}" id="email" name="email" required>
                        </div>
                    </div>
					<div class="form-group">
                        <label class="control-label col-md-4 col-sm-4" for="content">Password:</label>
                        <div class="col-md-6 col-sm-6">
                            <input type="password" class="form-control" value="" id="password" name="password">
                        </div>
                    </div>
					
                    <div class="form-group">
                        <label class="control-label col-md-4 col-sm-4"></label>
                        <div class="col-md-6 col-sm-6">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
	</div>	<!--/.main-->
@endsection