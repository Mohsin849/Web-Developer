@extends('admin/layouts.app')
@section('content')	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Edit Setting</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Edit Setting</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			<form class="form-horizontal form-bordered" data-parsley-validate="true" role="form" action="{{URL::to('admin/edit-setting-data/'.$setting->id)}}" method="post" files="true" enctype="multipart/form-data">
                 {{ csrf_field() }}
				<div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Contact Us:</label>
                    <div class="col-md-6 col-sm-6">
                        <input type="text" class="form-control" value="{{$setting->contact_us}}" id="contactUs" name="contactUs" required>
					</div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Facebbok:</label>
                    <div class="col-md-6 col-sm-6">
                        <input type="text" class="form-control"  value="{{$setting->facebook}}" id="facebook" name="facebook">
					</div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">YouTube:</label>
                    <div class="col-md-6 col-sm-6">
                        <input type="text" class="form-control"  value="{{$setting->youtube}}" id="youtube" name="youtube">
					</div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Linkden:</label>
                    <div class="col-md-6 col-sm-6">
                        <input type="text" class="form-control"  value="{{$setting->linkden}}" id="linkden" name="linkden">
					</div>
                </div>
				<div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Instagrame:</label>
                    <div class="col-md-6 col-sm-6">
                        <input type="text" class="form-control"  value="{{$setting->instagrame}}" id="instagrame" name="instagrame">
					</div>
                </div>
				<div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Contact Us Form Email:</label>
                    <div class="col-md-6 col-sm-6">
                        <input type="text" class="form-control"  value="{{$setting->contactemail}}" id="contactemail" name="contactemail">
					</div>
                </div>
				<div class="form-group">
						<label class="control-label col-md-4 col-sm-4" for="content">Banner Image :</label>
						<div class="col-md-6 col-sm-6">
							<input type="file" class="form-control" value="" id="bannerImage" name="bannerImage">
							<p><img src="{{ asset('public/images/'.$setting->image) }}" width="50px" height="50px"></p>
						</div>
				</div>
				<div class="form-group">
                    <label class="control-label col-md-4 col-sm-4" for="content">Setting Banner Content:</label>
                    <div class="col-md-6 col-sm-6">
					    <textarea name="contactdescription"   rows="4" cols="95" id="contactdescription">{{$setting->contactdescription}}</textarea>
					</div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-4 col-sm-4"></label>
                    <div class="col-md-6 col-sm-6">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
		</div>
		
		
	</div>	<!--/.main-->
@endsection