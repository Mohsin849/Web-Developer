@extends('admin/layouts.app')
@section('content')	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Setting</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Setting</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
			
            <table class="table table-striped">
                <thead>
                    <tr>

                        <th>Contact Us</th>
                        <th>Facebook</th>
						<th>Youtube</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
						@foreach($setting as $setting)
							
							<tr>
								<td>{{ $setting->contact_us }}</td>
								<td>{{ $setting->facebook }}</td>
								<td>{{ $setting->youtube }}</td>
							
								<td>
									<a href="{{URL::to('/')}}/admin/edit-setting/{{$setting->id}}" 
									   class="btn btn-success btn-icon btn-circle btn-sm" 
									   title="Edit">Edit
									</a>
									
								</td>
							</tr>
						@endforeach
						
				</tbody>

            </table>
            
		</div>
		
		
	</div>	<!--/.main-->
@endsection