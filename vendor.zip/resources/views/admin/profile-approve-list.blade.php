@extends('admin/layouts.app')
@section('content')
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Dashboard</h1>
			</div>
		</div><!--/.row-->
		
		<div class="panel panel-container">
		  
			<table class="table table-striped">
			  <thead>
				<tr>
				  <th scope="col">Name</th>
				  <th scope="col">Image</th>
				  <th scope="col">Status</th>
				</tr>
			  </thead>
			  <tbody>
			     
				@foreach($result as $key => $item)
			    <tr>
				  <th>{{$item->name}}</th>
				  <td><img src="{{URL::to('/resources/assets/images/documents/'.$item->verify_document)}}" width="100px;" height="80px;"></td>
				  <td>
					@if($item->verify_document_status ==1)
						<a href="{{URL::to('/resources/assets/images/documents/')}}">Approved</a> 
					@else 
						<a href="{{URL::to('/resources/assets/images/documents/')}}">Pending</a>
					@endif</td>
				</tr>
				@endforeach
			  </tbody>
			</table>
		</div>
		
		
	</div>	<!--/.main-->
@endsection