<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
        @include('layout.head')
    </head>
    <body>
        <section id="header">
            @include('layout.header')
        </section>
        <div class="middle-container">
            @yield('content')
        </div>
        @include('layout.footer')
    </body>

</html>
