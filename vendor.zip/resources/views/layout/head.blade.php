 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="Cupid Love - Dating HTML5 Template" />
    <meta name="author" content="potenzaglobalsolutions.com" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="csrf-token" content="{{ csrf_token() }}" />
    <title>Pinny Partners Love Dating</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="{{URL::to('/')}}/resources/assets/images/favicon.ico" />

    <!-- bootstrap -->
    <link href="{{URL::to('/')}}/resources/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="{{URL::to('/')}}/resources/assets/css/bootstrap-select.min.css" rel="stylesheet" type="text/css" />

    <!-- mega menu -->
    <link href="{{URL::to('/')}}/resources/assets/css/mega-menu/mega_menu.css" rel="stylesheet" type="text/css" />

    <!-- font-awesome -->
    <link href="{{URL::to('/')}}/resources/assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

    <!-- Flaticon -->
    <link href="{{URL::to('/')}}/resources/assets/css/flaticon.css" rel="stylesheet" type="text/css" />

    <!-- Magnific popup -->
    <link href="{{URL::to('/')}}/resources/assets/css/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css" />

    <!-- owl-carousel -->
    <link href="{{URL::to('/')}}/resources/assets/css/owl-carousel/owl.carousel.css" rel="stylesheet" type="text/css" />

    <!-- General style -->
    <link href="{{URL::to('/')}}/resources/assets/css/general.css" rel="stylesheet" type="text/css" />

    <!-- main style -->
    <link href="{{URL::to('/')}}/resources/assets/css/style.css" rel="stylesheet" type="text/css" />
	<!-- parsley style -->
    <link href="{{URL::to('/')}}/resources/assets/css/parsley.css" rel="stylesheet" type="text/css" />
    <!-- Style customizer -->
    <link rel="stylesheet" type="text/css" href="{{URL::to('/')}}/resources/assets/css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="https://pinaypartners.com/resources/assets/css/skins/skin-default.css" data-style="styles" />
    <link rel="stylesheet" type="text/css" href="{{URL::to('/')}}/resources/assets/css/style-customizer.css" /> 