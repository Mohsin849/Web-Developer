<footer class="page-footer font-small unique-color-dark text-white" style="background-color: #000;">
	<div style="background-color: #6351ce;">
    <div class="container">
		<!-- Grid row-->
		<div class="row py-4 d-flex align-items-center">

			<!-- Grid column -->
			<div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
			  <h6 class="mb-0">Get connected with us on social networks!</h6>
			</div>
			<div class="col-md-6 col-lg-7 text-center text-md-right">
			  <!-- Facebook -->
			  <a class="fb-ic">
				<i class="fa fa-facebook-f white-text mr-4"> </i>
			  </a>
			  <!-- Twitter -->
			  <a class="tw-ic">
				<i class="fa fa-twitter white-text mr-4"> </i>
			  </a>
			  <!-- Google +-->
			  <a class="gplus-ic">
				<i class="fa fa-google-plus-g white-text mr-4"> </i>
			  </a>
			  <!--Linkedin -->
			  <a class="li-ic">
				<i class="fa fa-linkedin-in white-text mr-4"> </i>
			  </a>
			  <!--Instagram-->
			  <a class="ins-ic">
				<i class="fa fa-instagram white-text"> </i>
			  </a>
			</div>
        <!-- Grid column -->
		</div>
      <!-- Grid row-->
	</div>
  </div>

<div class="col-md-12 text-center pt-3">
	
	<a class="me2 text-white" href="{{URL::to('/')}}/about" rel="nofollow">About Us</a>
	<a class="me2 text-white" href="{{URL::to('/')}}/contact">Contact Us</a>
	<a class="me2 text-white" href="{{URL::to('/')}}/general/success">Success Stories</a>
	<a class="me2 text-white" href="{{URL::to('/')}}/termsofuse">Terms of Use</a>
	<a class="me2 text-white" href="{{URL::to('/')}}/privacy">Privacy Statement</a>
	<a class="me2 text-white" href="{{URL::to('/')}}/datingsafety">Dating Safety</a>				
</div>
<div class="footer-copyright text-center py-3">© 2018 Copyright:
	<a  class="text-white" href="{{URL::to('/')}}/"> EastLogics.com</a>
</div>    
</footer>
<!-- Footer -->
<input type="hidden" id="siteburl" name="siteburl" value="https://pinaypartners.com/">
<div id="back-to-top"><a class="top arrow" href="#top"><i class="fa fa-level-up"></i></a></div>
<!--================================= jquery -->
	<!-- jquery  -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/popper.min.js"></script>
	<!-- bootstrap -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/bootstrap-select.min.js"></script>
	<!-- appear -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/jquery.appear.js"></script>
	<!-- Menu -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/mega-menu/mega_menu.js"></script>
	<!-- owl-carousel -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/owl-carousel/owl.carousel.min.js"></script>
	<!-- counter -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/counter/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/magnific-popup/jquery.magnific-popup.min.js"></script>
	<!-- style customizer  -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/style-customizer.js"></script>
	<!-- parsley.min -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/parsley.min.js"></script>
	<script type="text/javascript" src="{{URL::to('/')}}/resources/js/bootstrap-notify-3.1.3/bootstrap-notify.min.js"></script>
	<!-- custom -->
	<script type="text/javascript" src="{{URL::to('/')}}/resources/assets/js/custom.js"></script>
	