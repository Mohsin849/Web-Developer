 <header id="header" class="dark">
        <div class="topbar" style="display: block;">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="topbar-left text-left">
                            <ul class="list-inline">
                                <li><a href="mailto:support@website.com"><i class="fa fa-envelope-o"> </i> support@website.com </a></li>
                                <li><a href="tel:(007)1234567890"><i class="fa fa-phone"></i> (007) 123 456 7890 </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="topbar-right text-right">
                            <ul class="list-inline social-icons color-hover">
                                <li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li class="social-instagram"><a href="#"><i class="fa fa-instagram"></i></a></li>
                                <li class="social-dribbble"><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                            <ul class="list-inline text-uppercase top-menu">
                                @if(Auth::guest())
									<li><a href="{{URL::to('/')}}/register">register</a></li>
									<li><a href="{{URL::to('/')}}/login">login</a></li>
								@else
									<li>
										<a class="dropdown-item" href="{{ route('logout') }}"
										   onclick="event.preventDefault();
														 document.getElementById('logout-form').submit();">
											{{ __('Logout') }}
										</a>
										<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
											@csrf
										</form>
									</li>
								@endif
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--=================================
 mega menu -->

        <div class="menu">
            <!-- menu start -->
            <nav id="menu" class="mega-menu">
                <!-- menu list items container -->
                <section class="menu-list-items">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- menu logo -->
                                <ul class="menu-logo">
                                    <li>
                                        <a href="{{URL::to('/')}}">
                                            <h3>Pinay Partners</h3>
                                        </a>
                                    </li>
                                </ul>
								@if(!Auth::guest())
                                <!-- menu links -->
                                <ul class="menu-links">
                                    <!-- active class -->
                                    
									<li>
										<a href="{{URL::to('/dashboard')}}">5,404 Members Online</a>
                                    </li>
                                    <li>
										<a href="{{URL::to('/matches')}}">Matches</a>
                                    </li>
                                    <li>
										<a href="{{URL::to('/search')}}">Search</a>
                                    </li>
									<li>
										<a href="{{URL::to('/messageList')}}">Messages</a>
                                    </li>
                                    <li><a href="javascript:void(0)"> Activity <i class="fa fa-angle-down fa-indicator"></i></a>
                                        <!-- drop down multilevel  -->
                                        <ul class="drop-down-multilevel right-menu">
                                            
                                            <li><a href="{{URL::to('/interested-in-me')}}">Interested In Me</a></li>
                                            <li><a href="{{URL::to('/favorited-in-me')}}">I'm Their Favorite</a></li>
											<li><a href="{{URL::to('/viewed-my-profile')}}">Viewed My Profile</a></li>
                                            <li><a href="{{URL::to('/my-interest')}}">My Interests</a></li>
                                            <li><a href="{{URL::to('/my-favorites')}}">My Favorites</a></li>
											<li><a href="{{URL::to('/profile-view')}}">Profiles I Viewed</a></li>
											<li><a href="{{URL::to('/block-list')}}">Block List</a></li>
											
                                        </ul>
                                    </li>
									
									<li>
										<a href="javascript:void(0)">
										@if(Auth::user()->avatar_1 == '')
											<img src="{{URL::to('/')}}/resources/assets/images/profile/avatar.png" alt="Avatar" class="avatar">
										@else
											<img src="{{URL::to('/')}}/resources/assets/images/profile/{{Auth::user()->avatar_1}}" alt="Avatar" class="avatar">
										@endif	
										</a>
                                        <!-- drop down multilevel  -->
                                        <ul class="drop-down-multilevel right-menu">
                                            <li><a href="{{URL::to('/show-profile/'.str_slug(Auth::user()->name).'/'.Auth::user()->id)}}">View Profile</a></li>
                                            <li><a href="{{URL::to('/editmyprofile')}}">Edit Profile</a></li>
											<li><a href="{{URL::to('/editprofilephotos')}}">Photos</a></li>
                                            <li><a href="{{URL::to('/editmatchinfo')}}">Matches</a></li>
                                            <li><a href="{{URL::to('/editinterestinfo')}}">Hobbies & Interests</a></li>
											<li><a href="{{URL::to('/editpersonalityinfo')}}">Personality Questions</a></li>
											<li><a href="{{URL::to('/verifyprofile')}}">Verify Questions</a></li>
										</ul>
                                    </li>									
									<li><a href="javascript:void(0)"><img src="https://img.icons8.com/ultraviolet/40/000000/settings.png"></a>
                                        <!-- drop down multilevel  -->
                                        <ul class="drop-down-multilevel right-menu">
                                            
                                            <li><a href="{{URL::to('/showemailsettings')}}">Email Address</a></li>
                                            <li><a href="{{URL::to('/showpasswordsettings')}}">Password</a></li>
											<li><a href="{{URL::to('/showprofilesettings')}}">Profile Settings</a></li>
                                            <li><a href="">Billing</a></li>
                                            <li><a href="{{URL::to('/shownotificationsettings')}}">Notifications</a></li>
											<li><a href="">Help</a></li>
											<li><a href="">Upgrade Membership</a></li>
											
                                        </ul>
                                    </li>
                                </ul>
								@endif
							</div>
                        </div>
                    </div>
                </section>
            </nav>
            <!-- menu end -->
        </div>
    </header>
