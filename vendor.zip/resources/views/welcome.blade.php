@extends('layouts.app')

@section('content')
      <!--=================================
 banner -->

    <section id="home-slider" class="fullscreen">
        <div id="main-slider" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <!--/ Carousel item end -->
                <div class="carousel-item active h-100 bg-overlay-red" style="background: url({{URL::to('/')}}/resources/assets/images/bg/bg-1.jpg) no-repeat 0 0; background-size: cover;">
                    <div class="slider-content">
                        <div class="container">
                            <div class="row carousel-caption align-items-center h-100">
                                <div class="col-md-12 text-right">
                                    <div class="slider-1">
                                        <h1 class="animated2 text-white">Are You <span>Waiting</span> For <span> Dating ?</span></h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item h-100 bg-overlay-red" style="background: url({{URL::to('/')}}/resources/assets/images/bg/bg-2.jpg) no-repeat 0 0; background-size: cover;">
                    <div class="slider-content">
                        <div class="container">
                            <div class="row carousel-caption align-items-center h-100">
                                <div class="col-md-12 text-left">
                                    <div class="slider-1">
                                        <h1 class="animated7 text-white">Meet big <span> and </span> beautiful love <span> here!</span></h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/ Carousel item end -->
            </div>
            <!-- Controls -->
            <a class="left carousel-control" href="#main-slider" data-slide="prev"> <span><i class="fa fa-angle-left"></i></span> </a>
            <a class="right carousel-control" href="#main-slider" data-slide="next"> <span><i class="fa fa-angle-right"></i></span> </a>
        </div>
    </section>

    <!--=================================
 banner -->
   <section class="page-section-ptb position-relative timeline-section">
        <div class="container">
            <div class="row justify-content-center mb-5 sm-mb-3">
                <div class="col-md-10 text-center">
                    <h2 class="title divider mb-3">Step to find your Soul Mate</h2>
                    <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed <br/> do eiusmod tempor incididunt ut labore et dolore magna</p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10 col-md-12">
                    <ul class="timeline list-inline">
                        <li>
                            <div class="timeline-badge"><img class="img-fluid" src="{{URL::to('/')}}/resources/assets/images/timeline/01.png" alt="" /></div>
                            <div class="timeline-panel">
                                <div class="timeline-heading text-center">
                                    <h4 class="timeline-title divider-3">CREATE PROFILE</h4>
                                </div>
                                <div class="timeline-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. enim ad minim veniam, quis</p>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-badge"><img class="img-fluid" src="{{URL::to('/')}}/resources/assets/images/timeline/02.png" alt="" /></div>
                            <div class="timeline-panel">
                                <div class="timeline-heading text-center">
                                    <h4 class="timeline-title divider-3">Find match</h4>
                                </div>
                                <div class="timeline-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. enim ad minim veniam, quis</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="timeline-badge"><img class="img-fluid" src="{{URL::to('/')}}/resources/assets/images/timeline/03.png" alt="" /></div>
                            <div class="timeline-panel">
                                <div class="timeline-heading text-center">
                                    <h4 class="timeline-title divider-3">START DATING</h4>
                                </div>
                                <div class="timeline-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. enim ad minim veniam, quis</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
  
    <section class="page-section-ptb  text-white" style="background: url({{URL::to('/')}}/resources/assets/images/pattern/02.png) no-repeat 0 0; background-size: cover;">
        <div class="container">
            <div class="row justify-content-center mb-5 sm-mb-3">
                <div class="col-md-8 text-center">
                    <h2 class="title divider">Animated Fun Facts</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 text-center">
                    <div class="counter"> <img src="{{URL::to('/')}}/resources/assets/images/counter/01.png" alt="" /> <span class="timer" data-to="1600" data-speed="10000">1600</span>
                        <label>Total Members</label>
                    </div>
                </div>
                <div class="col-md-3 text-center">
                    <div class="counter"> <img src="{{URL::to('/')}}/resources/assets/images/counter/02.png" alt="" /> <span class="timer" data-to="750" data-speed="10000">750</span>
                        <label>Online Members</label>
                    </div>
                </div>
                <div class="col-md-3 text-center">
                    <div class="counter"> <img src="{{URL::to('/')}}/resources/assets/images/counter/03.png" alt="" /> <span class="timer" data-to="380" data-speed="10000">380</span>
                        <label>Men Online</label>
                    </div>
                </div>
                <div class="col-md-3 text-center">
                    <div class="counter"> <img src="{{URL::to('/')}}/resources/assets/images/counter/04.png" alt="" /> <span class="timer" data-to="370" data-speed="10000">370</span>
                        <label>Women Online</label>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="page-section-ptb grey-bg story-slider">
        <div class="container">
            <div class="row justify-content-center mb-2 sm-mb-0">
                <div class="col-md-8 text-center">
                    <h2 class="title divider">They Found True Love</h2>
                </div>
            </div>
        </div>
        <div class="owl-carousel" data-nav-dots="true" data-items="5" data-lg-items="4" data-md-items="3" data-sm-items="2" data-space="30">
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/01.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">Quinnel &amp;amp; Jonet</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/02.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">Adam &amp;amp; Eve</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/03.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">Bella &amp;amp; Edward</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/04.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">DEMI &amp;amp; HEAVEN</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/05.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">David &amp;amp; Bathsheba</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/06.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">Eros &amp;amp; Psychi</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/07.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">Hector &amp;amp; Andromache</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/08.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">Bonnie &amp;amp; Clyde</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/09.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">Henry &amp;amp; Clare</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/10.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">Casanova &amp;amp; Francesca</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/11.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">Jack &amp;amp; Sally</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="story-item">
                    <div class="story-image clearfix"><img class="img-fluid w-100" src="{{URL::to('/')}}/resources/assets/images/story/12.jpg" alt="" />
                        <div class="story-link"><a href="stories-details.html"><i class="glyph-icon flaticon-add"></i></a></div>
                    </div>
                    <div class="story-details text-center">
                        <h5 class="title divider-3">James &amp;amp; Lilly</h5>
                        <div class="about-des mt-3">Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
  
    <section class="page-section-ptb o-hidden grey-bg">
        <div class="container">
            <div class="row justify-content-center mb-5 sm-mb-0">
                <div class="col-md-10 text-center">
                    <h2 class="title divider mb-3">Why Choose Us</h2>
                    <p class="lead">Eum cu tantas legere complectitur, hinc utamur ea eam. Eum patrioque mnesarchum eu, diam erant convenire et vis. Et essent evertitur sea, vis cu ubique referrentur, sed eu dicant expetendis. Eum cu</p>
                </div>
            </div>
           
        </div>
    </section>

    <!--=================================
 page-section -->

    <section class="py-5 action-box-img bg text-center text-white bg-overlay-black-80" style="background-image:url(images/bg/bg-4.jpg)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <h5 class="pb-2">Want to hear more story, subscribe for our newsletter</h5>
                    <a class="button  btn-lg btn-theme full-rounded animated right-icn"><span>Subscribe<i class="glyph-icon flaticon-hearts" aria-hidden="true"></i></span></a> </div>
            </div>
        </div>
    </section>

@endsection
