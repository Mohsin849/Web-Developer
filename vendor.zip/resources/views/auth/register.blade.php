@extends('layouts.app')

@section('content')
<section class="login-form page-section-ptb" style="background:url('resources/assets/images/hero.jpg'); background-size: cover;
													background-position: 65%;width: 100%;height: 100%;">
  <div class="container">
    <div class="row  justify-content-center">
      <div class="col-md-6">
		<form method="post" action="{{ route('register') }}" data-parsley-validate="">
		<input type="hidden" name="_token" value="{{ csrf_token() }}">
        <div class="login-1-form register-1-form clearfix">
          <h4 class="title divider-3 mb-3 text-white">sign up</h4>
          <div class="login-1-social mt-5 mb-5 text-center clearfix">
            <ul class="list-inline text-capitalize">
              <li><a class="fb" href="{{ url('/auth/redirect/facebook') }}"><i class="fa fa-facebook"></i> Facebook Register</a></li>
              
            </ul>
          </div>
          <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-user"></i>
              <input id="firstname" name="firstname" class="web" type="text" placeholder="First name" required>
            </div>
          </div>
		  <div class="section-field mb-3">
            <div class="field-widget"> <i class="glyph-icon flaticon-padlock"></i>
              <input id="password" name="password" class="Password" type="password" placeholder="Password" required>
            </div>
          </div>
          <div class="section-field mb-3">
            <div class="field-widget"> <i class="fa fa-envelope-o" aria-hidden="true"></i>
              <input id="email" class="email" type="email" placeholder="Email" name="email" required>
            </div>
          </div>
          <div class="section-field" style="color: white;">
			  <label style="color: white;padding-right: 10px;font-size: 18px;">I'm a</label>
              <input id="iam" name="gender" class="web" type="radio" value="1" required>Male
			  <input id="iam" name="gender" class="web" type="radio" value="2"  required>Female
          </div>
		  <div class="section-field mb-3 mt-3">
            <div class="field-widget"> 
              <select name="age" id="age" class="web" required style="width:100%;height: 35px;">
				<option value="">Age</option>
				<option value="18">18</option>
				<option value="19">19</option>
				<option value="20">20</option>
				<option value="21">21</option>
				<option value="22">22</option>
				<option value="23">23</option>
				<option value="24">24</option>
				<option value="25">25</option>
				<option value="26">26</option>
				<option value="27">27</option>
				<option value="28">28</option>
				<option value="29">29</option>
				<option value="30">30</option>
				<option value="31">31</option>
				<option value="32">32</option>
				<option value="33">33</option>
				<option value="34">34</option>
				<option value="35">35</option>
				<option value="36">36</option>
				<option value="37">37</option>
				<option value="38">38</option>
				<option value="39">39</option>
				<option value="40">40</option>
			</select>
            </div>
          </div>
		  <div class="section-field mb-3">
            <div class="field-widget"> 
              <select name="country" id="country" class="web" required style="width:100%;height: 35px;" onchange="getState(this);">
					<option value="">Country</option>
				@foreach($countryList as $item)
					<option value="{{$item->id}}">{{$item->name}}</option>
				@endforeach
			</select>
            </div>
          </div>
          <div class="section-field mb-3">
            <div class="field-widget"> 
              <select name="state" id="state" class="web" required style="width:100%;height: 35px;" onchange="getCity(this);">
				<option value="">State</option>
				
			</select>
            </div>
          </div>
		  <div class="section-field mb-3">
            <div class="field-widget"> 
              <select name="city" id="city" class="web" required style="width:100%;height: 35px;">
				<option value="">City</option>
			  </select>
            </div>
          </div>
         
          <div class="clearfix"></div>
          <div class="section-field text-uppercase text-right mt-2">
			<button class="button btn-lg btn-theme full-rounded animated right-icn">
				<span>VIEW SINGLE NOW</span>
			</button>
		  </div>
          <div class="clearfix"></div>
        </div>
		</form>
      </div>
    </div>
  </div>
</section>

@endsection
