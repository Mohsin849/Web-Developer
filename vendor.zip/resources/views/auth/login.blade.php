@extends('layouts.app')
@section('content')

<section class="login-form page-section-ptb" style="background:url('resources/assets/images/hero.jpg'); background-size: cover;
													background-position: 65%;width: 100%;height: 100%;">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="login-1-form clearfix text-center">
          <h4 class="title divider-3 text-white">SIGN IN</h4>
          <div class="login-1-social mt-5 mb-5 text-center clearfix">
            <ul class="list-inline text-capitalize">
              <li><a class="fb" href="{{ url('/auth/redirect/facebook') }}"><i class="fa fa-facebook"></i> Facebook Login</a></li>
              
            </ul>
          </div>
		@foreach ($errors->all() as $error)

		  <div class="alert alert-danger" role="alert">{{ $error }}</div>

		@endforeach
		  <form method="POST" action="{{ route('login') }}" data-parsley-validate="">
          @csrf
          <div class="section-field mb-2">
            <div class="field-widget"> <i class="glyph-icon flaticon-user"></i>
              <input id="email" class="web" type="text" placeholder="Email" name="email" required>
            </div>
          </div>
          <div class="section-field mb-1">
            <div class="field-widget"> <i class="glyph-icon flaticon-padlock"></i>
              <input id="Password" class="Password" type="password" placeholder="Password" name="password" required>
            </div>
          </div>
          <div class="section-field text-uppercase">
			@if (Route::has('password.request'))
				<a class="float-right text-white" href="{{ route('password.request') }}">
					{{ __('Forgot Your Password?') }}
				</a>
			@endif
		  </div>
		  
          <div class="clearfix"></div>
          <div class="section-field text-uppercase text-right mt-2"> 
			<button type="submit" class="button  btn-lg btn-theme full-rounded animated right-icn">
				<span>sign in<i class="glyph-icon flaticon-hearts" aria-hidden="true"></i></span>
			</button> 
		  </div>
          <div class="clearfix"></div>
          <div class="section-field mt-2 text-center text-white">
            <p class="lead mb-0">Don’t have an account? <a class="text-white" href="register"><u>Register now!</u> </a></p>
          </div>
		  </form>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection
