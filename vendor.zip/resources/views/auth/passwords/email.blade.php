@extends('layouts.app')

@section('content')
<section class="login-form page-section-ptb" style="background:">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="login-1-form clearfix text-center">
          <h4 class="title divider-3 text-white">{{ __('Reset Password') }}</h4>
          
			@if (session('status'))
				<div class="alert alert-success" role="alert">
					{{ session('status') }}
				</div>
			@endif
		  <form method="POST" action="{{ route('password.email') }}">
            @csrf
          <div class="section-field mb-2">
            <div class="field-widget"> <i class="glyph-icon flaticon-user"></i>
              <input id="email" type="email" class="web @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
				@error('email')
					<span class="invalid-feedback" role="alert">
						<strong>{{ $message }}</strong>
					</span>
				@enderror
            </div>
          </div>
          
          
		  
          <div class="clearfix"></div>
          <div class="section-field text-uppercase text-right mt-2"> 
			<button type="submit" class="button  btn-lg btn-theme full-rounded animated right-icn">
				<span>{{ __('Send Password Reset Link') }}</span>
			</button> 
		  </div>
		  </form>
        </div>
      </div>
    </div>
  </div>
</section>

@endsection
