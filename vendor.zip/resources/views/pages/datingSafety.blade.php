@extends('layouts.app')
@section('content')
{!! $result->description !!}
@endsection
